"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  id: string
  email: string
  username: string
  firstName: string
  lastName: string
  dateOfBirth: string
  phoneNumber: string
  gender: "male" | "female" | "other" | "prefer-not-to-say"
  profession: string
  timezone: string
  preferences: {
    theme: "light" | "dark" | "system"
    gameTheme: "fantasy" | "sci-fi" | "minimal" | "nature"
    timeManagement: "pomodoro" | "timeblocking" | "flexible"
    intensity: "casual" | "moderate" | "intense"
    notifications: boolean
    sounds: boolean
    motivationalContent: "music" | "videos" | "quotes" | "none"
  }
  avatar: {
    id: string
    name: string
    unlocked: boolean
    equipped: boolean
  }[]
  stats: {
    level: number
    xp: number
    totalXp: number
    streak: number
    tasksCompleted: number
    weeklyXp: number
    monthlyXp: number
    yearlyXp: number
  }
  lastLoginDate: string | null
  loginBonus?: {
    xp: number
    message: string
    streak: number
  }
  onboardingCompleted: boolean
  createdAt: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  register: (userData: any) => Promise<boolean>
  logout: () => void
  updateUser: (updates: Partial<User>) => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

const defaultAvatars = [
  { id: "knight", name: "Knight", unlocked: true, equipped: true },
  { id: "mage", name: "Mage", unlocked: false, equipped: false },
  { id: "archer", name: "Archer", unlocked: false, equipped: false },
  { id: "warrior", name: "Warrior", unlocked: false, equipped: false },
  { id: "ninja", name: "Ninja", unlocked: false, equipped: false },
  { id: "paladin", name: "Paladin", unlocked: false, equipped: false },
]

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const checkAuth = async () => {
      const savedUser = localStorage.getItem("currentUser")
      if (savedUser) {
        try {
          const parsedUser = JSON.parse(savedUser)
          if (parsedUser && parsedUser.preferences) {
            setUser(parsedUser)
          }
        } catch (error) {
          console.error("Error parsing saved user:", error)
          localStorage.removeItem("currentUser")
        }
      }
      setIsLoading(false)
    }
    
    setTimeout(checkAuth, 1500)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true)
    
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    const existingUsers = JSON.parse(localStorage.getItem("users") || "{}")
    let userData = existingUsers[email]
    
    if (!userData) {
      userData = {
        id: `user-${Date.now()}`,
        email,
        username: email.split("@")[0],
        firstName: "",
        lastName: "",
        dateOfBirth: "",
        phoneNumber: "",
        gender: "prefer-not-to-say",
        profession: "",
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        preferences: {
          theme: "dark",
          gameTheme: "fantasy",
          timeManagement: "pomodoro",
          intensity: "moderate",
          notifications: true,
          sounds: true,
          motivationalContent: "music"
        },
        avatar: defaultAvatars,
        stats: {
          level: 1,
          xp: 0,
          totalXp: 0,
          streak: 0,
          tasksCompleted: 0,
          weeklyXp: 0,
          monthlyXp: 0,
          yearlyXp: 0
        },
        lastLoginDate: null,
        onboardingCompleted: false,
        createdAt: new Date().toISOString()
      }
      
      existingUsers[email] = userData
      localStorage.setItem("users", JSON.stringify(existingUsers))
    }
    
    // Handle login bonus and streak
    const today = new Date().toISOString().split('T')[0]
    const lastLogin = userData.lastLoginDate
    
    let bonusXP = 0
    let bonusMessage = ""
    
    if (!lastLogin) {
      // First time login
      bonusXP = 50
      bonusMessage = "Welcome bonus!"
      userData.stats.streak = 1
    } else {
      const lastLoginDate = new Date(lastLogin).toISOString().split('T')[0]
      const daysDiff = Math.floor((new Date(today).getTime() - new Date(lastLoginDate).getTime()) / (1000 * 60 * 60 * 24))
      
      if (daysDiff === 1) {
        // Consecutive day login
        userData.stats.streak += 1
        bonusXP = Math.min(10 + (userData.stats.streak * 2), 50) // Increasing bonus, max 50
        bonusMessage = `Day ${userData.stats.streak} bonus!`
        
        // Special milestone bonuses
        if (userData.stats.streak === 7) {
          bonusXP += 100
          bonusMessage = "🎉 Week streak milestone! +100 bonus XP!"
        } else if (userData.stats.streak === 15) {
          bonusXP += 250
          bonusMessage = "🏆 15-day streak champion! +250 bonus XP!"
        } else if (userData.stats.streak === 30) {
          bonusXP += 500
          bonusMessage = "👑 Monthly master! +500 bonus XP!"
        } else if (userData.stats.streak % 15 === 0 && userData.stats.streak > 15) {
          bonusXP += 200
          bonusMessage = `🔥 ${userData.stats.streak}-day streak legend! +200 bonus XP!`
        }
      } else if (daysDiff === 0) {
        // Same day login - no bonus
        bonusXP = 0
        bonusMessage = ""
      } else {
        // Streak broken
        userData.stats.streak = 1
        bonusXP = 10
        bonusMessage = "Daily login bonus"
      }
    }
    
    // Apply XP bonus
    if (bonusXP > 0) {
      userData.stats.xp += bonusXP
      userData.stats.totalXp += bonusXP
      
      // Level up check
      const xpNeeded = userData.stats.level * 100
      while (userData.stats.xp >= xpNeeded) {
        userData.stats.xp -= xpNeeded
        userData.stats.level += 1
      }
      
      // Store login bonus info for display
      userData.loginBonus = {
        xp: bonusXP,
        message: bonusMessage,
        streak: userData.stats.streak
      }
    }
    
    userData.lastLoginDate = new Date().toISOString()
    
    // Save updated user data
    existingUsers[email] = userData
    localStorage.setItem("users", JSON.stringify(existingUsers))
    
    setUser(userData)
    localStorage.setItem("currentUser", JSON.stringify(userData))
    setIsLoading(false)
    return true
  }

  const register = async (userData: any): Promise<boolean> => {
    setIsLoading(true)
    
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    const newUser: User = {
      id: `user-${Date.now()}`,
      email: userData.email,
      username: userData.username,
      firstName: userData.firstName,
      lastName: userData.lastName,
      dateOfBirth: "",
      phoneNumber: "",
      gender: "prefer-not-to-say",
      profession: "",
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      preferences: {
        theme: "dark",
        gameTheme: "fantasy",
        timeManagement: "pomodoro",
        intensity: "moderate",
        notifications: true,
        sounds: true,
        motivationalContent: "music"
      },
      avatar: defaultAvatars,
      stats: {
        level: 1,
        xp: 0,
        totalXp: 0,
        streak: 0,
        tasksCompleted: 0,
        weeklyXp: 0,
        monthlyXp: 0,
        yearlyXp: 0
      },
      lastLoginDate: null,
      onboardingCompleted: false,
      createdAt: new Date().toISOString()
    }
    
    const existingUsers = JSON.parse(localStorage.getItem("users") || "{}")
    existingUsers[userData.email] = newUser
    localStorage.setItem("users", JSON.stringify(existingUsers))
    
    setUser(newUser)
    localStorage.setItem("currentUser", JSON.stringify(newUser))
    setIsLoading(false)
    return true
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("currentUser")
  }

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates }
      setUser(updatedUser)
      localStorage.setItem("currentUser", JSON.stringify(updatedUser))
      
      const existingUsers = JSON.parse(localStorage.getItem("users") || "{}")
      existingUsers[user.email] = updatedUser
      localStorage.setItem("users", JSON.stringify(existingUsers))
    }
  }

  return (
    <AuthContext.Provider value={{ user, login, register, logout, updateUser, isLoading }}>
      {children}
    </AuthContext.Provider>
  )
}
