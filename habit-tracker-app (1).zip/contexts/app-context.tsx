"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useAuth } from "@/contexts/auth-context"

interface Quest {
  id: string
  title: string
  xp: number
  completed: boolean
}

interface Quests {
  main: Quest[]
  side: Quest[]
  mini: Quest[]
}

interface LongTermGoal {
  id: string
  title: string
  description: string
  targetDate: string
  progress: number
  subtasks: Quest[]
  createdAt: string
}

interface AppContextType {
  quests: Quests
  toggleQuest: (category: keyof Quests, id: string) => void
  deleteQuest: (category: keyof Quests, id: string) => void
  addTask: (category: keyof Quests, title: string) => Quest
  prioritizeWithAI: () => void
  breakdownQuestWithAI: (mainQuestTitle: string) => Promise<void>
  showJournalPrompt: boolean
  setShowJournalPrompt: (show: boolean) => void
  completedQuestTitle: string
  isLoading: boolean
  longTermGoals: LongTermGoal[]
  addLongTermGoal: (goal: Omit<LongTermGoal, "id" | "createdAt" | "subtasks" | "progress">) => void
  generateSubtasksForGoal: (goalId: string) => Promise<void>
  addSubtaskToTasks: (subtask: Quest, category: keyof Quests) => void
  updateGoalProgress: (goalId: string) => void
  user: any
  updateUser: (user: any) => void
  updateDailyQuestProgress: (increment: number) => void
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export const useApp = () => {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error("useApp must be used within an AppProvider")
  }
  return context
}

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [quests, setQuests] = useState<Quests>({
    main: [],
    side: [],
    mini: []
  })
  const [showJournalPrompt, setShowJournalPrompt] = useState(false)
  const [completedQuestTitle, setCompletedQuestTitle] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [longTermGoals, setLongTermGoals] = useState<LongTermGoal[]>([])

  const { user, updateUser } = useAuth()

  // Initialize tasks based on user's AI generated tasks or default tasks
  useEffect(() => {
    if (user) {
      if (user.aiGeneratedTasks) {
        // Use AI generated tasks for new users
        setQuests(user.aiGeneratedTasks)
      } else if (user.onboardingCompleted) {
        // Use default tasks for existing users
        const defaultQuests: Quests = {
          main: [
            { id: "m1", title: "Study for Exam", xp: 150, completed: false },
            { id: "m2", title: "Build Project Prototype", xp: 200, completed: false },
            { id: "m3", title: "Complete Week 1 of Fitness Plan", xp: 100, completed: true },
          ],
          side: [
            { id: "s1", title: "Organize digital files", xp: 40, completed: false },
            { id: "s2", title: "Read one chapter of a book", xp: 30, completed: true },
            { id: "s3", title: "Research new productivity tools", xp: 50, completed: false },
          ],
          mini: [
            { id: "mi1", title: "5-minute meditation", xp: 10, completed: true },
            { id: "mi2", title: "Tidy up workspace", xp: 10, completed: true },
            { id: "mi3", title: "Drink a glass of water", xp: 5, completed: false },
            { id: "mi4", title: "Stretch for 2 minutes", xp: 5, completed: false },
          ],
        }
        setQuests(defaultQuests)
      }
    }
  }, [user])

  const updateDailyQuestProgress = (increment: number) => {
    // Update daily quest progress in localStorage
    const today = new Date().toISOString().split('T')[0]
    const savedQuest = localStorage.getItem(`dailyQuest_${today}`)
    
    if (savedQuest) {
      const quest = JSON.parse(savedQuest)
      if (!quest.isCompleted && !quest.isFailed && quest.isActive) {
        quest.currentCount = Math.min(quest.currentCount + increment, quest.targetCount)
        
        // Calculate current XP based on progress
        const progressRatio = quest.currentCount / quest.targetCount
        quest.currentXP = Math.floor(quest.xpReward * progressRatio)

        // Check if completed
        if (quest.currentCount >= quest.targetCount) {
          quest.isCompleted = true
          quest.isActive = false
          quest.currentXP = quest.xpReward

          // Award XP to user
          if (user) {
            const newStats = { ...user.stats }
            newStats.xp += quest.xpReward
            newStats.totalXp += quest.xpReward

            // Level up check
            const xpNeeded = newStats.level * 100
            while (newStats.xp >= xpNeeded) {
              newStats.xp -= xpNeeded
              newStats.level += 1
            }

            updateUser({ stats: newStats })
          }
        }

        localStorage.setItem(`dailyQuest_${today}`, JSON.stringify(quest))
      }
    }
  }

  const toggleQuest = (category: keyof Quests, id: string) => {
    let questTitle = ""
    let questXP = 0
    const isCompleting = !quests[category].find((q) => q.id === id)?.completed

    setQuests((prev) => {
      const updatedQuests = {
        ...prev,
        [category]: prev[category].map((q) => {
          if (q.id === id) {
            if (isCompleting && category === "main") {
              questTitle = q.title
              // Update daily quest progress for main quests
              updateDailyQuestProgress(1)
            }
            if (isCompleting) {
              questXP = q.xp
            }
            return { ...q, completed: !q.completed }
          }
          return q
        }),
      }
      return updatedQuests
    })

    // Award XP when completing a quest
    if (isCompleting && questXP > 0) {
      const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
      if (currentUser.stats) {
        currentUser.stats.xp += questXP
        currentUser.stats.totalXp += questXP
        currentUser.stats.tasksCompleted += 1
        
        // Level up check
        const xpNeeded = currentUser.stats.level * 100
        while (currentUser.stats.xp >= xpNeeded) {
          currentUser.stats.xp -= xpNeeded
          currentUser.stats.level += 1
        }
        
        // Update user in all storage locations
        localStorage.setItem("currentUser", JSON.stringify(currentUser))
        const allUsers = JSON.parse(localStorage.getItem("users") || "{}")
        allUsers[currentUser.email] = currentUser
        localStorage.setItem("users", JSON.stringify(allUsers))
        
        // Trigger a re-render by updating the user context if available
        if (typeof updateUser === 'function') {
          updateUser(currentUser)
        }
      }
    }

    if (questTitle) {
      setCompletedQuestTitle(questTitle)
      setShowJournalPrompt(true)
    }
  }

  const deleteQuest = (category: keyof Quests, id: string) => {
    setQuests((prev) => ({
      ...prev,
      [category]: prev[category].filter((q) => q.id !== id),
    }))
  }

  const addTask = (category: keyof Quests, title: string): Quest => {
    const newQuest: Quest = {
      id: `${category}-${Date.now()}`,
      title,
      xp: category === "main" ? 100 : category === "side" ? 40 : 10,
      completed: false,
    }
    setQuests((prev) => ({ ...prev, [category]: [...prev[category], newQuest] }))
    return newQuest
  }

  const prioritizeWithAI = () => {
    setQuests((prev) => {
      const reorderedMain = [...prev.main].sort((a, b) => Number(a.completed) - Number(b.completed))
      const reorderedSide = [...prev.side].sort((a, b) => Number(a.completed) - Number(b.completed))
      return { ...prev, main: reorderedMain, side: reorderedSide }
    })
  }

  const breakdownQuestWithAI = async (mainQuestTitle: string) => {
    setIsLoading(true)

    // Simulate AI response for demo purposes
    // In production, you would integrate with your preferred AI service
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000)) // Simulate API call

      const mockSideQuests = [`Research requirements for ${mainQuestTitle}`, `Create action plan for ${mainQuestTitle}`]

      const mockMiniTasks = [
        "Set up workspace",
        "Gather necessary materials",
        "Schedule focused work time",
        "Review progress checklist",
      ]

      const newSideQuests = mockSideQuests.map((title) => ({
        id: `s-${Date.now()}-${Math.random()}`,
        title,
        xp: 40,
        completed: false,
      }))

      const newMiniTasks = mockMiniTasks.map((title) => ({
        id: `mi-${Date.now()}-${Math.random()}`,
        title,
        xp: 10,
        completed: false,
      }))

      setQuests((prev) => ({
        ...prev,
        side: [...prev.side, ...newSideQuests],
        mini: [...prev.mini, ...newMiniTasks],
      }))
    } catch (error) {
      console.error("Error breaking down quest:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const addLongTermGoal = (goal: Omit<LongTermGoal, "id" | "createdAt" | "subtasks" | "progress">) => {
    const newGoal: LongTermGoal = {
      ...goal,
      id: `goal-${Date.now()}`,
      createdAt: new Date().toISOString(),
      subtasks: [],
      progress: 0,
    }
    setLongTermGoals((prev) => [...prev, newGoal])
  }

  const generateSubtasksForGoal = async (goalId: string) => {
    setIsLoading(true)

    const goal = longTermGoals.find((g) => g.id === goalId)
    if (!goal) return

    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      const mockSubtasks = [
        `Research best practices for ${goal.title}`,
        `Create detailed plan for ${goal.title}`,
        `Set up necessary tools and resources`,
        `Break down ${goal.title} into weekly milestones`,
        `Identify potential obstacles and solutions`,
        `Schedule regular progress reviews`,
      ]

      const generatedSubtasks: Quest[] = mockSubtasks.slice(0, 4).map((title, index) => ({
        id: `subtask-${goalId}-${Date.now()}-${index}`,
        title,
        xp: 50,
        completed: false,
      }))

      setLongTermGoals((prev) =>
        prev.map((g) => (g.id === goalId ? { ...g, subtasks: [...g.subtasks, ...generatedSubtasks] } : g)),
      )
    } catch (error) {
      console.error("Error generating subtasks:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const addSubtaskToTasks = (subtask: Quest, category: keyof Quests) => {
    setQuests((prev) => ({
      ...prev,
      [category]: [...prev[category], subtask],
    }))
  }

  const updateGoalProgress = (goalId: string) => {
    setLongTermGoals((prev) =>
      prev.map((goal) => {
        if (goal.id === goalId) {
          const completedSubtasks = goal.subtasks.filter((st) => st.completed).length
          const progress = goal.subtasks.length > 0 ? (completedSubtasks / goal.subtasks.length) * 100 : 0
          return { ...goal, progress }
        }
        return goal
      }),
    )
  }

  const value = {
    quests,
    toggleQuest,
    deleteQuest,
    addTask,
    prioritizeWithAI,
    breakdownQuestWithAI,
    showJournalPrompt,
    setShowJournalPrompt,
    completedQuestTitle,
    isLoading,
    longTermGoals,
    addLongTermGoal,
    generateSubtasksForGoal,
    addSubtaskToTasks,
    updateGoalProgress,
    user,
    updateUser,
    updateDailyQuestProgress,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}
