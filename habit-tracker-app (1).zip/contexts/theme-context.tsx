"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useAuth } from "@/contexts/auth-context"

interface ThemeContextType {
  theme: string
  setTheme: (theme: string) => void
  themes: Record<string, any>
  gameTheme: string
  setGameTheme: (theme: string) => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export const useTheme = () => {
  const context = useContext(ThemeContext)
  if (!context) {
    return {
      theme: "indigo",
      setTheme: () => {},
      themes: getThemeClasses("fantasy"),
      gameTheme: "fantasy",
      setGameTheme: () => {}
    }
  }
  return context
}

const getThemeClasses = (gameTheme: string) => {
  const baseThemes = {
    fantasy: {
      indigo: {
        bg: "bg-gradient-to-br from-purple-900 via-indigo-900 to-gray-900",
        cardBg: "bg-gradient-to-br from-purple-800/30 to-indigo-800/30",
        primary: "bg-purple-600",
        hover: "hover:bg-purple-500",
        text: "text-purple-400",
        border: "border-purple-700/50",
        ring: "focus:ring-purple-400",
        accent: "text-yellow-400"
      },
      teal: {
        bg: "bg-gradient-to-br from-emerald-900 via-teal-900 to-gray-900",
        cardBg: "bg-gradient-to-br from-emerald-800/30 to-teal-800/30",
        primary: "bg-emerald-600",
        hover: "hover:bg-emerald-500",
        text: "text-emerald-400",
        border: "border-emerald-700/50",
        ring: "focus:ring-emerald-400",
        accent: "text-amber-400"
      },
      crimson: {
        bg: "bg-gradient-to-br from-red-900 via-rose-900 to-gray-900",
        cardBg: "bg-gradient-to-br from-red-800/30 to-rose-800/30",
        primary: "bg-red-600",
        hover: "hover:bg-red-500",
        text: "text-red-400",
        border: "border-red-700/50",
        ring: "focus:ring-red-400",
        accent: "text-orange-400"
      }
    },
    "sci-fi": {
      indigo: {
        bg: "bg-gradient-to-br from-slate-900 via-blue-900 to-black",
        cardBg: "bg-gradient-to-br from-slate-800/30 to-blue-800/30",
        primary: "bg-cyan-600",
        hover: "hover:bg-cyan-500",
        text: "text-cyan-400",
        border: "border-cyan-700/50",
        ring: "focus:ring-cyan-400",
        accent: "text-blue-400"
      },
      teal: {
        bg: "bg-gradient-to-br from-gray-900 via-teal-900 to-black",
        cardBg: "bg-gradient-to-br from-gray-800/30 to-teal-800/30",
        primary: "bg-teal-600",
        hover: "hover:bg-teal-500",
        text: "text-teal-400",
        border: "border-teal-700/50",
        ring: "focus:ring-teal-400",
        accent: "text-green-400"
      },
      crimson: {
        bg: "bg-gradient-to-br from-gray-900 via-red-900 to-black",
        cardBg: "bg-gradient-to-br from-gray-800/30 to-red-800/30",
        primary: "bg-red-600",
        hover: "hover:bg-red-500",
        text: "text-red-400",
        border: "border-red-700/50",
        ring: "focus:ring-red-400",
        accent: "text-pink-400"
      }
    },
    minimal: {
      indigo: {
        bg: "bg-gray-50",
        cardBg: "bg-white",
        primary: "bg-gray-900",
        hover: "hover:bg-gray-800",
        text: "text-gray-700",
        border: "border-gray-200",
        ring: "focus:ring-gray-400",
        accent: "text-indigo-600"
      },
      teal: {
        bg: "bg-gray-50",
        cardBg: "bg-white",
        primary: "bg-teal-600",
        hover: "hover:bg-teal-700",
        text: "text-teal-700",
        border: "border-gray-200",
        ring: "focus:ring-teal-400",
        accent: "text-teal-600"
      },
      crimson: {
        bg: "bg-gray-50",
        cardBg: "bg-white",
        primary: "bg-red-600",
        hover: "hover:bg-red-700",
        text: "text-red-700",
        border: "border-gray-200",
        ring: "focus:ring-red-400",
        accent: "text-red-600"
      }
    },
    nature: {
      indigo: {
        bg: "bg-gradient-to-br from-green-900 via-emerald-900 to-teal-900",
        cardBg: "bg-gradient-to-br from-green-800/30 to-emerald-800/30",
        primary: "bg-green-600",
        hover: "hover:bg-green-500",
        text: "text-green-400",
        border: "border-green-700/50",
        ring: "focus:ring-green-400",
        accent: "text-yellow-400"
      },
      teal: {
        bg: "bg-gradient-to-br from-teal-900 via-cyan-900 to-blue-900",
        cardBg: "bg-gradient-to-br from-teal-800/30 to-cyan-800/30",
        primary: "bg-teal-600",
        hover: "hover:bg-teal-500",
        text: "text-teal-400",
        border: "border-teal-700/50",
        ring: "focus:ring-teal-400",
        accent: "text-cyan-400"
      },
      crimson: {
        bg: "bg-gradient-to-br from-orange-900 via-red-900 to-pink-900",
        cardBg: "bg-gradient-to-br from-orange-800/30 to-red-800/30",
        primary: "bg-orange-600",
        hover: "hover:bg-orange-500",
        text: "text-orange-400",
        border: "border-orange-700/50",
        ring: "focus:ring-orange-400",
        accent: "text-yellow-400"
      }
    }
  }

  return baseThemes[gameTheme as keyof typeof baseThemes] || baseThemes.fantasy
}

export const ThemeProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth()
  const [theme, setTheme] = useState("indigo")
  const [gameTheme, setGameTheme] = useState("fantasy")

  useEffect(() => {
    if (user?.preferences) {
      setGameTheme(user.preferences.gameTheme)
    }
  }, [user])

  const themeClasses = getThemeClasses(gameTheme)
  const validTheme = themeClasses[theme as keyof typeof themeClasses] ? theme : "indigo"

  return (
    <ThemeContext.Provider value={{ 
      theme: validTheme, 
      setTheme, 
      themes: themeClasses, 
      gameTheme, 
      setGameTheme 
    }}>
      {children}
    </ThemeContext.Provider>
  )
}
