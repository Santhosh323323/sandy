"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useAuth } from "@/contexts/auth-context"

interface DailyQuest {
  id: string
  title: string
  description: string
  targetCount: number
  currentCount: number
  xpReward: number
  currentXP: number
  timeLimit: number // in hours
  startTime: string
  endTime: string
  isActive: boolean
  isCompleted: boolean
  isFailed: boolean
}

interface DailyQuestContextType {
  dailyQuest: DailyQuest | null
  updateQuestProgress: (increment: number) => void
  checkQuestStatus: () => void
  resetDailyQuest: () => void
  getTimeRemaining: () => number
}

const DailyQuestContext = createContext<DailyQuestContextType | undefined>(undefined)

export const useDailyQuest = () => {
  const context = useContext(DailyQuestContext)
  if (!context) {
    throw new Error("useDailyQuest must be used within a DailyQuestProvider")
  }
  return context
}

export const DailyQuestProvider = ({ children }: { children: ReactNode }) => {
  const { user, updateUser } = useAuth()
  const [dailyQuest, setDailyQuest] = useState<DailyQuest | null>(null)

  // Initialize or reset daily quest
  useEffect(() => {
    if (user) {
      const today = new Date().toISOString().split('T')[0]
      const savedQuest = localStorage.getItem(`dailyQuest_${today}`)
      
      if (savedQuest) {
        const quest = JSON.parse(savedQuest)
        setDailyQuest(quest)
      } else {
        // Create new daily quest
        const newQuest: DailyQuest = {
          id: `daily_${today}`,
          title: "Daily Quest Challenge",
          description: "Complete 3 Main Quests before sunset",
          targetCount: 3,
          currentCount: 0,
          xpReward: 50,
          currentXP: 0,
          timeLimit: 18, // 18 hours from start
          startTime: new Date().toISOString(),
          endTime: new Date(Date.now() + 18 * 60 * 60 * 1000).toISOString(),
          isActive: true,
          isCompleted: false,
          isFailed: false
        }
        setDailyQuest(newQuest)
        localStorage.setItem(`dailyQuest_${today}`, JSON.stringify(newQuest))
      }
    }
  }, [user])

  // Check quest status every minute
  useEffect(() => {
    const interval = setInterval(() => {
      checkQuestStatus()
    }, 60000) // Check every minute

    return () => clearInterval(interval)
  }, [dailyQuest])

  const updateQuestProgress = (increment: number) => {
    if (!dailyQuest || dailyQuest.isCompleted || dailyQuest.isFailed) return

    const updatedQuest = {
      ...dailyQuest,
      currentCount: Math.min(dailyQuest.currentCount + increment, dailyQuest.targetCount)
    }

    // Calculate current XP based on progress
    const progressRatio = updatedQuest.currentCount / updatedQuest.targetCount
    updatedQuest.currentXP = Math.floor(updatedQuest.xpReward * progressRatio)

    // Check if completed
    if (updatedQuest.currentCount >= updatedQuest.targetCount) {
      updatedQuest.isCompleted = true
      updatedQuest.isActive = false
      updatedQuest.currentXP = updatedQuest.xpReward

      // Award XP to user
      if (user) {
        const newStats = { ...user.stats }
        newStats.xp += updatedQuest.xpReward
        newStats.totalXp += updatedQuest.xpReward

        // Level up check
        const xpNeeded = newStats.level * 100
        while (newStats.xp >= xpNeeded) {
          newStats.xp -= xpNeeded
          newStats.level += 1
        }

        updateUser({ stats: newStats })
      }
    }

    setDailyQuest(updatedQuest)
    const today = new Date().toISOString().split('T')[0]
    localStorage.setItem(`dailyQuest_${today}`, JSON.stringify(updatedQuest))
  }

  const checkQuestStatus = () => {
    if (!dailyQuest || dailyQuest.isCompleted || dailyQuest.isFailed) return

    const now = new Date()
    const endTime = new Date(dailyQuest.endTime)

    if (now > endTime) {
      // Quest failed - reduce XP
      const failedQuest = {
        ...dailyQuest,
        isFailed: true,
        isActive: false,
        currentXP: 0
      }

      // Reduce user XP by 25% of the quest reward
      if (user) {
        const xpPenalty = Math.floor(dailyQuest.xpReward * 0.25)
        const newStats = { ...user.stats }
        newStats.xp = Math.max(0, newStats.xp - xpPenalty)
        newStats.totalXp = Math.max(0, newStats.totalXp - xpPenalty)

        updateUser({ stats: newStats })
      }

      setDailyQuest(failedQuest)
      const today = new Date().toISOString().split('T')[0]
      localStorage.setItem(`dailyQuest_${today}`, JSON.stringify(failedQuest))
    }
  }

  const getTimeRemaining = (): number => {
    if (!dailyQuest) return 0
    const now = new Date()
    const endTime = new Date(dailyQuest.endTime)
    return Math.max(0, endTime.getTime() - now.getTime())
  }

  const resetDailyQuest = () => {
    const today = new Date().toISOString().split('T')[0]
    localStorage.removeItem(`dailyQuest_${today}`)
    setDailyQuest(null)
  }

  return (
    <DailyQuestContext.Provider value={{
      dailyQuest,
      updateQuestProgress,
      checkQuestStatus,
      resetDailyQuest,
      getTimeRemaining
    }}>
      {children}
    </DailyQuestContext.Provider>
  )
}
