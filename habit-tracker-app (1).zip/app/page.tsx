"use client"

import { useState, useEffect } from "react"
import LoginPage from "@/components/auth/login-page"
import OnboardingFlow from "@/components/auth/onboarding-flow"
import HabitTrackerApp from "@/components/habit-tracker-app"
import SplashScreen from "@/components/ui/splash-screen"
import { AuthProvider, useAuth } from "@/contexts/auth-context"
import LoadingScreen from "@/components/ui/loading-screen"

function AppContent() {
  const { user, isLoading } = useAuth()
  const [showOnboarding, setShowOnboarding] = useState(false)
  const [showSplash, setShowSplash] = useState(true)

  useEffect(() => {
    if (user && !user.onboardingCompleted) {
      setShowOnboarding(true)
    }
  }, [user])

  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />
  }

  if (isLoading) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoginPage />
  }

  if (showOnboarding) {
    return <OnboardingFlow onComplete={() => setShowOnboarding(false)} />
  }

  return <HabitTrackerApp />
}

export default function Home() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  )
}
