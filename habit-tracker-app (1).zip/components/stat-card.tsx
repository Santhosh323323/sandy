import React from "react"

interface StatCardProps {
  icon: React.ReactElement
  label: string
  value: string
  color: string
}

export default function StatCard({ icon, label, value, color }: StatCardProps) {
  return (
    <div className="bg-gray-800/60 p-3 rounded-xl border border-gray-700">
      <div className={`mx-auto h-8 w-8 flex items-center justify-center ${color}`}>
        {React.cloneElement(icon, { size: 24 })}
      </div>
      <p className="text-sm font-semibold mt-2">{value}</p>
      <p className="text-xs text-gray-400">{label}</p>
    </div>
  )
}
