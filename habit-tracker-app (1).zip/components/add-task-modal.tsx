"use client"

import { useState } from "react"
import { useApp } from "@/contexts/app-context"
import { Sparkles } from "lucide-react"

interface AddTaskModalProps {
  category: "main" | "side" | "mini"
  onClose: () => void
}

export default function AddTaskModal({ category, onClose }: AddTaskModalProps) {
  const [title, setTitle] = useState("")
  const { addTask, breakdownQuestWithAI } = useApp()

  const handleAdd = () => {
    if (title.trim()) {
      addTask(category, title.trim())
      onClose()
    }
  }

  const handleAddAndBreakdown = () => {
    if (title.trim()) {
      const newQuest = addTask(category, title.trim())
      breakdownQuestWithAI(newQuest.title)
      onClose()
    }
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-gray-800 p-6 rounded-xl w-11/12 max-w-md border border-indigo-700">
        <h2 className="text-xl font-bold mb-4 capitalize">Add New {category} Quest</h2>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter quest title..."
          className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 mb-4 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-400 focus:outline-none"
        />
        <div className="flex flex-col gap-3">
          <button
            onClick={handleAdd}
            className="w-full px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 font-semibold"
          >
            Add Quest
          </button>
          {category === "main" && (
            <button
              onClick={handleAddAndBreakdown}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-teal-600 hover:bg-teal-500 font-semibold"
            >
              <Sparkles size={18} /> Add & Breakdown with AI
            </button>
          )}
          <button type="button" onClick={onClose} className="w-full px-4 py-2 rounded-lg bg-gray-600 hover:bg-gray-500">
            Cancel
          </button>
        </div>
      </div>
    </div>
  )
}
