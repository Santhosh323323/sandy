"use client"

import { useState } from "react"
import { useTheme } from "@/contexts/theme-context"

interface Message {
  from: "user" | "ai"
  text: string
}

export default function AICoach() {
  const { theme, themes } = useTheme()
  const [prompt, setPrompt] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    { from: "ai", text: "Hello! I'm your AI coach. How can I help you be more productive today?" },
  ])
  const [isThinking, setIsThinking] = useState(false)
  const currentTheme = themes[theme]

  const handleSendPrompt = async () => {
    if (!prompt.trim() || isThinking) return

    const userMessage: Message = { from: "user", text: prompt }
    setMessages((prev) => [...prev, userMessage])
    setPrompt("")
    setIsThinking(true)

    // Simulate AI response for demo purposes
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      const responses = [
        "That's a great question! Let me help you break that down into manageable steps.",
        "I understand your challenge. Here's what I recommend based on productivity research...",
        "Excellent goal! Let's create a strategy that works with your current habits.",
        "I can see you're motivated to improve. Here are some evidence-based techniques...",
        "That's a common struggle. Let me share some approaches that have helped others...",
      ]

      const randomResponse = responses[Math.floor(Math.random() * responses.length)]
      const aiMessage: Message = { from: "ai", text: randomResponse }
      setMessages((prev) => [...prev, aiMessage])
    } catch (error) {
      console.error("Error with AI Coach:", error)
      setMessages((prev) => [...prev, { from: "ai", text: "I'm having trouble connecting. Please try again." }])
    } finally {
      setIsThinking(false)
    }
  }

  return (
    <div className="animate-fade-in flex flex-col h-full max-h-[80vh]">
      <h1 className="text-2xl font-bold mb-4">AI Coach</h1>
      <div className="flex-grow space-y-4 overflow-y-auto p-2 bg-gray-800/50 rounded-lg">
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.from === "user" ? "justify-end" : "justify-start"}`}>
            <p
              className={`max-w-xs md:max-w-md p-3 rounded-2xl ${
                msg.from === "user" ? "bg-indigo-600 rounded-br-none" : "bg-gray-700 rounded-bl-none"
              }`}
            >
              {msg.text}
            </p>
          </div>
        ))}
        {isThinking && (
          <div className="flex justify-start">
            <p className="max-w-xs md:max-w-md p-3 rounded-2xl bg-gray-700 rounded-bl-none animate-pulse">
              Thinking...
            </p>
          </div>
        )}
      </div>
      <div className="mt-4 flex gap-2">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSendPrompt()}
          placeholder="Ask your coach..."
          className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-400 focus:outline-none"
        />
        <button
          onClick={handleSendPrompt}
          disabled={isThinking}
          className={`px-4 py-2 rounded-lg ${currentTheme.primary} ${currentTheme.hover} font-semibold disabled:opacity-50`}
        >
          Send
        </button>
      </div>
    </div>
  )
}
