"use client"

import { useAuth } from "@/contexts/auth-context"
import { useTheme } from "@/contexts/theme-context"
import { BarChart2, User, Calendar, Phone, Mail, MapPin, Briefcase, Settings } from 'lucide-react'

interface ProfilePageProps {
  navigate: (page: string) => void
}

export default function ProfilePage({ navigate }: ProfilePageProps) {
  const { user } = useAuth()
  const { themes, gameTheme } = useTheme()
  const currentTheme = themes?.indigo || {}

  if (!user) return null

  const calculateStats = (questList: any[]) => {
    if (!questList || questList.length === 0) return { completed: 0, total: 0, percentage: 0 }
    const completed = questList.filter((q) => q.completed).length
    const total = questList.length
    const percentage = Math.round((completed / total) * 100)
    return { completed, total, percentage }
  }

  const getAge = (dateOfBirth: string) => {
    if (!dateOfBirth) return null
    const today = new Date()
    const birthDate = new Date(dateOfBirth)
    let age = today.getFullYear() - birthDate.getFullYear()
    const monthDiff = today.getMonth() - birthDate.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--
    }
    return age
  }

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Profile</h1>
        <button
          onClick={() => navigate("settings")}
          className={`flex items-center gap-2 px-4 py-2 ${currentTheme.primary} ${currentTheme.hover} rounded-lg font-semibold transition`}
        >
          <Settings className="w-5 h-5" />
          Settings
        </button>
      </div>

      {/* Profile Header */}
      <div className={`${currentTheme.cardBg} p-6 rounded-xl border ${currentTheme.border} backdrop-blur-sm`}>
        <div className="flex items-center gap-6">
          <div className="relative">
            <div className={`w-20 h-20 ${currentTheme.primary} rounded-full flex items-center justify-center text-2xl font-bold text-white`}>
              {user.firstName?.[0] || user.username[0].toUpperCase()}
            </div>
            <div className={`absolute -bottom-1 -right-1 w-6 h-6 ${currentTheme.accent} rounded-full flex items-center justify-center text-xs font-bold`}>
              {user.stats.level}
            </div>
          </div>
          <div className="flex-grow">
            <h2 className="text-2xl font-bold">
              {user.firstName && user.lastName 
                ? `${user.firstName} ${user.lastName}` 
                : user.username}
            </h2>
            <p className={`${currentTheme.text} mb-2`}>@{user.username}</p>
            <div className="flex items-center gap-4 text-sm">
              <div className={`flex items-center gap-1 ${currentTheme.accent}`}>
                <span>Level {user.stats.level}</span>
                <span>•</span>
                <span>{user.stats.xp}/{user.stats.level * 100} XP</span>
              </div>
              <span className={`${currentTheme.text}`}>
                {user.stats.streak} day streak
              </span>
            </div>
            <div className="mt-3">
              <div className="flex justify-between text-xs text-gray-400 mb-1">
                <span>Progress to Level {user.stats.level + 1}</span>
                <span>{user.stats.xp}/{user.stats.level * 100} XP</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className={`bg-gradient-to-r from-yellow-400 to-orange-500 h-2 rounded-full transition-all duration-500`}
                  style={{ width: `${Math.min((user.stats.xp / (user.stats.level * 100)) * 100, 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Personal Information */}
      <div className={`${currentTheme.cardBg} p-6 rounded-xl border ${currentTheme.border} backdrop-blur-sm`}>
        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
          <User className={currentTheme.text} />
          Personal Information
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center gap-3">
            <Mail className={`${currentTheme.text} w-5 h-5`} />
            <div>
              <p className="text-sm text-gray-400">Email</p>
              <p className="font-semibold">{user.email}</p>
            </div>
          </div>
          
          {user.phoneNumber && (
            <div className="flex items-center gap-3">
              <Phone className={`${currentTheme.text} w-5 h-5`} />
              <div>
                <p className="text-sm text-gray-400">Phone</p>
                <p className="font-semibold">{user.phoneNumber}</p>
              </div>
            </div>
          )}
          
          {user.dateOfBirth && (
            <div className="flex items-center gap-3">
              <Calendar className={`${currentTheme.text} w-5 h-5`} />
              <div>
                <p className="text-sm text-gray-400">Age</p>
                <p className="font-semibold">{getAge(user.dateOfBirth)} years old</p>
              </div>
            </div>
          )}
          
          <div className="flex items-center gap-3">
            <MapPin className={`${currentTheme.text} w-5 h-5`} />
            <div>
              <p className="text-sm text-gray-400">Timezone</p>
              <p className="font-semibold">{user.timezone}</p>
            </div>
          </div>
          
          {user.profession && (
            <div className="flex items-center gap-3">
              <Briefcase className={`${currentTheme.text} w-5 h-5`} />
              <div>
                <p className="text-sm text-gray-400">Profession</p>
                <p className="font-semibold">{user.profession}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Quick Stats */}
      <div className={`${currentTheme.cardBg} p-6 rounded-xl border ${currentTheme.border} backdrop-blur-sm`}>
        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
          <BarChart2 className={currentTheme.text} />
          Quick Stats
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className={`text-2xl font-bold ${currentTheme.accent}`}>{user.stats.tasksCompleted}</div>
            <div className="text-sm text-gray-400">Tasks Completed</div>
          </div>
          <div className="text-center">
            <div className={`text-2xl font-bold ${currentTheme.accent}`}>{user.stats.streak}</div>
            <div className="text-sm text-gray-400">Day Streak</div>
          </div>
          <div className="text-center">
            <div className={`text-2xl font-bold ${currentTheme.accent}`}>{user.stats.level}</div>
            <div className="text-sm text-gray-400">Current Level</div>
          </div>
          <div className="text-center">
            <div className={`text-2xl font-bold ${currentTheme.accent}`}>{user.stats.totalXp}</div>
            <div className="text-sm text-gray-400">Total XP</div>
          </div>
        </div>
      </div>

      {/* Current Avatar */}
      <div className={`${currentTheme.cardBg} p-6 rounded-xl border ${currentTheme.border} backdrop-blur-sm`}>
        <h3 className="font-bold text-lg mb-4">Current Avatar</h3>
        <div className="flex items-center gap-4">
          <div className={`w-16 h-16 ${currentTheme.primary} rounded-full flex items-center justify-center text-2xl`}>
            {user.avatar.find(a => a.equipped)?.name[0] || "K"}
          </div>
          <div>
            <p className="font-semibold">{user.avatar.find(a => a.equipped)?.name || "Knight"}</p>
            <p className="text-sm text-gray-400">Unlocked avatar</p>
          </div>
        </div>
      </div>
    </div>
  )
}
