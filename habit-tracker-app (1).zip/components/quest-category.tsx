"use client"

import React from "react"

interface QuestCategoryProps {
  icon: React.ReactElement
  title: string
  description: string
  count: number
  color: string
  navigate: () => void
}

export default function QuestCategory({ icon, title, description, count, color, navigate }: QuestCategoryProps) {
  return (
    <div
      onClick={navigate}
      className="flex items-center bg-gray-800/60 p-3 rounded-xl border border-gray-700 hover:bg-gray-700/80 transition cursor-pointer"
    >
      <div className={`mr-4 text-${color}-400`}>{React.cloneElement(icon, { size: 28 })}</div>
      <div className="flex-grow">
        <h3 className="font-bold">{title}</h3>
        <p className="text-sm text-gray-400">{description}</p>
      </div>
      <div className="flex items-center gap-2">
        <span className="font-semibold text-lg">{count}</span>
        <span className="text-xs text-gray-500">active</span>
      </div>
    </div>
  )
}
