"use client"

import type React from "react"

import { useState } from "react"
import { useApp } from "@/contexts/app-context"
import { Plus, Target, Calendar, TrendingUp, Sparkles, ArrowRight } from "lucide-react"

export default function LongTermGoalsPage() {
  const { longTermGoals, addLongTermGoal, generateSubtasksForGoal, addSubtaskToTasks, updateGoalProgress } = useApp()
  const [showAddModal, setShowAddModal] = useState(false)

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Long-term Goals</h1>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded-lg font-semibold transition"
        >
          <Plus size={18} />
          Add Goal
        </button>
      </div>

      {longTermGoals.length === 0 ? (
        <div className="text-center py-12">
          <Target className="mx-auto h-16 w-16 text-gray-500 mb-4" />
          <h3 className="text-xl font-semibold mb-2">No Goals Yet</h3>
          <p className="text-gray-400 mb-6">Start by adding your first long-term goal</p>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 rounded-lg font-semibold transition"
          >
            Add Your First Goal
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {longTermGoals.map((goal) => (
            <GoalCard
              key={goal.id}
              goal={goal}
              onGenerateSubtasks={generateSubtasksForGoal}
              onAddSubtaskToTasks={addSubtaskToTasks}
              onUpdateProgress={updateGoalProgress}
            />
          ))}
        </div>
      )}

      {showAddModal && <AddGoalModal onClose={() => setShowAddModal(false)} onAdd={addLongTermGoal} />}
    </div>
  )
}

interface GoalCardProps {
  goal: any
  onGenerateSubtasks: (goalId: string) => Promise<void>
  onAddSubtaskToTasks: (subtask: any, category: "main" | "side" | "mini") => void
  onUpdateProgress: (goalId: string) => void
}

const GoalCard = ({ goal, onGenerateSubtasks, onAddSubtaskToTasks, onUpdateProgress }: GoalCardProps) => {
  const [showSubtasks, setShowSubtasks] = useState(false)

  const handleAddSubtaskToTasks = (subtask: any, category: "main" | "side" | "mini") => {
    onAddSubtaskToTasks(subtask, category)
    onUpdateProgress(goal.id)
  }

  return (
    <div className="bg-gray-800/60 p-6 rounded-xl border border-gray-700">
      <div className="flex justify-between items-start mb-4">
        <div className="flex-grow">
          <h3 className="text-xl font-bold mb-2">{goal.title}</h3>
          <p className="text-gray-400 mb-3">{goal.description}</p>
          <div className="flex items-center gap-4 text-sm text-gray-500">
            <div className="flex items-center gap-1">
              <Calendar size={16} />
              Target: {new Date(goal.targetDate).toLocaleDateString()}
            </div>
            <div className="flex items-center gap-1">
              <TrendingUp size={16} />
              {Math.round(goal.progress)}% Complete
            </div>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="w-full bg-gray-700 rounded-full h-3">
          <div
            className="bg-gradient-to-r from-purple-500 to-indigo-500 h-3 rounded-full transition-all duration-500"
            style={{ width: `${goal.progress}%` }}
          />
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-3 mb-4">
        <button
          onClick={() => onGenerateSubtasks(goal.id)}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-500 rounded-lg text-sm font-semibold transition"
        >
          <Sparkles size={16} />
          Generate Subtasks
        </button>
        <button
          onClick={() => setShowSubtasks(!showSubtasks)}
          className="flex items-center gap-2 px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded-lg text-sm font-semibold transition"
        >
          {showSubtasks ? "Hide" : "Show"} Subtasks ({goal.subtasks.length})
        </button>
      </div>

      {/* Subtasks */}
      {showSubtasks && (
        <div className="space-y-2 border-t border-gray-700 pt-4">
          <h4 className="font-semibold text-gray-300">Generated Subtasks:</h4>
          {goal.subtasks.length === 0 ? (
            <p className="text-gray-500 text-sm">No subtasks generated yet</p>
          ) : (
            goal.subtasks.map((subtask: any) => (
              <div key={subtask.id} className="flex items-center justify-between bg-gray-700/50 p-3 rounded-lg">
                <span className="flex-grow">{subtask.title}</span>
                <div className="flex items-center gap-2">
                  <select
                    onChange={(e) => {
                      if (e.target.value) {
                        handleAddSubtaskToTasks(subtask, e.target.value as "main" | "side" | "mini")
                        e.target.value = ""
                      }
                    }}
                    className="bg-gray-600 text-white text-xs px-2 py-1 rounded"
                    defaultValue=""
                  >
                    <option value="" disabled>
                      Add to...
                    </option>
                    <option value="main">Main Quest</option>
                    <option value="side">Side Quest</option>
                    <option value="mini">Mini Task</option>
                  </select>
                  <ArrowRight size={16} className="text-gray-400" />
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  )
}

interface AddGoalModalProps {
  onClose: () => void
  onAdd: (goal: any) => void
}

const AddGoalModal = ({ onClose, onAdd }: AddGoalModalProps) => {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [targetDate, setTargetDate] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (title.trim() && description.trim() && targetDate) {
      onAdd({
        title: title.trim(),
        description: description.trim(),
        targetDate,
      })
      onClose()
    }
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-800 p-6 rounded-xl w-11/12 max-w-md border border-indigo-700">
        <h2 className="text-xl font-bold mb-4">Add Long-term Goal</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold mb-2">Goal Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Learn Spanish fluently"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-400 focus:outline-none"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your goal and why it's important to you..."
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-400 focus:outline-none h-24 resize-none"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2">Target Date</label>
            <input
              type="date"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-indigo-400 focus:outline-none"
              required
            />
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded-lg font-semibold transition"
            >
              Add Goal
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded-lg font-semibold transition"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
