import { Sparkles } from "lucide-react"

export default function LoadingSpinner() {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="flex flex-col items-center gap-4">
        <Sparkles className="text-indigo-400 h-12 w-12 animate-spin" />
        <p className="text-lg font-semibold text-white">AI is thinking...</p>
      </div>
    </div>
  )
}
