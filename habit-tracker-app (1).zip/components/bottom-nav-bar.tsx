"use client"

import { useTheme } from "@/contexts/theme-context"
import { Home, ListChecks, Book, Bot, User } from 'lucide-react'

interface BottomNavBarProps {
  activePage: string
  navigate: (page: string) => void
}

export default function BottomNavBar({ activePage, navigate }: BottomNavBarProps) {
  const { themes, gameTheme } = useTheme()
  const currentTheme = themes?.indigo || {}

  const navItems = [
    { id: "home", icon: <Home />, label: "Home" },
    { id: "tasks", icon: <ListChecks />, label: "Tasks" },
    { id: "journal", icon: <Book />, label: "Journal" },
    { id: "coach", icon: <Bot />, label: "AI Coach" },
    { id: "profile", icon: <User />, label: "Profile" },
  ]

  return (
    <div className={`fixed bottom-0 left-0 right-0 ${currentTheme.cardBg} backdrop-blur-sm border-t ${currentTheme.border}`}>
      <div className="flex justify-around items-center h-16">
        {navItems.map((item) => {
          const isActive = activePage === item.id
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className={`flex flex-col items-center justify-center transition-colors duration-200 w-1/5 ${
                isActive ? currentTheme.text : "text-gray-400 hover:text-white"
              }`}
            >
              {item.icon}
              <span className="text-xs mt-1">{item.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
