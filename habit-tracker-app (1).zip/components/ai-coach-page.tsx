"use client"

import { useState, useRef, useEffect } from "react"
import { useTheme } from "@/contexts/theme-context"
import { useApp } from "@/contexts/app-context"
import { Bot, Send, Sparkles, Plus, Lightbulb, Target, Clock, User } from 'lucide-react'

interface Message {
  from: "user" | "ai"
  text: string
  timestamp: Date
  taskSuggestion?: {
    title: string
    category: "main" | "side" | "mini"
    xp: number
  }
}

export default function AICoachPage() {
  const { theme, themes } = useTheme()
  const { addTask } = useApp()
  const [prompt, setPrompt] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    { 
      from: "ai", 
      text: "Hello! I'm your AI productivity coach. I'm here to help you optimize your workflow, break down complex tasks, and stay motivated. How can I assist you today?", 
      timestamp: new Date() 
    },
  ])
  const [isThinking, setIsThinking] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const currentTheme = themes && theme ? themes[theme] : {}

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const generateAIResponse = async (userMessage: string): Promise<Message> => {
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2000))

    const lowerMessage = userMessage.toLowerCase()
    let response = ""
    let taskSuggestion = null

    // Task-related responses
    if (lowerMessage.includes("task") || lowerMessage.includes("todo") || lowerMessage.includes("work")) {
      const taskResponses = [
        "I can help you break that down into manageable steps. Would you like me to create a task for this?",
        "That sounds like something we should add to your task list. Let me suggest a structured approach.",
        "Great idea! I can help you organize this into actionable tasks. Here's what I recommend:",
        "Let's turn this into a concrete action item. I'll suggest a task structure for you."
      ]
      response = taskResponses[Math.floor(Math.random() * taskResponses.length)]
      
      // Generate task suggestion
      const taskTitles = [
        `Research and plan: ${userMessage.split(' ').slice(0, 3).join(' ')}`,
        `Complete: ${userMessage.split(' ').slice(0, 4).join(' ')}`,
        `Work on: ${userMessage.split(' ').slice(0, 3).join(' ')}`,
        `Finish: ${userMessage.split(' ').slice(0, 4).join(' ')}`
      ]
      
      taskSuggestion = {
        title: taskTitles[Math.floor(Math.random() * taskTitles.length)],
        category: Math.random() > 0.6 ? "main" : Math.random() > 0.5 ? "side" : "mini" as "main" | "side" | "mini",
        xp: Math.random() > 0.6 ? 100 : Math.random() > 0.5 ? 40 : 10
      }
    }
    // Productivity advice
    else if (lowerMessage.includes("productive") || lowerMessage.includes("focus") || lowerMessage.includes("motivation")) {
      const productivityTips = [
        "Here are some proven productivity strategies: 1) Use the Pomodoro Technique for focused work sessions, 2) Prioritize your most important tasks in the morning, 3) Take regular breaks to maintain energy levels.",
        "To boost your focus, try eliminating distractions, setting clear goals for each work session, and using time-blocking to dedicate specific hours to specific tasks.",
        "Motivation comes from progress! Break large tasks into smaller wins, celebrate completions, and track your achievements. Remember, consistency beats perfection.",
        "Consider the 2-minute rule: if something takes less than 2 minutes, do it now. For bigger tasks, use the 'Swiss cheese' method - poke holes in the task by doing small parts of it."
      ]
      response = productivityTips[Math.floor(Math.random() * productivityTips.length)]
    }
    // Goal setting
    else if (lowerMessage.includes("goal") || lowerMessage.includes("plan") || lowerMessage.includes("achieve")) {
      const goalResponses = [
        "Setting SMART goals is key! Make sure your goals are Specific, Measurable, Achievable, Relevant, and Time-bound. What specific outcome are you aiming for?",
        "Great that you're thinking about goals! I recommend breaking them into: 1) Long-term vision (1+ years), 2) Medium-term milestones (3-6 months), 3) Short-term actions (weekly/daily).",
        "Goal achievement is about consistent action. Start by identifying the smallest possible step you can take today toward your goal, then build momentum from there.",
        "I love helping with goal planning! Consider using the 'backwards planning' method - start with your end goal and work backwards to identify all the steps needed."
      ]
      response = goalResponses[Math.floor(Math.random() * goalResponses.length)]
    }
    // Time management
    else if (lowerMessage.includes("time") || lowerMessage.includes("schedule") || lowerMessage.includes("busy")) {
      const timeResponses = [
        "Time management is about energy management too! Schedule your most important work during your peak energy hours, and use lower-energy times for routine tasks.",
        "Try time-blocking: assign specific time slots to specific activities. This helps prevent tasks from expanding to fill available time and keeps you focused.",
        "The key to better time management is saying 'no' to non-essential activities. What's one thing you could eliminate or delegate to free up more time?",
        "Consider batching similar tasks together - like answering all emails at once, or doing all your calls in one block. This reduces context switching and improves efficiency."
      ]
      response = timeResponses[Math.floor(Math.random() * timeResponses.length)]
    }
    // General encouragement and advice
    else {
      const generalResponses = [
        "That's an interesting point! I'm here to help you think through challenges and find actionable solutions. What specific aspect would you like to explore further?",
        "I appreciate you sharing that with me. Based on what you've said, I think we could approach this systematically. What's the most important outcome you're hoping for?",
        "Thanks for the context! I'm designed to help you break down complex situations into manageable steps. What feels like the biggest obstacle right now?",
        "I understand. Let's work together to find a practical approach. What resources or support do you currently have available for this?",
        "That makes sense. I find that the best solutions often come from combining your intuition with structured thinking. What does your gut tell you about the next step?"
      ]
      response = generalResponses[Math.floor(Math.random() * generalResponses.length)]
    }

    return {
      from: "ai",
      text: response,
      timestamp: new Date(),
      taskSuggestion
    }
  }

  const handleSendPrompt = async () => {
    if (!prompt.trim() || isThinking) return

    const userMessage: Message = { from: "user", text: prompt, timestamp: new Date() }
    setMessages(prev => [...prev, userMessage])
    setPrompt("")
    setIsThinking(true)

    try {
      const aiResponse = await generateAIResponse(prompt)
      setMessages(prev => [...prev, aiResponse])
    } catch (error) {
      console.error("Error with AI Coach:", error)
      setMessages(prev => [...prev, { 
        from: "ai", 
        text: "I'm having trouble processing that right now. Please try again in a moment.", 
        timestamp: new Date() 
      }])
    } finally {
      setIsThinking(false)
    }
  }

  const handleAddTask = (taskSuggestion: any) => {
    addTask(taskSuggestion.category, taskSuggestion.title)
    // Update the message to show task was added
    setMessages(prev => prev.map(msg => 
      msg.taskSuggestion === taskSuggestion 
        ? { ...msg, taskSuggestion: { ...taskSuggestion, added: true } }
        : msg
    ))
  }

  const quickPrompts = [
    "Help me prioritize my tasks",
    "I'm feeling overwhelmed",
    "How can I stay motivated?",
    "Break down a complex project",
    "Time management tips",
    "Set better goals"
  ]

  return (
    <div className="animate-fade-in flex flex-col h-full max-h-[85vh]">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <div className={`w-12 h-12 ${currentTheme.primary || 'bg-indigo-600'} rounded-full flex items-center justify-center`}>
          <Bot className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">AI Productivity Coach</h1>
          <p className="text-gray-400">Your personal assistant for better productivity</p>
        </div>
      </div>

      {/* Quick Prompts */}
      <div className="mb-4">
        <h3 className="text-sm font-semibold text-gray-400 mb-2">Quick Suggestions:</h3>
        <div className="flex flex-wrap gap-2">
          {quickPrompts.map((quickPrompt, index) => (
            <button
              key={index}
              onClick={() => setPrompt(quickPrompt)}
              className="text-xs bg-gray-700 hover:bg-gray-600 px-3 py-1 rounded-full transition"
            >
              {quickPrompt}
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-grow space-y-4 overflow-y-auto p-4 bg-gray-800/30 rounded-lg border border-gray-700">
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.from === "user" ? "justify-end" : "justify-start"}`}>
            <div className="max-w-[80%]">
              <div className={`p-4 rounded-2xl ${
                msg.from === "user" 
                  ? `${currentTheme.primary || 'bg-indigo-600'} text-white rounded-br-none` 
                  : "bg-gray-700 text-white rounded-bl-none"
              }`}>
                {msg.from === "ai" && (
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    <span className="text-xs text-purple-400 font-semibold">AI Coach</span>
                  </div>
                )}
                <p className="text-sm leading-relaxed">{msg.text}</p>
                
                {/* Task Suggestion */}
                {msg.taskSuggestion && !msg.taskSuggestion.added && (
                  <div className="mt-3 p-3 bg-gray-600/50 rounded-lg border border-gray-600">
                    <div className="flex items-center gap-2 mb-2">
                      <Target className="w-4 h-4 text-green-400" />
                      <span className="text-xs font-semibold text-green-400">Suggested Task</span>
                    </div>
                    <div className="text-sm mb-2">{msg.taskSuggestion.title}</div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <span className="capitalize">{msg.taskSuggestion.category} Quest</span>
                        <span>•</span>
                        <span>+{msg.taskSuggestion.xp} XP</span>
                      </div>
                      <button
                        onClick={() => handleAddTask(msg.taskSuggestion)}
                        className="flex items-center gap-1 text-xs bg-green-600 hover:bg-green-500 px-2 py-1 rounded transition"
                      >
                        <Plus className="w-3 h-3" />
                        Add Task
                      </button>
                    </div>
                  </div>
                )}

                {msg.taskSuggestion && msg.taskSuggestion.added && (
                  <div className="mt-3 p-2 bg-green-600/20 rounded-lg border border-green-600/50">
                    <div className="flex items-center gap-2 text-xs text-green-400">
                      <Plus className="w-3 h-3" />
                      Task added to your quest list!
                    </div>
                  </div>
                )}
              </div>
              <div className="text-xs text-gray-500 mt-1 px-2">
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}
        
        {isThinking && (
          <div className="flex justify-start">
            <div className="bg-gray-700 p-4 rounded-2xl rounded-bl-none max-w-[80%]">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span className="text-xs text-purple-400 font-semibold">AI Coach</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-100"></div>
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-200"></div>
                </div>
                <span className="text-sm text-gray-300">Thinking...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="mt-4 flex gap-3">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSendPrompt()}
          placeholder="Ask your AI coach anything..."
          className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-400 focus:outline-none"
          disabled={isThinking}
        />
        <button
          onClick={handleSendPrompt}
          disabled={isThinking || !prompt.trim()}
          className={`px-4 py-2 rounded-lg ${currentTheme.primary || 'bg-indigo-600'} ${currentTheme.hover || 'hover:bg-indigo-500'} font-semibold disabled:opacity-50 transition`}
        >
          <Send className="w-5 h-5" />
        </button>
      </div>

      {/* Tips */}
      <div className="mt-4 p-3 bg-blue-900/20 rounded-lg border border-blue-500/30">
        <div className="flex items-center gap-2 mb-1">
          <Lightbulb className="w-4 h-4 text-blue-400" />
          <span className="text-sm font-semibold text-blue-400">Pro Tip</span>
        </div>
        <p className="text-xs text-blue-200">
          Ask me to break down complex projects, suggest task priorities, or help with time management strategies. I can also create tasks directly from our conversation!
        </p>
      </div>
    </div>
  )
}
