"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { useTheme } from "@/contexts/theme-context"
import { Gift, Star, Lock, CheckCircle, Crown, Sparkles } from 'lucide-react'

interface RedemptionItem {
  id: string
  name: string
  description: string
  cost: number
  type: "avatar" | "theme" | "feature"
  rarity: "common" | "rare" | "epic" | "legendary"
  icon: string
  unlocked: boolean
  redeemed: boolean
  previewImage?: string
}

export default function RedemptionPage() {
  const { user, updateUser } = useAuth()
  const { themes, theme } = useTheme()
  const [selectedCategory, setSelectedCategory] = useState<"all" | "avatar" | "theme" | "feature">("all")
  const [showConfirmModal, setShowConfirmModal] = useState<RedemptionItem | null>(null)
  
  const currentTheme = themes && theme ? themes[theme] : {}

  const redemptionItems: RedemptionItem[] = [
    // Avatar Rewards
    {
      id: "avatar_mystic_warrior",
      name: "Mystic Warrior",
      description: "A legendary warrior infused with mystical powers",
      cost: 1000,
      type: "avatar",
      rarity: "epic",
      icon: "⚔️✨",
      unlocked: (user?.stats?.totalXp || 0) >= 800,
      redeemed: false
    },
    {
      id: "avatar_cosmic_guardian",
      name: "Cosmic Guardian",
      description: "Protector of the universe with cosmic abilities",
      cost: 2500,
      type: "avatar",
      rarity: "legendary",
      icon: "🌌🛡️",
      unlocked: (user?.stats?.totalXp || 0) >= 2000,
      redeemed: false
    },
    {
      id: "avatar_shadow_assassin",
      name: "Shadow Assassin",
      description: "Master of stealth and precision strikes",
      cost: 1500,
      type: "avatar",
      rarity: "epic",
      icon: "🥷💀",
      unlocked: (user?.stats?.totalXp || 0) >= 1200,
      redeemed: false
    },
    {
      id: "avatar_elemental_mage",
      name: "Elemental Mage",
      description: "Wielder of fire, water, earth, and air magic",
      cost: 2000,
      type: "avatar",
      rarity: "legendary",
      icon: "🔥💧🌍💨",
      unlocked: (user?.stats?.totalXp || 0) >= 1500,
      redeemed: false
    },
    {
      id: "avatar_cyber_ninja",
      name: "Cyber Ninja",
      description: "Futuristic warrior with advanced technology",
      cost: 1800,
      type: "avatar",
      rarity: "epic",
      icon: "🤖⚡",
      unlocked: (user?.stats?.totalXp || 0) >= 1300,
      redeemed: false
    },
    {
      id: "avatar_divine_oracle",
      name: "Divine Oracle",
      description: "Seer of the future with divine wisdom",
      cost: 3000,
      type: "avatar",
      rarity: "legendary",
      icon: "👁️✨",
      unlocked: (user?.stats?.totalXp || 0) >= 2500,
      redeemed: false
    },
    // Theme Rewards
    {
      id: "theme_neon_cyberpunk",
      name: "Neon Cyberpunk",
      description: "Futuristic neon-lit cyberpunk aesthetic",
      cost: 800,
      type: "theme",
      rarity: "rare",
      icon: "🌃💜",
      unlocked: (user?.stats?.totalXp || 0) >= 600,
      redeemed: false
    },
    {
      id: "theme_golden_luxury",
      name: "Golden Luxury",
      description: "Premium gold and black luxury theme",
      cost: 1200,
      type: "theme",
      rarity: "epic",
      icon: "👑💛",
      unlocked: (user?.stats?.totalXp || 0) >= 1000,
      redeemed: false
    },
    // Feature Rewards
    {
      id: "feature_advanced_analytics",
      name: "Advanced Analytics",
      description: "Detailed productivity insights and reports",
      cost: 500,
      type: "feature",
      rarity: "rare",
      icon: "📊",
      unlocked: (user?.stats?.totalXp || 0) >= 400,
      redeemed: false
    },
    {
      id: "feature_ai_mentor",
      name: "AI Mentor Pro",
      description: "Enhanced AI coaching with personalized strategies",
      cost: 1500,
      type: "feature",
      rarity: "epic",
      icon: "🧠",
      unlocked: (user?.stats?.totalXp || 0) >= 1200,
      redeemed: false
    }
  ]

  const filteredItems = redemptionItems.filter(item => 
    selectedCategory === "all" || item.type === selectedCategory
  )

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common": return "border-gray-500 bg-gray-500/10"
      case "rare": return "border-blue-500 bg-blue-500/10"
      case "epic": return "border-purple-500 bg-purple-500/10"
      case "legendary": return "border-yellow-500 bg-yellow-500/10"
      default: return "border-gray-500 bg-gray-500/10"
    }
  }

  const getRarityText = (rarity: string) => {
    switch (rarity) {
      case "common": return "text-gray-400"
      case "rare": return "text-blue-400"
      case "epic": return "text-purple-400"
      case "legendary": return "text-yellow-400"
      default: return "text-gray-400"
    }
  }

  const canAfford = (cost: number) => {
    return (user?.stats?.totalXp || 0) >= cost
  }

  const handleRedeem = (item: RedemptionItem) => {
    if (!canAfford(item.cost) || !item.unlocked || item.redeemed) return
    setShowConfirmModal(item)
  }

  const confirmRedeem = (item: RedemptionItem) => {
    if (!user) return

    // Deduct XP
    const newStats = { ...user.stats }
    newStats.totalXp -= item.cost

    // Add redeemed item based on type
    let updates: any = { stats: newStats }

    if (item.type === "avatar") {
      const newAvatar = {
        id: item.id,
        name: item.name,
        unlocked: true,
        equipped: false
      }
      updates.avatar = [...(user.avatar || []), newAvatar]
    }

    updateUser(updates)
    setShowConfirmModal(null)
  }

  const categories = [
    { id: "all", label: "All Items", icon: <Gift /> },
    { id: "avatar", label: "Avatars", icon: <Crown /> },
    { id: "theme", label: "Themes", icon: <Sparkles /> },
    { id: "feature", label: "Features", icon: <Star /> }
  ]

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Redemption Store</h1>
          <p className="text-gray-400">Exchange your XP for exclusive rewards</p>
        </div>
        <div className={`px-4 py-2 ${currentTheme.primary || 'bg-indigo-600'} rounded-lg`}>
          <div className="text-sm text-gray-300">Available XP</div>
          <div className="text-xl font-bold text-yellow-400">{user?.stats?.totalXp || 0}</div>
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id as any)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition whitespace-nowrap ${
              selectedCategory === category.id
                ? `${currentTheme.primary || 'bg-indigo-600'} text-white`
                : "bg-gray-700 text-gray-300 hover:bg-gray-600"
            }`}
          >
            {category.icon}
            {category.label}
          </button>
        ))}
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className={`relative p-4 rounded-xl border-2 transition-all duration-300 ${
              item.unlocked && canAfford(item.cost) && !item.redeemed
                ? `${getRarityColor(item.rarity)} hover:scale-105 cursor-pointer`
                : "border-gray-700 bg-gray-800/30 opacity-60"
            }`}
          >
            {/* Rarity Badge */}
            <div className={`absolute top-2 right-2 text-xs font-bold px-2 py-1 rounded-full ${getRarityText(item.rarity)} bg-gray-900/50`}>
              {item.rarity.toUpperCase()}
            </div>

            {/* Lock/Redeemed Indicator */}
            {!item.unlocked && (
              <div className="absolute top-2 left-2">
                <Lock className="w-5 h-5 text-gray-400" />
              </div>
            )}
            {item.redeemed && (
              <div className="absolute top-2 left-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
              </div>
            )}

            {/* Item Icon */}
            <div className="text-4xl mb-3 text-center">
              {item.icon}
            </div>

            {/* Item Info */}
            <div className="text-center">
              <h3 className="font-bold text-lg mb-1">{item.name}</h3>
              <p className="text-xs text-gray-400 mb-3">{item.description}</p>
              
              <div className="space-y-2">
                <div className={`text-lg font-bold ${getRarityText(item.rarity)}`}>
                  {item.cost} XP
                </div>

                {!item.unlocked && (
                  <div className="text-xs text-red-400">
                    Need {item.cost - (user?.stats?.totalXp || 0)} more XP
                  </div>
                )}

                {item.redeemed && (
                  <div className="text-xs text-green-400 font-semibold">
                    Already Redeemed
                  </div>
                )}

                {item.unlocked && !item.redeemed && (
                  <button
                    onClick={() => handleRedeem(item)}
                    disabled={!canAfford(item.cost)}
                    className={`w-full px-3 py-2 rounded-lg font-semibold transition ${
                      canAfford(item.cost)
                        ? `${currentTheme.primary || 'bg-indigo-600'} hover:${currentTheme.hover || 'bg-indigo-500'} text-white`
                        : "bg-gray-600 text-gray-400 cursor-not-allowed"
                    }`}
                  >
                    {canAfford(item.cost) ? "Redeem" : "Insufficient XP"}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
          <div className={`${currentTheme.cardBg || 'bg-gray-800'} p-6 rounded-xl w-11/12 max-w-md border ${currentTheme.border || 'border-gray-700'} text-center`}>
            <div className="text-4xl mb-4">{showConfirmModal.icon}</div>
            <h2 className="text-xl font-bold mb-2">Confirm Redemption</h2>
            <p className="text-gray-300 mb-4">
              Are you sure you want to redeem <strong>{showConfirmModal.name}</strong> for <strong>{showConfirmModal.cost} XP</strong>?
            </p>
            <div className="text-sm text-gray-400 mb-6">
              You will have {(user?.stats?.totalXp || 0) - showConfirmModal.cost} XP remaining.
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowConfirmModal(null)}
                className="flex-1 px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded-lg font-semibold transition"
              >
                Cancel
              </button>
              <button
                onClick={() => confirmRedeem(showConfirmModal)}
                className={`flex-1 px-4 py-2 ${currentTheme.primary || 'bg-indigo-600'} ${currentTheme.hover || 'hover:bg-indigo-500'} rounded-lg font-semibold transition`}
              >
                Redeem
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
