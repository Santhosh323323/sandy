"use client"

import { Award } from "lucide-react"

interface JournalPromptModalProps {
  title: string
  onClose: () => void
  onNavigate: () => void
}

export default function JournalPromptModal({ title, onClose, onNavigate }: JournalPromptModalProps) {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-gray-800 p-6 rounded-xl w-11/12 max-w-md border border-green-500 text-center">
        <Award className="mx-auto h-12 w-12 text-green-400 mb-4" />
        <h2 className="text-xl font-bold mb-2">Quest Complete!</h2>
        <p className="text-gray-300 mb-4">
          {"You've completed"} "{title}". Take a moment to reflect on this achievement in your journal.
        </p>
        <div className="flex justify-center gap-3">
          <button onClick={onClose} className="px-4 py-2 rounded-lg bg-gray-600 hover:bg-gray-500">
            Later
          </button>
          <button onClick={onNavigate} className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-500 font-semibold">
            Write Journal
          </button>
        </div>
      </div>
    </div>
  )
}
