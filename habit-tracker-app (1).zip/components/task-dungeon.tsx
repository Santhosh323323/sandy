"use client"

import type React from "react"

import { useState } from "react"
import { useApp } from "@/contexts/app-context"
import { Sparkles, Target, Book, Zap, Plus, Trash2, ExternalLink, Calendar } from 'lucide-react'
import AddTaskModal from "@/components/add-task-modal"
import LongTermGoalsPage from "@/components/long-term-goals-page"

interface TaskDungeonProps {
  navigate?: (page: string) => void
  setSelectedQuest?: (quest: any) => void
}

export default function TaskDungeon({ navigate, setSelectedQuest }: TaskDungeonProps) {
  const { quests, toggleQuest, deleteQuest } = useApp()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [currentCategory, setCurrentCategory] = useState<"main" | "side" | "mini">("main")
  const [activeTab, setActiveTab] = useState<"tasks" | "goals">("tasks")

  const openAddTaskModal = (category: "main" | "side" | "mini") => {
    setCurrentCategory(category)
    setIsModalOpen(true)
  }

  const viewQuestDetail = (quest: any) => {
    if (setSelectedQuest && navigate) {
      setSelectedQuest(quest)
      navigate("quest-detail")
    }
  }

  if (activeTab === "goals") {
    return (
      <div className="animate-fade-in">
        {/* Header with tab navigation */}
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-2xl font-bold">Task Management</h1>
          <button
            onClick={() => setActiveTab("tasks")}
            className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition"
          >
            Back to Tasks
          </button>
        </div>

        <LongTermGoalsPage />
      </div>
    )
  }

  return (
    <div className="animate-fade-in">
      {/* Tab Navigation */}
      <div className="flex bg-gray-800/50 rounded-lg p-1 mb-6">
        <button
          onClick={() => setActiveTab("tasks")}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition ${
            activeTab === "tasks" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"
          }`}
        >
          <Target size={18} />
          Daily Tasks
        </button>
        <button
          onClick={() => setActiveTab("goals")}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition ${
            activeTab === "goals" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"
          }`}
        >
          <Calendar size={18} />
          Long-term Goals
        </button>
      </div>

      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Task Dungeon</h1>
        <button className="flex items-center gap-2 px-3 py-2 text-sm font-semibold bg-indigo-600 hover:bg-indigo-500 rounded-lg transition">
          <Sparkles size={16} /> Prioritize with AI
        </button>
      </div>

      <div className="space-y-6">
        <TaskSection
          title="Main Quests"
          quests={quests.main}
          onToggle={(id) => toggleQuest("main", id)}
          onDelete={(id) => deleteQuest("main", id)}
          onAdd={() => openAddTaskModal("main")}
          onViewDetail={viewQuestDetail}
          icon={<Target />}
          category="main"
          showDetailButton={true}
        />
        <TaskSection
          title="Side Quests"
          quests={quests.side}
          onToggle={(id) => toggleQuest("side", id)}
          onDelete={(id) => deleteQuest("side", id)}
          onAdd={() => openAddTaskModal("side")}
          icon={<Book />}
          category="side"
        />
        <TaskSection
          title="Mini Tasks"
          quests={quests.mini}
          onToggle={(id) => toggleQuest("mini", id)}
          onDelete={(id) => deleteQuest("mini", id)}
          onAdd={() => openAddTaskModal("mini")}
          icon={<Zap />}
          category="mini"
        />
      </div>

      {isModalOpen && <AddTaskModal category={currentCategory} onClose={() => setIsModalOpen(false)} />}
    </div>
  )
}

interface Quest {
  id: string
  title: string
  xp: number
  completed: boolean
}

interface TaskSectionProps {
  title: string
  quests: Quest[]
  onToggle: (id: string) => void
  onDelete: (id: string) => void
  onAdd: () => void
  icon: React.ReactNode
  category: string
  onViewDetail?: (quest: Quest) => void
  showDetailButton?: boolean
}

const TaskSection = ({
  title,
  quests,
  onToggle,
  onDelete,
  onAdd,
  icon,
  onViewDetail,
  showDetailButton = false,
}: TaskSectionProps) => (
  <section>
    <div className="flex justify-between items-center mb-3">
      <h2 className="text-xl font-semibold flex items-center gap-2">
        {icon} {title}
      </h2>
      <button onClick={onAdd} className="p-2 rounded-full bg-gray-700 hover:bg-indigo-600 transition">
        <Plus size={18} />
      </button>
    </div>
    <div className="space-y-2">
      {quests.map((quest) => (
        <div
          key={quest.id}
          className={`flex items-center p-3 rounded-lg transition ${
            quest.completed ? "bg-green-900/50 border-l-4 border-green-500" : "bg-gray-800 border-l-4 border-indigo-600"
          }`}
        >
          <div onClick={() => onToggle(quest.id)} className="flex-grow cursor-pointer">
            <span className={`${quest.completed ? "line-through text-gray-500" : ""}`}>{quest.title}</span>
          </div>
          <span className="text-xs font-bold text-yellow-400 mx-3">+{quest.xp} XP</span>
          {showDetailButton && onViewDetail && (
            <button
              onClick={() => onViewDetail(quest)}
              className="p-1 text-blue-400 hover:text-blue-300 transition mr-2"
              title="View Details"
            >
              <ExternalLink size={16} />
            </button>
          )}
          <button onClick={() => onDelete(quest.id)} className="p-1 text-gray-500 hover:text-red-500 transition">
            <Trash2 size={16} />
          </button>
        </div>
      ))}
    </div>
  </section>
)
