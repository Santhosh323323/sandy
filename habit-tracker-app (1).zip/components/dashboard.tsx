"use client"

import { useTheme } from "@/contexts/theme-context"
import { useApp } from "@/contexts/app-context"
import { useAuth } from "@/contexts/auth-context"
import { Star, TrendingUp, Shield, Bot, Award, Target, Book, Zap, User, Settings, LogOut, Gift, Focus, Calendar, Timer, BarChart3 } from 'lucide-react'
import StatCard from "@/components/stat-card"
import QuestCategory from "@/components/quest-category"
import SPLogo from "@/components/ui/sp-logo"
import { useEffect, useState } from "react"
import DailyQuestCard from "@/components/daily-quest-card"
import FocusPage from "@/components/focus-page"

interface DashboardProps {
  navigate: (page: string) => void
}

const LongTermGoalPreview = ({ navigate }: { navigate: (page: string) => void }) => {
  const { longTermGoals } = useApp()

  if (longTermGoals.length === 0) {
    return (
      <div className="bg-gray-800/60 p-4 rounded-xl border border-gray-700 text-center">
        <p className="text-gray-400 mb-3">No long-term goals yet</p>
        <button
          onClick={() => navigate("tasks")}
          className="text-sm bg-indigo-600 hover:bg-indigo-500 px-3 py-1 rounded-lg"
        >
          Add Your First Goal
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      {longTermGoals.slice(0, 2).map((goal) => (
        <div key={goal.id} className="bg-gray-800/60 p-3 rounded-xl border border-gray-700">
          <div className="flex justify-between items-center mb-2">
            <h4 className="font-semibold">{goal.title}</h4>
            <span className="text-xs text-gray-400">{Math.round(goal.progress)}%</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div
              className="bg-purple-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${goal.progress}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  )
}

export default function Dashboard({ navigate }: DashboardProps) {
  const { theme, themes } = useTheme()
  const { quests } = useApp()
  const { user, logout } = useAuth()
  const [efficiency, setEfficiency] = useState(0)
  const [focusScore, setFocusScore] = useState(0)
  const [showProfileMenu, setShowProfileMenu] = useState(false)
  const [activeTab, setActiveTab] = useState<"overview" | "focus">("overview")
  const currentTheme = themes && theme ? themes[theme] : {
    bg: "bg-gray-900",
    text: "text-indigo-400",
    border: "border-indigo-700/50"
  }

  // Calculate efficiency based on task completion patterns
  useEffect(() => {
    const calculateEfficiency = () => {
      const today = new Date().toISOString().split('T')[0]
      const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      
      // Get task completion data from localStorage
      const taskHistory = JSON.parse(localStorage.getItem('taskHistory') || '{}')
      const todayTasks = taskHistory[today] || { completed: 0, total: 0, timeSpent: 0 }
      const yesterdayTasks = taskHistory[yesterday] || { completed: 0, total: 0, timeSpent: 0 }
      
      // Calculate current completion rate
      const todayRate = todayTasks.total > 0 ? (todayTasks.completed / todayTasks.total) * 100 : 0
      const yesterdayRate = yesterdayTasks.total > 0 ? (yesterdayTasks.completed / yesterdayTasks.total) * 100 : 50
      
      // Calculate efficiency based on improvement and time management
      let efficiencyScore = todayRate
      
      // Bonus for improvement over yesterday
      if (todayRate > yesterdayRate) {
        efficiencyScore += (todayRate - yesterdayRate) * 0.5
      }
      
      // Bonus for consistent high performance
      if (todayRate >= 80) {
        efficiencyScore += 10
      }
      
      // Time efficiency bonus (completing tasks faster)
      if (todayTasks.timeSpent > 0 && yesterdayTasks.timeSpent > 0) {
        const timeImprovement = (yesterdayTasks.timeSpent - todayTasks.timeSpent) / yesterdayTasks.timeSpent
        if (timeImprovement > 0) {
          efficiencyScore += timeImprovement * 20
        }
      }
      
      setEfficiency(Math.min(Math.max(Math.round(efficiencyScore), 0), 100))
    }

    const calculateFocusScore = () => {
      const allTasks = [...quests.main, ...quests.side, ...quests.mini]
      const completedTasks = allTasks.filter(task => task.completed)
      const totalTasks = allTasks.length
      
      if (totalTasks === 0) {
        setFocusScore(0)
        return
      }
      
      // Base focus score on completion rate
      let focusPercentage = (completedTasks.length / totalTasks) * 100
      
      // Get today's task timing data
      const today = new Date().toISOString().split('T')[0]
      const taskTiming = JSON.parse(localStorage.getItem('taskTiming') || '{}')
      const todayTiming = taskTiming[today] || {}
      
      // Bonus for completing tasks within estimated time
      const onTimeCompletions = Object.values(todayTiming).filter((timing: any) => 
        timing.completed && timing.actualTime <= timing.estimatedTime
      ).length
      
      if (onTimeCompletions > 0) {
        focusPercentage += (onTimeCompletions / completedTasks.length) * 20
      }
      
      // Penalty for overdue tasks
      const overdueTasks = allTasks.filter(task => !task.completed).length
      if (overdueTasks > 0) {
        focusPercentage -= (overdueTasks / totalTasks) * 10
      }
      
      setFocusScore(Math.min(Math.max(Math.round(focusPercentage), 0), 100))
    }

    calculateEfficiency()
    calculateFocusScore()
  }, [quests])

  // Update task history when tasks change
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0]
    const allTasks = [...quests.main, ...quests.side, ...quests.mini]
    const completedTasks = allTasks.filter(task => task.completed)
    
    const taskHistory = JSON.parse(localStorage.getItem('taskHistory') || '{}')
    taskHistory[today] = {
      completed: completedTasks.length,
      total: allTasks.length,
      timeSpent: Math.random() * 8 + 2, // Simulated time spent (in hours)
      timestamp: new Date().toISOString()
    }
    
    localStorage.setItem('taskHistory', JSON.stringify(taskHistory))
  }, [quests])

  if (activeTab === "focus") {
    return (
      <div className="space-y-6 animate-fade-in">
        {/* Header with tab navigation */}
        <header className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            <SPLogo size="md" />
            <div>
              <h1 className="text-2xl font-bold">Skill Progressing</h1>
              <p className={`${currentTheme.text.replace("400", "300")}`}>Focus & Productivity Tools</p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab("overview")}
            className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition"
          >
            Back to Overview
          </button>
        </header>

        <FocusPage />
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <header className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <SPLogo size="md" />
          <div>
            <h1 className="text-2xl font-bold">Skill Progressing</h1>
            <p className={`${currentTheme.text.replace("400", "300")}`}>Welcome back, {user?.firstName || 'Adventurer'}!</p>
          </div>
        </div>
        <div className="relative">
          <button
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="w-12 h-12 bg-gray-800 rounded-full flex items-center justify-center border-2 border-gray-700 hover:border-indigo-500 transition"
          >
            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center text-sm font-bold">
              {user?.firstName?.[0] || user?.username[0].toUpperCase() || 'A'}
            </div>
          </button>
          
          {showProfileMenu && (
            <div className="absolute right-0 top-14 bg-gray-800 rounded-lg border border-gray-700 shadow-xl z-50 min-w-48">
              <button
                onClick={() => {
                  navigate("profile")
                  setShowProfileMenu(false)
                }}
                className="w-full text-left px-4 py-3 hover:bg-gray-700 rounded-t-lg transition flex items-center gap-2"
              >
                <User size={16} />
                View Profile
              </button>
              <button
                onClick={() => {
                  navigate("settings")
                  setShowProfileMenu(false)
                }}
                className="w-full text-left px-4 py-3 hover:bg-gray-700 transition flex items-center gap-2"
              >
                <Settings size={16} />
                Settings
              </button>
              <button
                onClick={() => {
                  navigate("redeem")
                  setShowProfileMenu(false)
                }}
                className="w-full text-left px-4 py-3 hover:bg-gray-700 transition flex items-center gap-2"
              >
                <Gift size={16} />
                Redemption Store
              </button>
              <hr className="border-gray-700" />
              <button
                onClick={() => {
                  logout()
                  setShowProfileMenu(false)
                }}
                className="w-full text-left px-4 py-3 hover:bg-gray-700 rounded-b-lg transition flex items-center gap-2 text-red-400"
              >
                <LogOut size={16} />
                Sign Out
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="flex bg-gray-800/50 rounded-lg p-1">
        <button
          onClick={() => setActiveTab("overview")}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition ${
            activeTab === "overview" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"
          }`}
        >
          <BarChart3 size={18} />
          Overview
        </button>
        <button
          onClick={() => setActiveTab("focus")}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition ${
            activeTab === "focus" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"
          }`}
        >
          <Timer size={18} />
          Focus Tools
        </button>
      </div>

      <div className="bg-gray-800/50 px-4 py-3 rounded-full border border-gray-700/50">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Star className="text-yellow-400 h-5 w-5" />
            <span className="font-bold">Level {user?.stats?.level || 1}</span>
          </div>
          <span className="text-sm text-gray-400">{user?.stats?.xp || 0} / {((user?.stats?.level || 1) * 100)} XP</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-yellow-400 to-orange-500 h-2 rounded-full transition-all duration-500"
            style={{ width: `${Math.min(((user?.stats?.xp || 0) / ((user?.stats?.level || 1) * 100)) * 100, 100)}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 text-center">
        <StatCard 
          icon={<TrendingUp />} 
          label="Streak" 
          value={`${user?.stats?.streak || 7} days`} 
          color="text-green-400" 
        />
        <StatCard 
          icon={<Shield />} 
          label="Efficiency" 
          value={`${efficiency}%`} 
          color={efficiency >= 80 ? "text-green-400" : efficiency >= 60 ? "text-yellow-400" : "text-red-400"} 
        />
        <StatCard 
          icon={<Bot />} 
          label="Focus" 
          value={`${focusScore}%`} 
          color={focusScore >= 80 ? "text-purple-400" : focusScore >= 60 ? "text-blue-400" : "text-orange-400"} 
        />
      </div>

      <DailyQuestCard />

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => navigate("redeem")}
          className="flex items-center gap-3 p-4 bg-gradient-to-r from-yellow-600/20 to-orange-600/20 rounded-xl border border-yellow-500/30 hover:bg-yellow-600/30 transition"
        >
          <Gift className="text-yellow-400" size={24} />
          <div className="text-left">
            <div className="font-semibold">Redeem Store</div>
            <div className="text-xs text-gray-400">{user?.stats?.totalXp || 0} XP available</div>
          </div>
        </button>
        
        <button
          onClick={() => setActiveTab("focus")}
          className="flex items-center gap-3 p-4 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-xl border border-blue-500/30 hover:bg-blue-600/30 transition"
        >
          <Focus className="text-blue-400" size={24} />
          <div className="text-left">
            <div className="font-semibold">Focus Tools</div>
            <div className="text-xs text-gray-400">Pomodoro & Analytics</div>
          </div>
        </button>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-3">Your Quests</h2>
        <div className="space-y-3">
          <QuestCategory
            icon={<Target />}
            title="Main Quest"
            description="High priority tasks"
            count={quests.main.length}
            color="red"
            navigate={() => navigate("tasks")}
          />
          <QuestCategory
            icon={<Book />}
            title="Side Quest"
            description="Medium priority"
            count={quests.side.length}
            color="blue"
            navigate={() => navigate("tasks")}
          />
          <QuestCategory
            icon={<Zap />}
            title="Mini Tasks"
            description="Quick wins"
            count={quests.mini.length}
            color="green"
            navigate={() => navigate("tasks")}
          />
        </div>
      </div>

      <div className="mt-6">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-xl font-semibold">Long-term Goals</h2>
          <button onClick={() => navigate("tasks")} className="text-sm text-indigo-400 hover:text-indigo-300">
            Manage Goals
          </button>
        </div>
        <LongTermGoalPreview navigate={navigate} />
      </div>

      {/* AI Setup Option for users who skipped it */}
      {user && !user.usedAISetup && (
        <div className="mt-6">
          <div className={`bg-gradient-to-r from-purple-600/20 to-indigo-600/20 p-6 rounded-xl border border-purple-500/30`}>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div className="flex-grow">
                <h3 className="font-bold text-lg mb-1">Try AI Task Setup</h3>
                <p className="text-sm text-gray-300">Get personalized tasks based on your goals and routine</p>
              </div>
              <button
                onClick={() => navigate("ai-setup")}
                className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 rounded-lg font-semibold transition"
              >
                Try Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
