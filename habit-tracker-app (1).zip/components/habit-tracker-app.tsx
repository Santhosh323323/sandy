"use client"

import { useState, useEffect } from "react"
import { ThemeProvider } from "@/contexts/theme-context"
import { AppProvider } from "@/contexts/app-context"
import { useTheme } from "@/contexts/theme-context"
import { useApp } from "@/contexts/app-context"
import Dashboard from "@/components/dashboard"
import TaskDungeon from "@/components/task-dungeon"
import JournalPage from "@/components/journal-page"
import AICoach from "@/components/ai-coach"
import ProfilePage from "@/components/profile-page"
import SettingsPage from "@/components/settings/settings-page"
import BottomNavBar from "@/components/bottom-nav-bar"
import JournalPromptModal from "@/components/journal-prompt-modal"
import LoadingSpinner from "@/components/loading-spinner"
import LongTermGoalsPage from "@/components/long-term-goals-page"
import MainQuestDetailPage from "@/components/main-quest-detail-page"
import LoginBonusModal from "@/components/auth/login-bonus-modal"
import AIOnboardingSession from "@/components/auth/ai-onboarding-session"
import AICoachPage from "@/components/ai-coach-page"
import RedemptionPage from "@/components/redemption-page"

const HabitTrackerAppContent = () => {
  const [currentPage, setCurrentPage] = useState("home")
  const { theme, themes } = useTheme()
  const { showJournalPrompt, setShowJournalPrompt, completedQuestTitle, isLoading, user, updateUser } = useApp()
  const [selectedQuest, setSelectedQuest] = useState<any>(null)
  const [showLoginBonus, setShowLoginBonus] = useState(false)

  // Provide fallback theme if theme is undefined
  const currentTheme = themes && theme ? themes[theme] : {
    bg: "bg-gray-900",
    gradient: "from-gray-900 to-indigo-900",
    primary: "bg-indigo-600",
    hover: "hover:bg-indigo-500",
    text: "text-indigo-400",
    border: "border-indigo-700/50",
    ring: "focus:ring-indigo-400",
    cardBg: "bg-white",
    accent: "text-green-500"
  }
  
  const navigate = (page: string) => setCurrentPage(page)

  useEffect(() => {
    if (user?.loginBonus && user.loginBonus.xp > 0) {
      setShowLoginBonus(true)
      // Clear the login bonus after showing
      setTimeout(() => {
        updateUser({ loginBonus: undefined })
      }, 100)
    }
  }, [user])

  return (
    <div className={`${currentTheme.bg} text-white font-sans min-h-screen flex flex-col`}>
      <main className="flex-grow p-4 pb-24">
        {currentPage === "home" && <Dashboard navigate={navigate} />}
        {currentPage === "tasks" && <TaskDungeon navigate={navigate} setSelectedQuest={setSelectedQuest} />}
        {currentPage === "journal" && <JournalPage />}
        {currentPage === "coach" && <AICoachPage />}
        {currentPage === "profile" && <ProfilePage navigate={navigate} />}
        {currentPage === "settings" && <SettingsPage navigate={navigate} />}
        {currentPage === "goals" && <LongTermGoalsPage />}
        {currentPage === "quest-detail" && selectedQuest && (
          <MainQuestDetailPage quest={selectedQuest} onBack={() => setCurrentPage("tasks")} />
        )}
        {currentPage === "ai-setup" && (
          <AIOnboardingSession 
            onComplete={(tasks) => {
              // Update user with AI generated tasks
              if (user) {
                updateUser({
                  ...user,
                  aiGeneratedTasks: tasks,
                  usedAISetup: true
                })
                
                // Update the app context with new tasks
                // This would need to be implemented in the app context
              }
              navigate("home")
            }} 
          />
        )}
        {currentPage === "redeem" && <RedemptionPage />}
      </main>

      <BottomNavBar activePage={currentPage} navigate={navigate} />

      {showJournalPrompt && (
        <JournalPromptModal
          title={completedQuestTitle}
          onClose={() => setShowJournalPrompt(false)}
          onNavigate={() => {
            navigate("journal")
            setShowJournalPrompt(false)
          }}
        />
      )}

      {showLoginBonus && user?.loginBonus && (
        <LoginBonusModal
          bonus={user.loginBonus}
          onClose={() => setShowLoginBonus(false)}
          currentTheme={currentTheme}
        />
      )}

      {isLoading && <LoadingSpinner />}
    </div>
  )
}

export default function HabitTrackerApp() {
  return (
    <ThemeProvider>
      <AppProvider>
        <HabitTrackerAppContent />
      </AppProvider>
    </ThemeProvider>
  )
}

const LoginBonusModal = ({ bonus, onClose, currentTheme }: any) => (
  <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
    <div className={`${currentTheme.cardBg} p-6 rounded-xl w-11/12 max-w-md border ${currentTheme.border} text-center backdrop-blur-sm`}>
      <div className="text-6xl mb-4">🎉</div>
      <h2 className="text-xl font-bold mb-2">Login Bonus!</h2>
      <p className={`${currentTheme.text} mb-4`}>{bonus.message}</p>
      <div className={`text-3xl font-bold ${currentTheme.accent} mb-2`}>+{bonus.xp} XP</div>
      <div className="text-sm text-gray-400 mb-6">
        Current streak: {bonus.streak} {bonus.streak === 1 ? 'day' : 'days'}
      </div>
      <button 
        onClick={onClose} 
        className={`px-6 py-2 ${currentTheme.primary} ${currentTheme.hover} rounded-lg font-semibold transition`}
      >
        Awesome!
      </button>
    </div>
  </div>
)
