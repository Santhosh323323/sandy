"use client"

import { useState, useEffect } from "react"
import { useApp } from "@/contexts/app-context"
import { Calendar, ChevronLeft, ChevronRight, Save, Search, Tag, Plus, Edit3, BookOpen, BarChart3 } from 'lucide-react'

interface JournalEntry {
  id: string
  date: string
  content: string
  mood: "great" | "good" | "okay" | "bad" | "terrible"
  tags: string[]
  createdAt: string
  updatedAt: string
}

type ViewMode = "calendar" | "entry" | "search" | "analytics" | "tags"

export default function JournalPage() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [journalText, setJournalText] = useState("")
  const [selectedMood, setSelectedMood] = useState<JournalEntry["mood"]>("good")
  const [tags, setTags] = useState("")
  const [entries, setEntries] = useState<JournalEntry[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [viewMode, setViewMode] = useState<ViewMode>("calendar")
  const [availableTags, setAvailableTags] = useState<string[]>([])
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const { completedQuestTitle } = useApp()

  // Load entries from localStorage on component mount
  useEffect(() => {
    const savedEntries = localStorage.getItem("journalEntries")
    if (savedEntries) {
      try {
        const parsedEntries = JSON.parse(savedEntries)
        setEntries(parsedEntries)
        
        // Extract all unique tags
        const allTags = new Set<string>()
        parsedEntries.forEach((entry: JournalEntry) => {
          entry.tags.forEach(tag => allTags.add(tag))
        })
        setAvailableTags(Array.from(allTags))
      } catch (error) {
        console.error("Error loading journal entries:", error)
      }
    }
  }, [])

  // Load entry for selected date
  useEffect(() => {
    if (viewMode === "entry") {
      const dateKey = selectedDate.toISOString().split('T')[0]
      const existingEntry = entries.find(entry => entry.date === dateKey)
      if (existingEntry) {
        setJournalText(existingEntry.content)
        setSelectedMood(existingEntry.mood)
        setTags(existingEntry.tags.join(", "))
      } else {
        setJournalText("")
        setSelectedMood("good")
        setTags("")
      }
    }
  }, [selectedDate, entries, viewMode])

  const saveEntry = () => {
    const dateKey = selectedDate.toISOString().split('T')[0]
    const entryTags = tags.split(",").map(tag => tag.trim()).filter(tag => tag.length > 0)
    
    const newEntry: JournalEntry = {
      id: `entry-${dateKey}`,
      date: dateKey,
      content: journalText,
      mood: selectedMood,
      tags: entryTags,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }

    const updatedEntries = entries.filter(entry => entry.date !== dateKey)
    updatedEntries.push(newEntry)
    
    setEntries(updatedEntries)
    localStorage.setItem("journalEntries", JSON.stringify(updatedEntries))
    
    // Update available tags
    const allTags = new Set(availableTags)
    entryTags.forEach(tag => allTags.add(tag))
    setAvailableTags(Array.from(allTags))
    
    // Show success message or navigate back
    setViewMode("calendar")
  }

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate()
  }

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay()
  }

  const hasEntry = (date: Date) => {
    const dateKey = date.toISOString().split('T')[0]
    return entries.some(entry => entry.date === dateKey)
  }

  const getEntryMood = (date: Date) => {
    const dateKey = date.toISOString().split('T')[0]
    const entry = entries.find(entry => entry.date === dateKey)
    return entry?.mood
  }

  const moodEmojis = {
    great: "😄",
    good: "😊",
    okay: "😐",
    bad: "😔",
    terrible: "😢"
  }

  const moodColors = {
    great: "bg-green-500",
    good: "bg-blue-500",
    okay: "bg-yellow-500",
    bad: "bg-orange-500",
    terrible: "bg-red-500"
  }

  const filteredEntries = entries.filter(entry => {
    const matchesSearch = entry.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesTags = selectedTags.length === 0 || 
                       selectedTags.some(tag => entry.tags.includes(tag))
    return matchesSearch && matchesTags
  })

  const getStreakData = () => {
    const sortedEntries = [...entries].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    let currentStreak = 0
    let longestStreak = 0
    let tempStreak = 0
    
    const today = new Date()
    let checkDate = new Date(today)
    
    // Check current streak
    for (let i = 0; i < 30; i++) {
      const dateKey = checkDate.toISOString().split('T')[0]
      if (sortedEntries.some(entry => entry.date === dateKey)) {
        if (i === 0 || currentStreak > 0) currentStreak++
      } else if (i === 0) {
        break
      }
      checkDate.setDate(checkDate.getDate() - 1)
    }
    
    // Calculate longest streak
    for (let i = 0; i < sortedEntries.length - 1; i++) {
      const current = new Date(sortedEntries[i].date)
      const next = new Date(sortedEntries[i + 1].date)
      const diffDays = Math.abs((current.getTime() - next.getTime()) / (1000 * 60 * 60 * 24))
      
      if (diffDays === 1) {
        tempStreak++
      } else {
        longestStreak = Math.max(longestStreak, tempStreak + 1)
        tempStreak = 0
      }
    }
    longestStreak = Math.max(longestStreak, tempStreak + 1)
    
    return { currentStreak, longestStreak, totalEntries: entries.length }
  }

  const getMoodStats = () => {
    const moodCounts = entries.reduce((acc, entry) => {
      acc[entry.mood] = (acc[entry.mood] || 0) + 1
      return acc
    }, {} as Record<string, number>)
    
    return Object.entries(moodCounts).map(([mood, count]) => ({
      mood: mood as keyof typeof moodEmojis,
      count,
      percentage: Math.round((count / entries.length) * 100)
    }))
  }

  // Navigation Menu
  const navigationItems = [
    { id: "calendar", label: "Calendar", icon: <Calendar />, description: "Monthly view with mood indicators" },
    { id: "search", label: "Search", icon: <Search />, description: "Find entries by content or tags" },
    { id: "tags", label: "Tags", icon: <Tag />, description: "Manage and filter by tags" },
    { id: "analytics", label: "Analytics", icon: <BarChart3 />, description: "Mood trends and statistics" }
  ]

  if (viewMode === "entry") {
    return <EntryView 
      selectedDate={selectedDate}
      journalText={journalText}
      setJournalText={setJournalText}
      selectedMood={selectedMood}
      setSelectedMood={setSelectedMood}
      tags={tags}
      setTags={setTags}
      availableTags={availableTags}
      moodEmojis={moodEmojis}
      moodColors={moodColors}
      onSave={saveEntry}
      onBack={() => setViewMode("calendar")}
      completedQuestTitle={completedQuestTitle}
    />
  }

  return (
    <div className="animate-fade-in space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <BookOpen className="text-purple-400" />
            Journal
          </h1>
          <p className="text-gray-400">Reflect on your journey</p>
        </div>
        <button
          onClick={() => {
            setSelectedDate(new Date())
            setViewMode("entry")
          }}
          className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-500 rounded-lg font-semibold transition"
        >
          <Edit3 size={18} />
          Write Today
        </button>
      </div>

      {/* Navigation Menu */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {navigationItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setViewMode(item.id as ViewMode)}
            className={`p-4 rounded-xl border-2 transition text-left ${
              viewMode === item.id
                ? "border-purple-500 bg-purple-500/20 text-white"
                : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              {item.icon}
              <span className="font-semibold">{item.label}</span>
            </div>
            <p className="text-xs opacity-75">{item.description}</p>
          </button>
        ))}
      </div>

      {/* Content based on view mode */}
      {viewMode === "calendar" && (
        <CalendarView 
          currentDate={currentDate}
          setCurrentDate={setCurrentDate}
          selectedDate={selectedDate}
          setSelectedDate={setSelectedDate}
          setViewMode={setViewMode}
          hasEntry={hasEntry}
          getEntryMood={getEntryMood}
          getDaysInMonth={getDaysInMonth}
          getFirstDayOfMonth={getFirstDayOfMonth}
          moodEmojis={moodEmojis}
        />
      )}

      {viewMode === "search" && (
        <SearchView 
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          filteredEntries={filteredEntries}
          setSelectedDate={setSelectedDate}
          setViewMode={setViewMode}
          moodEmojis={moodEmojis}
        />
      )}

      {viewMode === "tags" && (
        <TagsView 
          availableTags={availableTags}
          selectedTags={selectedTags}
          setSelectedTags={setSelectedTags}
          entries={entries}
          filteredEntries={filteredEntries}
          setSelectedDate={setSelectedDate}
          setViewMode={setViewMode}
          moodEmojis={moodEmojis}
        />
      )}

      {viewMode === "analytics" && (
        <AnalyticsView 
          getStreakData={getStreakData}
          getMoodStats={getMoodStats}
          entries={entries}
          moodEmojis={moodEmojis}
          moodColors={moodColors}
        />
      )}
    </div>
  )
}

// Calendar View Component
const CalendarView = ({ currentDate, setCurrentDate, selectedDate, setSelectedDate, setViewMode, hasEntry, getEntryMood, getDaysInMonth, getFirstDayOfMonth, moodEmojis }: any) => (
  <div className="space-y-4">
    {/* Calendar Navigation */}
    <div className="flex justify-between items-center bg-gray-800/50 p-4 rounded-lg">
      <button
        onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1))}
        className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <h2 className="text-xl font-bold">
        {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
      </h2>
      <button
        onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1))}
        className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition"
      >
        <ChevronRight className="w-5 h-5" />
      </button>
    </div>

    {/* Calendar Grid */}
    <div className="bg-gray-800/50 p-4 rounded-lg">
      <div className="grid grid-cols-7 gap-2 mb-4">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-sm font-semibold text-gray-400 p-2">
            {day}
          </div>
        ))}
      </div>
      
      <div className="grid grid-cols-7 gap-2">
        {/* Empty cells for days before month starts */}
        {Array.from({ length: getFirstDayOfMonth(currentDate) }).map((_, index) => (
          <div key={`empty-${index}`} className="h-12"></div>
        ))}
        
        {/* Days of the month */}
        {Array.from({ length: getDaysInMonth(currentDate) }).map((_, index) => {
          const day = index + 1
          const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day)
          const isToday = date.toDateString() === new Date().toDateString()
          const isSelected = date.toDateString() === selectedDate.toDateString()
          const entryExists = hasEntry(date)
          const mood = getEntryMood(date)
          
          return (
            <button
              key={day}
              onClick={() => {
                setSelectedDate(date)
                setViewMode("entry")
              }}
              className={`h-12 rounded-lg border-2 transition relative ${
                isSelected
                  ? "border-purple-500 bg-purple-500/20"
                  : isToday
                  ? "border-yellow-500 bg-yellow-500/10"
                  : entryExists
                  ? "border-green-500/50 bg-green-500/10 hover:bg-green-500/20"
                  : "border-gray-600 hover:border-gray-500 hover:bg-gray-700/50"
              }`}
            >
              <span className="text-sm font-semibold">{day}</span>
              {entryExists && mood && (
                <div className="absolute bottom-1 right-1 text-xs">
                  {moodEmojis[mood]}
                </div>
              )}
            </button>
          )
        })}
      </div>
    </div>
  </div>
)

// Search View Component
const SearchView = ({ searchTerm, setSearchTerm, filteredEntries, setSelectedDate, setViewMode, moodEmojis }: any) => (
  <div className="space-y-4">
    {/* Search Input */}
    <div className="relative">
      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
      <input
        type="text"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        placeholder="Search entries by content or tags..."
        className="w-full bg-gray-700 border border-gray-600 rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-purple-400 focus:outline-none"
      />
    </div>

    {/* Search Results */}
    <div className="space-y-3">
      <h3 className="text-lg font-semibold">
        {searchTerm ? `Search Results (${filteredEntries.length})` : `All Entries (${filteredEntries.length})`}
      </h3>
      {filteredEntries.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          {searchTerm ? "No entries found matching your search." : "No journal entries yet."}
        </div>
      ) : (
        filteredEntries.slice(0, 10).map((entry: any) => (
          <div
            key={entry.id}
            onClick={() => {
              setSelectedDate(new Date(entry.date))
              setViewMode("entry")
            }}
            className="bg-gray-800/50 p-4 rounded-lg cursor-pointer hover:bg-gray-700/50 transition"
          >
            <div className="flex justify-between items-start mb-2">
              <span className="font-semibold">
                {new Date(entry.date).toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </span>
              <span className="text-2xl">{moodEmojis[entry.mood]}</span>
            </div>
            <p className="text-gray-300 text-sm line-clamp-3 mb-2">
              {entry.content.substring(0, 200)}...
            </p>
            {entry.tags.length > 0 && (
              <div className="flex gap-2 flex-wrap">
                {entry.tags.slice(0, 5).map((tag: string) => (
                  <span key={tag} className="text-xs bg-purple-600/20 text-purple-300 px-2 py-1 rounded">
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))
      )}
    </div>
  </div>
)

// Tags View Component
const TagsView = ({ availableTags, selectedTags, setSelectedTags, entries, filteredEntries, setSelectedDate, setViewMode, moodEmojis }: any) => {
  const toggleTag = (tag: string) => {
    setSelectedTags((prev: string[]) => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    )
  }

  const getTagCount = (tag: string) => {
    return entries.filter((entry: any) => entry.tags.includes(tag)).length
  }

  return (
    <div className="space-y-6">
      {/* Available Tags */}
      <div>
        <h3 className="text-lg font-semibold mb-3">Available Tags ({availableTags.length})</h3>
        {availableTags.length === 0 ? (
          <p className="text-gray-400">No tags created yet. Add tags to your journal entries to see them here.</p>
        ) : (
          <div className="flex gap-2 flex-wrap">
            {availableTags.map((tag: string) => (
              <button
                key={tag}
                onClick={() => toggleTag(tag)}
                className={`px-3 py-2 rounded-lg border-2 transition ${
                  selectedTags.includes(tag)
                    ? "border-purple-500 bg-purple-500/20 text-white"
                    : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
                }`}
              >
                #{tag} ({getTagCount(tag)})
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Clear Filters */}
      {selectedTags.length > 0 && (
        <button
          onClick={() => setSelectedTags([])}
          className="px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded-lg transition"
        >
          Clear Filters
        </button>
      )}

      {/* Filtered Entries */}
      <div>
        <h3 className="text-lg font-semibold mb-3">
          {selectedTags.length > 0 
            ? `Entries with selected tags (${filteredEntries.length})`
            : `All Entries (${filteredEntries.length})`
          }
        </h3>
        <div className="space-y-3">
          {filteredEntries.slice(0, 10).map((entry: any) => (
            <div
              key={entry.id}
              onClick={() => {
                setSelectedDate(new Date(entry.date))
                setViewMode("entry")
              }}
              className="bg-gray-800/50 p-4 rounded-lg cursor-pointer hover:bg-gray-700/50 transition"
            >
              <div className="flex justify-between items-start mb-2">
                <span className="font-semibold">
                  {new Date(entry.date).toLocaleDateString()}
                </span>
                <span className="text-2xl">{moodEmojis[entry.mood]}</span>
              </div>
              <p className="text-gray-300 text-sm line-clamp-2 mb-2">
                {entry.content.substring(0, 150)}...
              </p>
              <div className="flex gap-2 flex-wrap">
                {entry.tags.map((tag: string) => (
                  <span 
                    key={tag} 
                    className={`text-xs px-2 py-1 rounded ${
                      selectedTags.includes(tag)
                        ? "bg-purple-600/30 text-purple-200"
                        : "bg-gray-600/30 text-gray-300"
                    }`}
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// Analytics View Component
const AnalyticsView = ({ getStreakData, getMoodStats, entries, moodEmojis, moodColors }: any) => {
  const streakData = getStreakData()
  const moodStats = getMoodStats()

  return (
    <div className="space-y-6">
      {/* Streak Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-800/50 p-4 rounded-xl text-center">
          <div className="text-2xl font-bold text-green-400">{streakData.currentStreak}</div>
          <div className="text-sm text-gray-400">Current Streak</div>
        </div>
        <div className="bg-gray-800/50 p-4 rounded-xl text-center">
          <div className="text-2xl font-bold text-blue-400">{streakData.longestStreak}</div>
          <div className="text-sm text-gray-400">Longest Streak</div>
        </div>
        <div className="bg-gray-800/50 p-4 rounded-xl text-center">
          <div className="text-2xl font-bold text-purple-400">{streakData.totalEntries}</div>
          <div className="text-sm text-gray-400">Total Entries</div>
        </div>
      </div>

      {/* Mood Distribution */}
      <div className="bg-gray-800/50 p-6 rounded-xl">
        <h3 className="text-lg font-semibold mb-4">Mood Distribution</h3>
        {moodStats.length === 0 ? (
          <p className="text-gray-400">No mood data available yet.</p>
        ) : (
          <div className="space-y-3">
            {moodStats.map((stat: any) => (
              <div key={stat.mood} className="flex items-center gap-4">
                <div className="flex items-center gap-2 w-20">
                  <span className="text-xl">{moodEmojis[stat.mood]}</span>
                  <span className="text-sm capitalize">{stat.mood}</span>
                </div>
                <div className="flex-grow">
                  <div className="w-full bg-gray-700 rounded-full h-3">
                    <div 
                      className={`${moodColors[stat.mood]} h-3 rounded-full transition-all duration-500`}
                      style={{ width: `${stat.percentage}%` }}
                    />
                  </div>
                </div>
                <div className="text-sm text-gray-400 w-16 text-right">
                  {stat.count} ({stat.percentage}%)
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recent Activity */}
      <div className="bg-gray-800/50 p-6 rounded-xl">
        <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
        <div className="grid grid-cols-7 gap-2">
          {Array.from({ length: 28 }).map((_, index) => {
            const date = new Date()
            date.setDate(date.getDate() - (27 - index))
            const dateKey = date.toISOString().split('T')[0]
            const entry = entries.find((e: any) => e.date === dateKey)
            
            return (
              <div
                key={index}
                className={`w-8 h-8 rounded border-2 flex items-center justify-center text-xs ${
                  entry 
                    ? `${moodColors[entry.mood]} border-gray-600` 
                    : "bg-gray-700 border-gray-600"
                }`}
                title={entry ? `${date.toLocaleDateString()}: ${entry.mood}` : date.toLocaleDateString()}
              >
                {entry && moodEmojis[entry.mood]}
              </div>
            )
          })}
        </div>
        <div className="text-xs text-gray-400 mt-2">Last 28 days</div>
      </div>
    </div>
  )
}

// Entry View Component
const EntryView = ({ selectedDate, journalText, setJournalText, selectedMood, setSelectedMood, tags, setTags, availableTags, moodEmojis, moodColors, onSave, onBack, completedQuestTitle }: any) => {
  const [isGenerating, setIsGenerating] = useState(false)

  const generateAiPrompt = async () => {
    setIsGenerating(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))
      const prompts = [
        `Reflect on completing "${completedQuestTitle || "your recent task"}". What challenges did you overcome?`,
        `How did you feel when you finished "${completedQuestTitle || "this task"}"? What motivated you to push through?`,
        `What did you learn about yourself while working on "${completedQuestTitle || "this goal"}"?`,
        `Looking back at "${completedQuestTitle || "this achievement"}", what would you do differently next time?`,
        "What are three things you're grateful for today?",
        "Describe a moment today that made you smile.",
        "What's one thing you learned about yourself today?",
        "How did you grow or challenge yourself today?",
      ]
      const randomPrompt = prompts[Math.floor(Math.random() * prompts.length)]
      setJournalText((prev: string) => `${randomPrompt}\n\n${prev}`)
    } catch (error) {
      console.error("Error generating journal prompt:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="animate-fade-in p-2 space-y-6">
      <div className="flex items-center gap-4">
        <button
          onClick={onBack}
          className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold">
          Journal - {selectedDate.toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </h1>
      </div>

      {/* Mood Selector */}
      <div className="bg-gray-800/50 p-4 rounded-lg">
        <label className="block text-sm font-semibold mb-3">How was your day?</label>
        <div className="flex gap-3 flex-wrap">
          {Object.entries(moodEmojis).map(([mood, emoji]) => (
            <button
              key={mood}
              onClick={() => setSelectedMood(mood as any)}
              className={`p-3 rounded-lg border-2 transition ${
                selectedMood === mood
                  ? `border-purple-500 ${moodColors[mood as keyof typeof moodColors]}/20`
                  : "border-gray-600 hover:border-gray-500"
              }`}
            >
              <div className="text-2xl">{emoji}</div>
              <div className="text-xs capitalize mt-1">{mood}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Tags */}
      <div>
        <label className="block text-sm font-semibold mb-2">Tags (comma separated)</label>
        <input
          type="text"
          value={tags}
          onChange={(e) => setTags(e.target.value)}
          placeholder="work, personal, achievement, challenge..."
          className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:ring-2 focus:ring-purple-400 focus:outline-none"
        />
        {availableTags.length > 0 && (
          <div className="mt-2">
            <div className="text-xs text-gray-400 mb-2">Quick add:</div>
            <div className="flex gap-2 flex-wrap">
              {availableTags.slice(0, 8).map((tag: string) => (
                <button
                  key={tag}
                  onClick={() => {
                    const currentTags = tags.split(',').map(t => t.trim()).filter(t => t)
                    if (!currentTags.includes(tag)) {
                      setTags(currentTags.length > 0 ? `${tags}, ${tag}` : tag)
                    }
                  }}
                  className="text-xs bg-gray-600 hover:bg-gray-500 px-2 py-1 rounded transition"
                >
                  #{tag}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Journal Content */}
      <div className="relative">
        <textarea
          value={journalText}
          onChange={(e) => setJournalText(e.target.value)}
          className="w-full h-64 bg-gray-800 rounded-lg p-4 text-white placeholder-gray-400 focus:ring-2 focus:ring-purple-400 focus:outline-none resize-none"
          placeholder="Reflect on your day, your victories, and your challenges..."
        />
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={generateAiPrompt}
          disabled={isGenerating}
          className="flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-gray-700 hover:bg-gray-600 font-semibold transition disabled:opacity-50"
        >
          <Plus size={18} /> {isGenerating ? "Generating..." : "AI Prompt"}
        </button>
        <button 
          onClick={onSave}
          className="flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-purple-600 hover:bg-purple-500 font-bold transition"
        >
          <Save size={18} />
          Save Entry
        </button>
      </div>
    </div>
  )
}
