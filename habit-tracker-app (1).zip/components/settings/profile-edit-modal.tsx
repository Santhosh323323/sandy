"use client"

import { useState } from "react"
import { X, Save, User, Phone, Calendar, Mail, MapPin, Briefcase } from 'lucide-react'

interface ProfileEditModalProps {
  user: any
  onClose: () => void
  onSave: (updates: any) => void
  currentTheme: any
}

export default function ProfileEditModal({ user, onClose, onSave, currentTheme }: ProfileEditModalProps) {
  const [formData, setFormData] = useState({
    firstName: user.firstName || "",
    lastName: user.lastName || "",
    username: user.username || "",
    email: user.email || "",
    phoneNumber: user.phoneNumber || "",
    dateOfBirth: user.dateOfBirth || "",
    profession: user.profession || "",
    timezone: user.timezone || "",
    gender: user.gender || "prefer-not-to-say"
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave(formData)
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className={`${currentTheme.cardBg} rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border ${currentTheme.border} backdrop-blur-sm`}>
        <div className="sticky top-0 bg-inherit p-6 border-b border-gray-700/50 flex justify-between items-center">
          <h2 className="text-xl font-bold">Edit Profile</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Basic Info */}
          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <User className={currentTheme.text} />
              Basic Information
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold mb-2">First Name</label>
                <input
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  className={`w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:ring-2 ${currentTheme.ring}`}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Last Name</label>
                <input
                  type="text"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  className={`w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:ring-2 ${currentTheme.ring}`}
                />
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Phone className={currentTheme.text} />
              Contact Information
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-2">Username</label>
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className={`w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:ring-2 ${currentTheme.ring}`}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className={`w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:ring-2 ${currentTheme.ring}`}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Phone Number</label>
                <input
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                  className={`w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:ring-2 ${currentTheme.ring}`}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Date of Birth</label>
                <input
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                  className={`w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:ring-2 ${currentTheme.ring}`}
                />
              </div>
            </div>
          </div>

          {/* Professional Info */}
          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Briefcase className={currentTheme.text} />
              Professional Information
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-2">Profession</label>
                <select
                  value={formData.profession}
                  onChange={(e) => setFormData({ ...formData, profession: e.target.value })}
                  className={`w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:ring-2 ${currentTheme.ring}`}
                >
                  <option value="">Select profession</option>
                  <option value="Student">Student</option>
                  <option value="Software Developer">Software Developer</option>
                  <option value="Designer">Designer</option>
                  <option value="Manager">Manager</option>
                  <option value="Entrepreneur">Entrepreneur</option>
                  <option value="Teacher">Teacher</option>
                  <option value="Healthcare">Healthcare</option>
                  <option value="Marketing">Marketing</option>
                  <option value="Sales">Sales</option>
                  <option value="Consultant">Consultant</option>
                  <option value="Writer">Writer</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Timezone</label>
                <select
                  value={formData.timezone}
                  onChange={(e) => setFormData({ ...formData, timezone: e.target.value })}
                  className={`w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:ring-2 ${currentTheme.ring}`}
                >
                  <option value="America/New_York">Eastern Time (ET)</option>
                  <option value="America/Chicago">Central Time (CT)</option>
                  <option value="America/Denver">Mountain Time (MT)</option>
                  <option value="America/Los_Angeles">Pacific Time (PT)</option>
                  <option value="Europe/London">London (GMT)</option>
                  <option value="Europe/Paris">Paris (CET)</option>
                  <option value="Asia/Tokyo">Tokyo (JST)</option>
                  <option value="Asia/Shanghai">Shanghai (CST)</option>
                  <option value="Asia/Kolkata">India (IST)</option>
                  <option value="Australia/Sydney">Sydney (AEST)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Gender */}
          <div>
            <label className="block text-sm font-semibold mb-3">Gender Identity</label>
            <div className="grid grid-cols-2 gap-3">
              {[
                { value: "male", label: "Male" },
                { value: "female", label: "Female" },
                { value: "other", label: "Other" },
                { value: "prefer-not-to-say", label: "Prefer not to say" }
              ].map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setFormData({ ...formData, gender: option.value })}
                  className={`p-3 rounded-lg border-2 transition ${
                    formData.gender === option.value
                      ? `${currentTheme.border} ${currentTheme.primary}/20 text-white`
                      : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              className={`flex items-center gap-2 flex-1 px-6 py-3 ${currentTheme.primary} ${currentTheme.hover} rounded-lg font-semibold transition`}
            >
              <Save className="w-5 h-5" />
              Save Changes
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 bg-gray-600 hover:bg-gray-500 rounded-lg font-semibold transition"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
