"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { X, Crown, Star, Lock, CheckCircle } from 'lucide-react'

interface AvatarSettingsModalProps {
  onClose: () => void
  currentTheme: any
}

interface AvatarClass {
  id: string
  name: string
  description: string
  requiredLevel: number
  requiredXP: number
  unlocked: boolean
  equipped: boolean
  icon: string
  rarity: "common" | "rare" | "epic" | "legendary"
}

export default function AvatarSettingsModal({ onClose, currentTheme }: AvatarSettingsModalProps) {
  const { user, updateUser } = useAuth()
  
  const avatarClasses: AvatarClass[] = [
    {
      id: "knight",
      name: "Knight",
      description: "A brave warrior with strong defense",
      requiredLevel: 1,
      requiredXP: 0,
      unlocked: true,
      equipped: user?.avatar?.find(a => a.id === "knight")?.equipped || false,
      icon: "⚔️",
      rarity: "common"
    },
    {
      id: "mage",
      name: "Mage",
      description: "Master of arcane arts and wisdom",
      requiredLevel: 5,
      requiredXP: 500,
      unlocked: (user?.stats?.level || 1) >= 5 && (user?.stats?.totalXp || 0) >= 500,
      equipped: user?.avatar?.find(a => a.id === "mage")?.equipped || false,
      icon: "🧙‍♂️",
      rarity: "rare"
    },
    {
      id: "archer",
      name: "Archer",
      description: "Swift and precise ranged combatant",
      requiredLevel: 8,
      requiredXP: 800,
      unlocked: (user?.stats?.level || 1) >= 8 && (user?.stats?.totalXp || 0) >= 800,
      equipped: user?.avatar?.find(a => a.id === "archer")?.equipped || false,
      icon: "🏹",
      rarity: "rare"
    },
    {
      id: "warrior",
      name: "Warrior",
      description: "Fierce fighter with unmatched strength",
      requiredLevel: 12,
      requiredXP: 1500,
      unlocked: (user?.stats?.level || 1) >= 12 && (user?.stats?.totalXp || 0) >= 1500,
      equipped: user?.avatar?.find(a => a.id === "warrior")?.equipped || false,
      icon: "⚡",
      rarity: "epic"
    },
    {
      id: "ninja",
      name: "Ninja",
      description: "Silent assassin with deadly precision",
      requiredLevel: 15,
      requiredXP: 2500,
      unlocked: (user?.stats?.level || 1) >= 15 && (user?.stats?.totalXp || 0) >= 2500,
      equipped: user?.avatar?.find(a => a.id === "ninja")?.equipped || false,
      icon: "🥷",
      rarity: "epic"
    },
    {
      id: "paladin",
      name: "Paladin",
      description: "Holy champion of justice and light",
      requiredLevel: 20,
      requiredXP: 5000,
      unlocked: (user?.stats?.level || 1) >= 20 && (user?.stats?.totalXp || 0) >= 5000,
      equipped: user?.avatar?.find(a => a.id === "paladin")?.equipped || false,
      icon: "✨",
      rarity: "legendary"
    },
    {
      id: "dragon_lord",
      name: "Dragon Lord",
      description: "Master of dragons and ultimate power",
      requiredLevel: 30,
      requiredXP: 10000,
      unlocked: (user?.stats?.level || 1) >= 30 && (user?.stats?.totalXp || 0) >= 10000,
      equipped: user?.avatar?.find(a => a.id === "dragon_lord")?.equipped || false,
      icon: "🐉",
      rarity: "legendary"
    },
    {
      id: "cosmic_sage",
      name: "Cosmic Sage",
      description: "Transcendent being of infinite wisdom",
      requiredLevel: 50,
      requiredXP: 25000,
      unlocked: (user?.stats?.level || 1) >= 50 && (user?.stats?.totalXp || 0) >= 25000,
      equipped: user?.avatar?.find(a => a.id === "cosmic_sage")?.equipped || false,
      icon: "🌌",
      rarity: "legendary"
    }
  ]

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common": return "border-gray-500 bg-gray-500/10"
      case "rare": return "border-blue-500 bg-blue-500/10"
      case "epic": return "border-purple-500 bg-purple-500/10"
      case "legendary": return "border-yellow-500 bg-yellow-500/10"
      default: return "border-gray-500 bg-gray-500/10"
    }
  }

  const getRarityText = (rarity: string) => {
    switch (rarity) {
      case "common": return "text-gray-400"
      case "rare": return "text-blue-400"
      case "epic": return "text-purple-400"
      case "legendary": return "text-yellow-400"
      default: return "text-gray-400"
    }
  }

  const equipAvatar = (avatarId: string) => {
    if (!user) return

    const updatedAvatars = user.avatar.map((avatar: any) => ({
      ...avatar,
      equipped: avatar.id === avatarId
    }))

    updateUser({
      avatar: updatedAvatars
    })
  }

  const unlockedCount = avatarClasses.filter(avatar => avatar.unlocked).length
  const totalCount = avatarClasses.length

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className={`${currentTheme.cardBg} rounded-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto border ${currentTheme.border} backdrop-blur-sm`}>
        <div className="sticky top-0 bg-inherit p-6 border-b border-gray-700/50 flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Crown className="text-yellow-400" />
              Avatar Collection
            </h2>
            <p className="text-sm text-gray-400">
              Unlocked: {unlockedCount}/{totalCount} avatars
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex justify-between text-sm text-gray-400 mb-2">
              <span>Collection Progress</span>
              <span>{Math.round((unlockedCount / totalCount) * 100)}%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-purple-500 to-yellow-500 h-3 rounded-full transition-all duration-500"
                style={{ width: `${(unlockedCount / totalCount) * 100}%` }}
              />
            </div>
          </div>

          {/* Avatar Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {avatarClasses.map((avatar) => (
              <div
                key={avatar.id}
                className={`relative p-4 rounded-xl border-2 transition-all duration-300 ${
                  avatar.unlocked 
                    ? `${getRarityColor(avatar.rarity)} hover:scale-105 cursor-pointer` 
                    : "border-gray-700 bg-gray-800/30 opacity-60"
                } ${avatar.equipped ? "ring-2 ring-indigo-500" : ""}`}
                onClick={() => avatar.unlocked && equipAvatar(avatar.id)}
              >
                {/* Rarity Indicator */}
                <div className={`absolute top-2 right-2 text-xs font-bold px-2 py-1 rounded-full ${getRarityText(avatar.rarity)} bg-gray-900/50`}>
                  {avatar.rarity.toUpperCase()}
                </div>

                {/* Equipped Indicator */}
                {avatar.equipped && (
                  <div className="absolute top-2 left-2">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  </div>
                )}

                {/* Lock Indicator */}
                {!avatar.unlocked && (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-900/70 rounded-xl">
                    <Lock className="w-8 h-8 text-gray-400" />
                  </div>
                )}

                {/* Avatar Icon */}
                <div className="text-4xl mb-3 text-center">
                  {avatar.icon}
                </div>

                {/* Avatar Info */}
                <div className="text-center">
                  <h3 className="font-bold text-lg mb-1">{avatar.name}</h3>
                  <p className="text-xs text-gray-400 mb-3">{avatar.description}</p>
                  
                  {!avatar.unlocked && (
                    <div className="space-y-1">
                      <div className="text-xs text-red-400">
                        Requires Level {avatar.requiredLevel}
                      </div>
                      <div className="text-xs text-yellow-400">
                        {avatar.requiredXP} Total XP
                      </div>
                      <div className="text-xs text-gray-500">
                        Need: {Math.max(0, avatar.requiredXP - (user?.stats?.totalXp || 0))} more XP
                      </div>
                    </div>
                  )}

                  {avatar.unlocked && !avatar.equipped && (
                    <button className="text-xs bg-indigo-600 hover:bg-indigo-500 px-3 py-1 rounded-full transition">
                      Equip
                    </button>
                  )}

                  {avatar.equipped && (
                    <div className="text-xs text-green-400 font-semibold">
                      Currently Equipped
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Next Unlock Preview */}
          <div className="mt-8 p-4 bg-gray-800/50 rounded-xl border border-gray-700">
            <h3 className="font-bold mb-3 flex items-center gap-2">
              <Star className="text-yellow-400" />
              Next Unlock
            </h3>
            {(() => {
              const nextAvatar = avatarClasses.find(avatar => !avatar.unlocked)
              if (!nextAvatar) {
                return <p className="text-green-400">🎉 All avatars unlocked! You're a true master!</p>
              }
              
              const xpNeeded = nextAvatar.requiredXP - (user?.stats?.totalXp || 0)
              const levelsNeeded = Math.max(0, nextAvatar.requiredLevel - (user?.stats?.level || 1))
              
              return (
                <div className="flex items-center gap-4">
                  <div className="text-3xl">{nextAvatar.icon}</div>
                  <div className="flex-grow">
                    <h4 className="font-semibold">{nextAvatar.name}</h4>
                    <p className="text-sm text-gray-400">{nextAvatar.description}</p>
                    <div className="text-xs text-yellow-400 mt-1">
                      {xpNeeded > 0 && `${xpNeeded} XP needed`}
                      {levelsNeeded > 0 && ` • ${levelsNeeded} levels needed`}
                    </div>
                  </div>
                </div>
              )
            })()}
          </div>
        </div>
      </div>
    </div>
  )
}
