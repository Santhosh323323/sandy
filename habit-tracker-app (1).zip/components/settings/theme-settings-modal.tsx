"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { useTheme } from "@/contexts/theme-context"
import { X, Palette, Sparkles } from 'lucide-react'
import CustomThemeModal from "./custom-theme-modal"

interface ThemeSettingsModalProps {
  onClose: () => void
  currentTheme: any
}

export default function ThemeSettingsModal({ onClose, currentTheme }: ThemeSettingsModalProps) {
  const { user, updateUser } = useAuth()
  const { gameTheme, setGameTheme, theme, setTheme } = useTheme()
  const [showCustomThemeModal, setShowCustomThemeModal] = useState(false)

  const gameThemes = [
    { 
      value: "fantasy", 
      label: "Fantasy", 
      emoji: "🏰", 
      description: "Medieval castles and magical quests",
      colors: ["purple", "indigo", "pink"]
    },
    { 
      value: "sci-fi", 
      label: "Sci-Fi", 
      emoji: "🚀", 
      description: "Futuristic technology and space exploration",
      colors: ["cyan", "blue", "teal"]
    },
    { 
      value: "nature", 
      label: "Nature", 
      emoji: "🌿", 
      description: "Earth tones and natural elements",
      colors: ["green", "emerald", "lime"]
    },
    { 
      value: "custom", 
      label: "Custom", 
      emoji: "🎨", 
      description: "Create your own unique theme",
      colors: ["rainbow", "custom", "personal"]
    }
  ]

  const colorThemes = [
    { value: "indigo", label: "Indigo", color: "bg-indigo-500" },
    { value: "teal", label: "Teal", color: "bg-teal-500" },
    { value: "crimson", label: "Crimson", color: "bg-red-500" }
  ]

  const handleGameThemeChange = (newGameTheme: string) => {
    if (newGameTheme === "custom") {
      setShowCustomThemeModal(true)
      return
    }
    setGameTheme(newGameTheme)
    updateUser({
      preferences: {
        ...user?.preferences,
        gameTheme: newGameTheme
      }
    })
  }

  const handleColorThemeChange = (newColorTheme: string) => {
    setTheme(newColorTheme)
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className={`${currentTheme.cardBg} rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border ${currentTheme.border} backdrop-blur-sm`}>
        <div className="sticky top-0 bg-inherit p-6 border-b border-gray-700/50 flex justify-between items-center">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Palette className={currentTheme.text} />
            Theme & Appearance
          </h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-8">
          {/* Game Theme Selection */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Sparkles className={currentTheme.text} />
              Game Theme
            </h3>
            <p className="text-sm text-gray-400 mb-4">Choose the visual style that motivates you</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {gameThemes.map((themeOption) => (
                <button
                  key={themeOption.value}
                  onClick={() => handleGameThemeChange(themeOption.value)}
                  className={`p-4 rounded-xl border-2 transition text-left ${
                    gameTheme === themeOption.value
                      ? `${currentTheme.border} ${currentTheme.primary}/20 text-white`
                      : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
                  }`}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-2xl">{themeOption.emoji}</span>
                    <div>
                      <h4 className="font-semibold">{themeOption.label}</h4>
                      <p className="text-xs opacity-75">{themeOption.description}</p>
                    </div>
                  </div>
                  <div className="flex gap-1 mt-2">
                    {themeOption.colors.map((color, index) => (
                      <div key={index} className={`w-4 h-4 rounded-full bg-${color}-500`} />
                    ))}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Color Theme Selection */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Color Accent</h3>
            <p className="text-sm text-gray-400 mb-4">Select your preferred accent color</p>
            <div className="grid grid-cols-3 gap-3">
              {colorThemes.map((colorTheme) => (
                <button
                  key={colorTheme.value}
                  onClick={() => handleColorThemeChange(colorTheme.value)}
                  className={`p-4 rounded-lg border-2 transition ${
                    theme === colorTheme.value
                      ? `${currentTheme.border} ${currentTheme.primary}/20 text-white`
                      : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
                  }`}
                >
                  <div className={`w-8 h-8 ${colorTheme.color} rounded-full mx-auto mb-2`} />
                  <div className="text-sm font-semibold">{colorTheme.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Preview */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Preview</h3>
            <div className={`${currentTheme.cardBg} p-4 rounded-xl border ${currentTheme.border} backdrop-blur-sm`}>
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-10 h-10 ${currentTheme.primary} rounded-full flex items-center justify-center text-white font-bold`}>
                  A
                </div>
                <div>
                  <h4 className="font-semibold">Sample Task</h4>
                  <p className="text-sm text-gray-400">This is how your tasks will look</p>
                </div>
                <div className={`ml-auto text-sm ${currentTheme.accent} font-semibold`}>+50 XP</div>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className={`${currentTheme.primary} h-2 rounded-full w-3/4`} />
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-gray-700/50">
          <button
            onClick={onClose}
            className={`w-full px-6 py-3 ${currentTheme.primary} ${currentTheme.hover} rounded-lg font-semibold transition`}
          >
            Apply Changes
          </button>
        </div>
      </div>
      {showCustomThemeModal && (
        <CustomThemeModal
          onClose={() => setShowCustomThemeModal(false)}
          onSave={(customTheme) => {
            // Handle custom theme save
            console.log("Custom theme saved:", customTheme)
          }}
          currentTheme={currentTheme}
        />
      )}
    </div>
  )
}
