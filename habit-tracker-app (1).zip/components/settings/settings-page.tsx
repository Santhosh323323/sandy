"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { useTheme } from "@/contexts/theme-context"
import { User, Palette, Shield, HelpCircle, Bell, ChevronRight, LogOut, Edit, Trash2, Moon, Sun, Monitor, Crown } from 'lucide-react'
import ProfileEditModal from "./profile-edit-modal"
import ThemeSettingsModal from "./theme-settings-modal"
import AvatarSettingsModal from "./avatar-settings-modal"

interface SettingsPageProps {
  navigate: (page: string) => void
}

export default function SettingsPage({ navigate }: SettingsPageProps) {
  const { user, updateUser, logout } = useAuth()
  const { themes, gameTheme, setGameTheme } = useTheme()
  const [showProfileEdit, setShowProfileEdit] = useState(false)
  const [showThemeSettings, setShowThemeSettings] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [showAvatarSettings, setShowAvatarSettings] = useState(false)
  
  const currentTheme = themes?.indigo || {}

  if (!user) return null

  const handleDeleteAccount = () => {
    if (showDeleteConfirm) {
      // Clear all user data
      localStorage.removeItem("currentUser")
      localStorage.removeItem("users")
      localStorage.removeItem("journalEntries")
      localStorage.removeItem("taskHistory")
      localStorage.removeItem("taskTiming")
      logout()
    } else {
      setShowDeleteConfirm(true)
    }
  }

  const handleLogout = () => {
    logout()
  }

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate("profile")}
          className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition"
        >
          <ChevronRight className="w-5 h-5 rotate-180" />
        </button>
        <h1 className="text-2xl font-bold">Settings</h1>
      </div>

      {/* User Info Card */}
      <div className={`${currentTheme.cardBg} p-4 rounded-xl border ${currentTheme.border} backdrop-blur-sm`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 ${currentTheme.primary} rounded-full flex items-center justify-center text-lg font-bold text-white`}>
            {user.firstName?.[0] || user.username[0].toUpperCase()}
          </div>
          <div className="flex-grow">
            <h2 className="font-bold">
              {user.firstName && user.lastName 
                ? `${user.firstName} ${user.lastName}` 
                : user.username}
            </h2>
            <p className="text-sm text-gray-400">{user.email}</p>
          </div>
          <div className={`text-sm ${currentTheme.accent} font-semibold`}>
            Level {user.stats.level}
          </div>
        </div>
      </div>

      {/* Account Settings */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-gray-300">Account</h3>
        
        <button
          onClick={() => setShowProfileEdit(true)}
          className={`w-full flex items-center gap-4 p-4 ${currentTheme.cardBg} hover:bg-gray-700/60 rounded-xl border ${currentTheme.border} transition group backdrop-blur-sm`}
        >
          <div className={`${currentTheme.text} group-hover:${currentTheme.accent}`}>
            <Edit />
          </div>
          <div className="flex-grow text-left">
            <h3 className="font-semibold">Edit Profile</h3>
            <p className="text-sm text-gray-400">Update your personal information</p>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white" />
        </button>

        <button
          onClick={handleLogout}
          className={`w-full flex items-center gap-4 p-4 ${currentTheme.cardBg} hover:bg-gray-700/60 rounded-xl border ${currentTheme.border} transition group backdrop-blur-sm`}
        >
          <div className="text-orange-400 group-hover:text-orange-300">
            <LogOut />
          </div>
          <div className="flex-grow text-left">
            <h3 className="font-semibold">Sign Out</h3>
            <p className="text-sm text-gray-400">Sign out of your account</p>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white" />
        </button>
      </div>

      {/* Appearance Settings */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-gray-300">Appearance</h3>
        
        <button
          onClick={() => setShowThemeSettings(true)}
          className={`w-full flex items-center gap-4 p-4 ${currentTheme.cardBg} hover:bg-gray-700/60 rounded-xl border ${currentTheme.border} transition group backdrop-blur-sm`}
        >
          <div className={`${currentTheme.text} group-hover:${currentTheme.accent}`}>
            <Palette />
          </div>
          <div className="flex-grow text-left">
            <h3 className="font-semibold">Theme & Appearance</h3>
            <p className="text-sm text-gray-400">Customize colors and visual style</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500 capitalize">{gameTheme}</span>
            <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white" />
          </div>
        </button>

        <button
          onClick={() => setShowAvatarSettings(true)}
          className={`w-full flex items-center gap-4 p-4 ${currentTheme.cardBg} hover:bg-gray-700/60 rounded-xl border ${currentTheme.border} transition group backdrop-blur-sm`}
        >
          <div className={`${currentTheme.text} group-hover:${currentTheme.accent}`}>
            <Crown />
          </div>
          <div className="flex-grow text-left">
            <h3 className="font-semibold">Avatar Collection</h3>
            <p className="text-sm text-gray-400">Manage your unlocked avatars</p>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white" />
        </button>

        {/* Quick Theme Toggle */}
        <div className={`${currentTheme.cardBg} p-4 rounded-xl border ${currentTheme.border} backdrop-blur-sm`}>
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-semibold">Display Mode</h4>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[
              { value: "light", label: "Light", icon: <Sun className="w-4 h-4" /> },
              { value: "dark", label: "Dark", icon: <Moon className="w-4 h-4" /> },
              { value: "system", label: "System", icon: <Monitor className="w-4 h-4" /> }
            ].map((mode) => (
              <button
                key={mode.value}
                onClick={() => updateUser({ 
                  preferences: { ...user.preferences, theme: mode.value as any } 
                })}
                className={`flex items-center justify-center gap-2 p-3 rounded-lg border-2 transition ${
                  user.preferences.theme === mode.value
                    ? `${currentTheme.border} ${currentTheme.primary}/20 text-white`
                    : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
                }`}
              >
                {mode.icon}
                <span className="text-sm">{mode.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* App Settings */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-gray-300">App Settings</h3>
        
        <button
          className={`w-full flex items-center gap-4 p-4 ${currentTheme.cardBg} hover:bg-gray-700/60 rounded-xl border ${currentTheme.border} transition group backdrop-blur-sm`}
        >
          <div className={`${currentTheme.text} group-hover:${currentTheme.accent}`}>
            <Bell />
          </div>
          <div className="flex-grow text-left">
            <h3 className="font-semibold">Notifications</h3>
            <p className="text-sm text-gray-400">Manage alerts and reminders</p>
          </div>
          <div className="flex items-center gap-2">
            <button className={`w-12 h-6 ${user.preferences.notifications ? 'bg-indigo-600' : 'bg-gray-600'} rounded-full p-1 transition`}>
              <div className={`w-4 h-4 bg-white rounded-full transition-transform ${user.preferences.notifications ? 'translate-x-6' : 'translate-x-0'}`} />
            </button>
          </div>
        </button>
      </div>

      {/* Privacy Settings */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-gray-300">Privacy & Security</h3>
        
        <div className={`${currentTheme.cardBg} p-4 rounded-xl border ${currentTheme.border} backdrop-blur-sm`}>
          <div className="flex items-center gap-4 mb-4">
            <Shield className={currentTheme.text} />
            <div>
              <h4 className="font-semibold">Data & Privacy</h4>
              <p className="text-sm text-gray-400">Your data is stored locally on your device</p>
            </div>
          </div>
          <div className="space-y-3 text-sm text-gray-300">
            <div className="flex justify-between">
              <span>Data Storage</span>
              <span className="text-green-400">Local Only</span>
            </div>
            <div className="flex justify-between">
              <span>Analytics</span>
              <span className="text-red-400">Disabled</span>
            </div>
            <div className="flex justify-between">
              <span>Third-party Sharing</span>
              <span className="text-red-400">None</span>
            </div>
          </div>
        </div>
      </div>

      {/* Help & Support */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-gray-300">Support</h3>
        
        <button
          className={`w-full flex items-center gap-4 p-4 ${currentTheme.cardBg} hover:bg-gray-700/60 rounded-xl border ${currentTheme.border} transition group backdrop-blur-sm`}
        >
          <div className={`${currentTheme.text} group-hover:${currentTheme.accent}`}>
            <HelpCircle />
          </div>
          <div className="flex-grow text-left">
            <h3 className="font-semibold">Help & Support</h3>
            <p className="text-sm text-gray-400">Get assistance and contact support</p>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white" />
        </button>
      </div>

      {/* Danger Zone */}
      <div className={`${currentTheme.cardBg} p-6 rounded-xl border border-red-500/30 backdrop-blur-sm`}>
        <h3 className="font-bold text-lg mb-4 text-red-400">Danger Zone</h3>
        <div className="space-y-3">
          <button
            onClick={handleDeleteAccount}
            className={`w-full flex items-center gap-3 p-3 ${showDeleteConfirm ? 'bg-red-600 hover:bg-red-700' : 'bg-red-600/20 hover:bg-red-600/30'} rounded-lg transition`}
          >
            <Trash2 className="w-5 h-5" />
            <div className="flex-grow text-left">
              <div className="font-semibold">
                {showDeleteConfirm ? "Click again to confirm deletion" : "Delete Account"}
              </div>
              <div className="text-sm opacity-75">
                {showDeleteConfirm ? "This action cannot be undone" : "Permanently delete your account and all data"}
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Modals */}
      {showProfileEdit && (
        <ProfileEditModal
          user={user}
          onClose={() => setShowProfileEdit(false)}
          onSave={(updates) => {
            updateUser(updates)
            setShowProfileEdit(false)
          }}
          currentTheme={currentTheme}
        />
      )}

      {showThemeSettings && (
        <ThemeSettingsModal
          onClose={() => setShowThemeSettings(false)}
          currentTheme={currentTheme}
        />
      )}

      {showAvatarSettings && (
        <AvatarSettingsModal
          onClose={() => setShowAvatarSettings(false)}
          currentTheme={currentTheme}
        />
      )}
    </div>
  )
}
