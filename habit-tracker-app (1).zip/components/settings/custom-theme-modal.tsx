"use client"

import { useState } from "react"
import { X, Palette, Save, RotateCcw } from 'lucide-react'

interface CustomThemeModalProps {
  onClose: () => void
  onSave: (theme: any) => void
  currentTheme: any
}

export default function CustomThemeModal({ onClose, onSave, currentTheme }: CustomThemeModalProps) {
  const [customTheme, setCustomTheme] = useState({
    name: "My Custom Theme",
    primary: "#6366f1",
    secondary: "#8b5cf6",
    accent: "#f59e0b",
    background: "#111827",
    surface: "#1f2937",
    text: "#f3f4f6",
    textSecondary: "#9ca3af"
  })

  const [previewMode, setPreviewMode] = useState(false)

  const colorOptions = [
    { name: "Primary", key: "primary", description: "Main buttons and highlights" },
    { name: "Secondary", key: "secondary", description: "Secondary elements" },
    { name: "Accent", key: "accent", description: "XP and rewards" },
    { name: "Background", key: "background", description: "Main background" },
    { name: "Surface", key: "surface", description: "Cards and panels" },
    { name: "Text", key: "text", description: "Primary text" },
    { name: "Text Secondary", key: "textSecondary", description: "Secondary text" }
  ]

  const presetThemes = [
    {
      name: "Ocean Breeze",
      primary: "#0ea5e9",
      secondary: "#06b6d4",
      accent: "#f59e0b",
      background: "#0c1821",
      surface: "#1e3a8a",
      text: "#f0f9ff",
      textSecondary: "#bae6fd"
    },
    {
      name: "Forest Night",
      primary: "#059669",
      secondary: "#10b981",
      accent: "#f59e0b",
      background: "#064e3b",
      surface: "#065f46",
      text: "#ecfdf5",
      textSecondary: "#a7f3d0"
    },
    {
      name: "Sunset Glow",
      primary: "#dc2626",
      secondary: "#ea580c",
      accent: "#fbbf24",
      background: "#7f1d1d",
      surface: "#991b1b",
      text: "#fef2f2",
      textSecondary: "#fecaca"
    },
    {
      name: "Purple Haze",
      primary: "#7c3aed",
      secondary: "#a855f7",
      accent: "#f59e0b",
      background: "#581c87",
      surface: "#6b21a8",
      text: "#faf5ff",
      textSecondary: "#d8b4fe"
    }
  ]

  const handleColorChange = (key: string, value: string) => {
    setCustomTheme(prev => ({ ...prev, [key]: value }))
  }

  const applyPreset = (preset: any) => {
    setCustomTheme(prev => ({ ...prev, ...preset }))
  }

  const resetToDefault = () => {
    setCustomTheme({
      name: "My Custom Theme",
      primary: "#6366f1",
      secondary: "#8b5cf6",
      accent: "#f59e0b",
      background: "#111827",
      surface: "#1f2937",
      text: "#f3f4f6",
      textSecondary: "#9ca3af"
    })
  }

  const handleSave = () => {
    onSave(customTheme)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className={`${previewMode ? 'bg-gray-800' : currentTheme.cardBg} rounded-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto border ${currentTheme.border} backdrop-blur-sm`}
           style={previewMode ? { backgroundColor: customTheme.surface } : {}}>
        
        <div className="sticky top-0 bg-inherit p-6 border-b border-gray-700/50 flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Palette className="text-purple-400" />
              Custom Theme Creator
            </h2>
            <p className="text-sm text-gray-400">Design your perfect productivity environment</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPreviewMode(!previewMode)}
              className="px-3 py-1 text-sm bg-gray-600 hover:bg-gray-500 rounded transition"
            >
              {previewMode ? "Edit Mode" : "Preview"}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Theme Name */}
          <div>
            <label className="block text-sm font-semibold mb-2">Theme Name</label>
            <input
              type="text"
              value={customTheme.name}
              onChange={(e) => setCustomTheme(prev => ({ ...prev, name: e.target.value }))}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-purple-500"
            />
          </div>

          {/* Preset Themes */}
          <div>
            <h3 className="font-semibold mb-3">Quick Presets</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {presetThemes.map((preset, index) => (
                <button
                  key={index}
                  onClick={() => applyPreset(preset)}
                  className="p-3 rounded-lg border border-gray-600 hover:border-gray-500 transition text-left"
                >
                  <div className="flex gap-2 mb-2">
                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: preset.primary }} />
                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: preset.secondary }} />
                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: preset.accent }} />
                  </div>
                  <div className="text-sm font-semibold">{preset.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Color Customization */}
          <div>
            <h3 className="font-semibold mb-3">Color Customization</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {colorOptions.map((option) => (
                <div key={option.key} className="space-y-2">
                  <label className="block text-sm font-semibold">{option.name}</label>
                  <p className="text-xs text-gray-400">{option.description}</p>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={customTheme[option.key as keyof typeof customTheme]}
                      onChange={(e) => handleColorChange(option.key, e.target.value)}
                      className="w-12 h-10 rounded border border-gray-600 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={customTheme[option.key as keyof typeof customTheme]}
                      onChange={(e) => handleColorChange(option.key, e.target.value)}
                      className="flex-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm font-mono"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Preview */}
          <div>
            <h3 className="font-semibold mb-3">Preview</h3>
            <div className="p-4 rounded-lg border border-gray-600" 
                 style={{ 
                   backgroundColor: customTheme.surface,
                   color: customTheme.text,
                   borderColor: customTheme.primary + '50'
                 }}>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold"
                     style={{ backgroundColor: customTheme.primary }}>
                  A
                </div>
                <div>
                  <h4 className="font-semibold" style={{ color: customTheme.text }}>Sample Task</h4>
                  <p className="text-sm" style={{ color: customTheme.textSecondary }}>This is how your tasks will look</p>
                </div>
                <div className="ml-auto text-sm font-semibold" style={{ color: customTheme.accent }}>+50 XP</div>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="h-2 rounded-full w-3/4" style={{ backgroundColor: customTheme.primary }} />
              </div>
              <button className="mt-3 px-4 py-2 rounded-lg font-semibold text-white transition"
                      style={{ backgroundColor: customTheme.secondary }}>
                Sample Button
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4 border-t border-gray-700">
            <button
              onClick={resetToDefault}
              className="flex items-center gap-2 px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded-lg transition"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </button>
            <button
              onClick={handleSave}
              className="flex items-center gap-2 flex-1 px-6 py-2 bg-purple-600 hover:bg-purple-500 rounded-lg font-semibold transition"
            >
              <Save className="w-4 h-4" />
              Save Custom Theme
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
