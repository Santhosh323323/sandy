"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import AIOnboardingSession from "./ai-onboarding-session"
import { ChevronRight, ChevronLeft, User, Briefcase, Globe, Palette, Timer, Zap, Phone, Calendar, Bot, SkipForward } from 'lucide-react'

interface OnboardingFlowProps {
  onComplete: () => void
}

export default function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [showAISession, setShowAISession] = useState(false)
  const [skipAISetup, setSkipAISetup] = useState(false)
  const [aiGeneratedTasks, setAiGeneratedTasks] = useState<any>(null)
  const { user, updateUser } = useAuth()
  const [formData, setFormData] = useState({
    dateOfBirth: user?.dateOfBirth || "",
    phoneNumber: user?.phoneNumber || "",
    gender: user?.gender || "prefer-not-to-say",
    profession: user?.profession || "",
    timezone: user?.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone,
    theme: user?.preferences.theme || "dark",
    gameTheme: user?.preferences.gameTheme || "fantasy",
    timeManagement: user?.preferences.timeManagement || "pomodoro",
    intensity: user?.preferences.intensity || "moderate",
    motivationalContent: user?.preferences.motivationalContent || "music"
  })

  const steps = [
    { title: "Personal Info", icon: <User /> },
    { title: "Contact Details", icon: <Phone /> },
    { title: "Profession", icon: <Briefcase /> },
    { title: "Location", icon: <Globe /> },
    { title: "Appearance", icon: <Palette /> },
    { title: "Preferences", icon: <Timer /> },
    { title: "Motivation", icon: <Zap /> },
    { title: "AI Setup", icon: <Bot /> }
  ]

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      // Last step - AI Setup choice
      if (skipAISetup) {
        handleComplete()
      } else {
        setShowAISession(true)
      }
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSkipAI = () => {
    setSkipAISetup(true)
    handleComplete()
  }

  const handleAISessionComplete = (tasks: any) => {
    setAiGeneratedTasks(tasks)
    handleComplete()
  }

  const handleComplete = () => {
    if (user) {
      updateUser({
        dateOfBirth: formData.dateOfBirth,
        phoneNumber: formData.phoneNumber,
        gender: formData.gender as any,
        profession: formData.profession,
        timezone: formData.timezone,
        preferences: {
          ...user.preferences,
          theme: formData.theme as any,
          gameTheme: formData.gameTheme as any,
          timeManagement: formData.timeManagement as any,
          intensity: formData.intensity as any,
          motivationalContent: formData.motivationalContent as any
        },
        onboardingCompleted: true,
        aiGeneratedTasks: aiGeneratedTasks, // Will be null if skipped
        usedAISetup: !skipAISetup
      })
    }
    onComplete()
  }

  if (showAISession) {
    return <AIOnboardingSession onComplete={handleAISessionComplete} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-2xl font-bold text-white">Setup Your Quest</h1>
            <span className="text-gray-300">{currentStep + 1} of {steps.length}</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-purple-500 to-indigo-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 shadow-2xl">
          {currentStep === 0 && <PersonalInfoStep formData={formData} setFormData={setFormData} />}
          {currentStep === 1 && <ContactDetailsStep formData={formData} setFormData={setFormData} />}
          {currentStep === 2 && <ProfessionStep formData={formData} setFormData={setFormData} />}
          {currentStep === 3 && <LocationStep formData={formData} setFormData={setFormData} />}
          {currentStep === 4 && <AppearanceStep formData={formData} setFormData={setFormData} />}
          {currentStep === 5 && <PreferencesStep formData={formData} setFormData={setFormData} />}
          {currentStep === 6 && <MotivationStep formData={formData} setFormData={setFormData} />}
          {currentStep === 7 && <AISetupChoiceStep />}

          {/* Navigation */}
          <div className="flex justify-between mt-8">
            <button
              onClick={handleBack}
              disabled={currentStep === 0}
              className="flex items-center gap-2 px-6 py-3 bg-gray-600 hover:bg-gray-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg font-semibold transition"
            >
              <ChevronLeft className="w-5 h-5" />
              Back
            </button>
            
            <div className="flex gap-3">
              {currentStep === steps.length - 1 && (
                <button
                  onClick={handleSkipAI}
                  className="flex items-center gap-2 px-6 py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-semibold transition"
                >
                  <SkipForward className="w-5 h-5" />
                  Skip AI Setup
                </button>
              )}
              
              <button
                onClick={handleNext}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-lg font-semibold transition"
              >
                {currentStep === steps.length - 1 ? "Start AI Setup" : "Next"}
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

const AISetupChoiceStep = () => (
  <div className="space-y-6">
    <div className="text-center mb-6">
      <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-4">
        <Bot className="w-8 h-8 text-white" />
      </div>
      <h2 className="text-2xl font-bold text-white mb-2">AI Task Setup</h2>
      <p className="text-gray-300">Would you like our AI to create personalized tasks for you?</p>
    </div>
    
    <div className="grid grid-cols-1 gap-4">
      <div className="bg-gradient-to-r from-purple-600/20 to-indigo-600/20 p-6 rounded-xl border border-purple-500/30">
        <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
          <Bot className="text-purple-400" />
          AI-Powered Setup (Recommended)
        </h3>
        <ul className="text-sm text-gray-300 space-y-2">
          <li>• Personalized tasks based on your goals and routine</li>
          <li>• Smart categorization into Main, Side, and Mini tasks</li>
          <li>• Tailored to your profession and preferences</li>
          <li>• Interactive conversation to understand your needs</li>
        </ul>
      </div>
      
      <div className="bg-gray-700/30 p-6 rounded-xl border border-gray-600/50">
        <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
          <SkipForward className="text-gray-400" />
          Quick Start
        </h3>
        <ul className="text-sm text-gray-300 space-y-2">
          <li>• Start with sample tasks</li>
          <li>• Add your own tasks manually</li>
          <li>• Skip the AI conversation</li>
          <li>• Get started immediately</li>
        </ul>
      </div>
    </div>
    
    <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
      <p className="text-sm text-blue-200">
        💡 <strong>Tip:</strong> You can always access AI features later from the app menu, even if you skip this step.
      </p>
    </div>
  </div>
)

// Keep all the existing step components unchanged...
const PersonalInfoStep = ({ formData, setFormData }: any) => (
  <div className="space-y-6">
    <div className="text-center mb-6">
      <h2 className="text-2xl font-bold text-white mb-2">Tell us about yourself</h2>
      <p className="text-gray-300">This helps us personalize your experience</p>
    </div>
    
    <div>
      <label className="block text-white font-semibold mb-3">Gender Identity</label>
      <div className="grid grid-cols-2 gap-3">
        {[
          { value: "male", label: "Male" },
          { value: "female", label: "Female" },
          { value: "other", label: "Other" },
          { value: "prefer-not-to-say", label: "Prefer not to say" }
        ].map((option) => (
          <button
            key={option.value}
            onClick={() => setFormData({ ...formData, gender: option.value })}
            className={`p-3 rounded-lg border-2 transition ${
              formData.gender === option.value
                ? "border-purple-500 bg-purple-500/20 text-white"
                : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  </div>
)

const ContactDetailsStep = ({ formData, setFormData }: any) => {
  const [ageError, setAgeError] = useState("")
  
  const validateAge = (dateOfBirth: string) => {
    if (!dateOfBirth) return ""
    
    const today = new Date()
    const birthDate = new Date(dateOfBirth)
    let age = today.getFullYear() - birthDate.getFullYear()
    const monthDiff = today.getMonth() - birthDate.getMonth()
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--
    }
    
    if (birthDate > today) {
      return "Date of birth cannot be in the future"
    }
    
    if (age < 18) {
      return "You must be 18 years or older to use this app"
    }
    
    return ""
  }

  const handleDateChange = (date: string) => {
    setFormData({ ...formData, dateOfBirth: date })
    const error = validateAge(date)
    setAgeError(error)
  }

  // Calculate max date (18 years ago)
  const maxDate = new Date()
  maxDate.setFullYear(maxDate.getFullYear() - 18)
  const maxDateString = maxDate.toISOString().split('T')[0]

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-white mb-2">Contact Information</h2>
        <p className="text-gray-300">We'll use this for important notifications</p>
      </div>
      
      <div>
        <label className="block text-white font-semibold mb-2">Date of Birth</label>
        <div className="relative">
          <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="date"
            value={formData.dateOfBirth}
            onChange={(e) => handleDateChange(e.target.value)}
            max={maxDateString}
            className={`w-full bg-white/10 border rounded-lg pl-10 pr-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent ${
              ageError ? 'border-red-500' : 'border-white/20'
            }`}
            required
          />
        </div>
        {ageError && (
          <p className="text-red-400 text-sm mt-1">{ageError}</p>
        )}
        <p className="text-gray-400 text-xs mt-1">You must be 18 years or older to use this app</p>
      </div>

      <div>
        <label className="block text-white font-semibold mb-2">Phone Number</label>
        <div className="relative">
          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="tel"
            value={formData.phoneNumber}
            onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
            placeholder="+1 (555) 123-4567"
            className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            required
          />
        </div>
      </div>
    </div>
  )
}

const ProfessionStep = ({ formData, setFormData }: any) => (
  <div className="space-y-6">
    <div className="text-center mb-6">
      <h2 className="text-2xl font-bold text-white mb-2">What's your profession?</h2>
      <p className="text-gray-300">We'll customize features based on your work style</p>
    </div>
    
    <div className="grid grid-cols-2 gap-3">
      {[
        "Student", "Software Developer", "Designer", "Manager",
        "Entrepreneur", "Teacher", "Healthcare", "Marketing",
        "Sales", "Consultant", "Writer", "Other"
      ].map((profession) => (
        <button
          key={profession}
          onClick={() => setFormData({ ...formData, profession })}
          className={`p-3 rounded-lg border-2 transition ${
            formData.profession === profession
              ? "border-purple-500 bg-purple-500/20 text-white"
              : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
          }`}
        >
          {profession}
        </button>
      ))}
    </div>
  </div>
)

const LocationStep = ({ formData, setFormData }: any) => (
  <div className="space-y-6">
    <div className="text-center mb-6">
      <h2 className="text-2xl font-bold text-white mb-2">Select your timezone</h2>
      <p className="text-gray-300">For accurate scheduling and reminders</p>
    </div>
    
    <select
      value={formData.timezone}
      onChange={(e) => setFormData({ ...formData, timezone: e.target.value })}
      className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500"
    >
      <option value="America/New_York">Eastern Time (ET)</option>
      <option value="America/Chicago">Central Time (CT)</option>
      <option value="America/Denver">Mountain Time (MT)</option>
      <option value="America/Los_Angeles">Pacific Time (PT)</option>
      <option value="Europe/London">London (GMT)</option>
      <option value="Europe/Paris">Paris (CET)</option>
      <option value="Asia/Tokyo">Tokyo (JST)</option>
      <option value="Asia/Shanghai">Shanghai (CST)</option>
      <option value="Asia/Kolkata">India (IST)</option>
      <option value="Australia/Sydney">Sydney (AEST)</option>
    </select>
  </div>
)

const AppearanceStep = ({ formData, setFormData }: any) => (
  <div className="space-y-6">
    <div className="text-center mb-6">
      <h2 className="text-2xl font-bold text-white mb-2">Choose your style</h2>
      <p className="text-gray-300">Pick themes that inspire you</p>
    </div>
    
    <div>
      <label className="block text-white font-semibold mb-3">App Theme</label>
      <div className="grid grid-cols-2 gap-3">
        {[
          { value: "fantasy", label: "Fantasy", emoji: "🏰" },
          { value: "sci-fi", label: "Sci-Fi", emoji: "🚀" },
          { value: "nature", label: "Nature", emoji: "🌿" },
          { value: "custom", label: "Custom", emoji: "🎨" }
        ].map((theme) => (
          <button
            key={theme.value}
            onClick={() => setFormData({ ...formData, gameTheme: theme.value })}
            className={`p-4 rounded-lg border-2 transition ${
              formData.gameTheme === theme.value
                ? "border-purple-500 bg-purple-500/20 text-white"
                : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
            }`}
          >
            <div className="text-2xl mb-2">{theme.emoji}</div>
            {theme.label}
          </button>
        ))}
      </div>
    </div>
  </div>
)

const PreferencesStep = ({ formData, setFormData }: any) => (
  <div className="space-y-6">
    <div className="text-center mb-6">
      <h2 className="text-2xl font-bold text-white mb-2">Work preferences</h2>
      <p className="text-gray-300">How do you like to manage your time?</p>
    </div>
    
    <div>
      <label className="block text-white font-semibold mb-3">Time Management Style</label>
      <div className="space-y-3">
        {[
          { value: "pomodoro", label: "Pomodoro Technique", desc: "25min work, 5min break cycles" },
          { value: "timeblocking", label: "Time Blocking", desc: "Dedicated time slots for tasks" },
          { value: "flexible", label: "Flexible", desc: "Work at your own pace" }
        ].map((style) => (
          <button
            key={style.value}
            onClick={() => setFormData({ ...formData, timeManagement: style.value })}
            className={`w-full p-4 rounded-lg border-2 text-left transition ${
              formData.timeManagement === style.value
                ? "border-purple-500 bg-purple-500/20 text-white"
                : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
            }`}
          >
            <div className="font-semibold">{style.label}</div>
            <div className="text-sm opacity-75">{style.desc}</div>
          </button>
        ))}
      </div>
    </div>

    <div>
      <label className="block text-white font-semibold mb-3">Intensity Level</label>
      <div className="grid grid-cols-3 gap-3">
        {[
          { value: "casual", label: "Casual", emoji: "😌" },
          { value: "moderate", label: "Moderate", emoji: "💪" },
          { value: "intense", label: "Intense", emoji: "🔥" }
        ].map((level) => (
          <button
            key={level.value}
            onClick={() => setFormData({ ...formData, intensity: level.value })}
            className={`p-4 rounded-lg border-2 transition ${
              formData.intensity === level.value
                ? "border-purple-500 bg-purple-500/20 text-white"
                : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
            }`}
          >
            <div className="text-2xl mb-2">{level.emoji}</div>
            {level.label}
          </button>
        ))}
      </div>
    </div>
  </div>
)

const MotivationStep = ({ formData, setFormData }: any) => (
  <div className="space-y-6">
    <div className="text-center mb-6">
      <h2 className="text-2xl font-bold text-white mb-2">Stay motivated</h2>
      <p className="text-gray-300">What helps you recharge during breaks?</p>
    </div>
    
    <div className="grid grid-cols-2 gap-3">
      {[
        { value: "music", label: "Music", emoji: "🎵", desc: "Curated playlists" },
        { value: "videos", label: "Videos", emoji: "🎬", desc: "Motivational clips" },
        { value: "quotes", label: "Quotes", emoji: "💭", desc: "Inspiring words" },
        { value: "none", label: "None", emoji: "🔇", desc: "Silent breaks" }
      ].map((content) => (
        <button
          key={content.value}
          onClick={() => setFormData({ ...formData, motivationalContent: content.value })}
          className={`p-4 rounded-lg border-2 transition ${
            formData.motivationalContent === content.value
              ? "border-purple-500 bg-purple-500/20 text-white"
              : "border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500"
          }`}
        >
          <div className="text-2xl mb-2">{content.emoji}</div>
          <div className="font-semibold">{content.label}</div>
          <div className="text-xs opacity-75">{content.desc}</div>
        </button>
      ))}
    </div>
  </div>
)
