"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Bot, Send, Sparkles, Target, Calendar, CheckCircle } from 'lucide-react'

interface AIOnboardingSessionProps {
  onComplete: (tasks: any) => void
}

interface Message {
  from: "ai" | "user"
  text: string
  timestamp: Date
}

interface GeneratedTask {
  title: string
  category: "main" | "side" | "mini"
  xp: number
  frequency: "daily" | "weekly" | "monthly"
}

export default function AIOnboardingSession({ onComplete }: AIOnboardingSessionProps) {
  const { user } = useAuth()
  const [messages, setMessages] = useState<Message[]>([
    {
      from: "ai",
      text: `Hello ${user?.firstName || 'there'}! 👋 I'm your AI productivity assistant. I'm here to help you set up your personalized task system. Let's start by understanding your goals and daily routine. What are the main areas of your life you'd like to improve or focus on? (e.g., work, health, learning, personal projects)`,
      timestamp: new Date()
    }
  ])
  const [currentInput, setCurrentInput] = useState("")
  const [isThinking, setIsThinking] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)
  const [userResponses, setUserResponses] = useState<string[]>([])
  const [generatedTasks, setGeneratedTasks] = useState<GeneratedTask[]>([])
  const [showTaskPreview, setShowTaskPreview] = useState(false)

  const aiQuestions = [
    "What are the main areas of your life you'd like to improve or focus on?",
    "What does a typical day look like for you? What are your main responsibilities?",
    "What are your biggest challenges when it comes to staying productive?",
    "What time of day do you feel most energetic and focused?",
    "What are 2-3 specific goals you'd like to achieve in the next month?"
  ]

  const handleSendMessage = async () => {
    if (!currentInput.trim() || isThinking) return

    const userMessage: Message = {
      from: "user",
      text: currentInput,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setUserResponses(prev => [...prev, currentInput])
    setCurrentInput("")
    setIsThinking(true)

    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2000))

    let aiResponse = ""
    
    if (currentStep < aiQuestions.length) {
      const responses = [
        "That's great insight! Understanding your focus areas helps me create relevant tasks.",
        "Thanks for sharing your routine. This helps me understand your schedule better.",
        "I appreciate your honesty about challenges. Let's work on solutions together.",
        "Perfect! Knowing your peak energy times will help optimize your task scheduling.",
        "Excellent goals! Now I have everything I need to create your personalized task system."
      ]
      
      aiResponse = responses[currentStep - 1]
      
      if (currentStep < aiQuestions.length) {
        aiResponse += ` ${aiQuestions[currentStep]}`
        setCurrentStep(prev => prev + 1)
      } else {
        aiResponse += " Let me generate your personalized tasks based on our conversation..."
        setTimeout(() => generateTasks(), 1000)
      }
    }

    setMessages(prev => [...prev, {
      from: "ai",
      text: aiResponse,
      timestamp: new Date()
    }])

    setIsThinking(false)
  }

  const generateTasks = async () => {
    setIsThinking(true)
    
    // Simulate AI task generation based on user responses
    await new Promise(resolve => setTimeout(resolve, 3000))

    const taskTemplates = {
      work: [
        { title: "Review daily priorities", category: "mini" as const, frequency: "daily" as const },
        { title: "Complete important project milestone", category: "main" as const, frequency: "weekly" as const },
        { title: "Organize workspace", category: "side" as const, frequency: "daily" as const },
        { title: "Check and respond to emails", category: "mini" as const, frequency: "daily" as const }
      ],
      health: [
        { title: "30-minute workout session", category: "main" as const, frequency: "daily" as const },
        { title: "Drink 8 glasses of water", category: "mini" as const, frequency: "daily" as const },
        { title: "Prepare healthy meal", category: "side" as const, frequency: "daily" as const },
        { title: "10-minute meditation", category: "mini" as const, frequency: "daily" as const }
      ],
      learning: [
        { title: "Read for 30 minutes", category: "side" as const, frequency: "daily" as const },
        { title: "Complete online course module", category: "main" as const, frequency: "weekly" as const },
        { title: "Practice new skill", category: "side" as const, frequency: "daily" as const },
        { title: "Review learning notes", category: "mini" as const, frequency: "daily" as const }
      ],
      personal: [
        { title: "Call family/friends", category: "side" as const, frequency: "weekly" as const },
        { title: "Journal reflection", category: "mini" as const, frequency: "daily" as const },
        { title: "Plan weekend activities", category: "side" as const, frequency: "weekly" as const },
        { title: "Tidy living space", category: "mini" as const, frequency: "daily" as const }
      ]
    }

    // Generate tasks based on user responses
    const tasks: GeneratedTask[] = []
    const responses = userResponses.join(" ").toLowerCase()

    Object.entries(taskTemplates).forEach(([category, categoryTasks]) => {
      if (responses.includes(category) || responses.includes(category.slice(0, -1))) {
        tasks.push(...categoryTasks.slice(0, 2))
      }
    })

    // Add some default tasks if none were generated
    if (tasks.length === 0) {
      tasks.push(
        { title: "Plan your day", category: "mini", frequency: "daily", xp: 10 },
        { title: "Complete priority task", category: "main", frequency: "daily", xp: 100 },
        { title: "Take a short break", category: "mini", frequency: "daily", xp: 5 },
        { title: "Review progress", category: "side", frequency: "daily", xp: 30 }
      )
    }

    // Add XP values
    const tasksWithXP = tasks.map(task => ({
      ...task,
      xp: task.category === "main" ? 100 : task.category === "side" ? 40 : 10
    }))

    setGeneratedTasks(tasksWithXP)
    setShowTaskPreview(true)
    setIsThinking(false)

    setMessages(prev => [...prev, {
      from: "ai",
      text: "Perfect! I've generated a personalized task system for you based on our conversation. Here are your recommended daily tasks. You can review and customize them before we proceed.",
      timestamp: new Date()
    }])
  }

  const handleCompleteOnboarding = () => {
    const organizedTasks = {
      main: generatedTasks.filter(t => t.category === "main"),
      side: generatedTasks.filter(t => t.category === "side"),
      mini: generatedTasks.filter(t => t.category === "mini")
    }
    
    onComplete(organizedTasks)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">AI Task Setup</h1>
              <p className="text-purple-100">Let's create your personalized productivity system</p>
            </div>
          </div>
          <div className="mt-4">
            <div className="flex justify-between text-sm text-purple-100 mb-2">
              <span>Progress</span>
              <span>{Math.min(currentStep, 5)}/5</span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-2">
              <div 
                className="bg-white h-2 rounded-full transition-all duration-500"
                style={{ width: `${(Math.min(currentStep, 5) / 5) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Chat Area */}
        <div className="h-96 overflow-y-auto p-6 space-y-4">
          {messages.map((message, index) => (
            <div key={index} className={`flex ${message.from === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-xs md:max-w-md p-4 rounded-2xl ${
                message.from === "user" 
                  ? "bg-indigo-600 text-white rounded-br-none" 
                  : "bg-gray-700 text-white rounded-bl-none"
              }`}>
                {message.from === "ai" && (
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    <span className="text-xs text-purple-400 font-semibold">AI Assistant</span>
                  </div>
                )}
                <p className="text-sm leading-relaxed">{message.text}</p>
              </div>
            </div>
          ))}
          
          {isThinking && (
            <div className="flex justify-start">
              <div className="bg-gray-700 p-4 rounded-2xl rounded-bl-none">
                <div className="flex items-center gap-2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-100"></div>
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-200"></div>
                  </div>
                  <span className="text-sm text-gray-300">AI is thinking...</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Task Preview */}
        {showTaskPreview && (
          <div className="border-t border-white/20 p-6">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <Target className="text-purple-400" />
              Your Personalized Tasks
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <h4 className="font-semibold text-red-400 mb-2">Main Quests ({generatedTasks.filter(t => t.category === "main").length})</h4>
                {generatedTasks.filter(t => t.category === "main").map((task, index) => (
                  <div key={index} className="bg-red-900/20 p-2 rounded-lg mb-2 text-sm">
                    <div className="font-medium">{task.title}</div>
                    <div className="text-xs text-gray-400">+{task.xp} XP • {task.frequency}</div>
                  </div>
                ))}
              </div>
              <div>
                <h4 className="font-semibold text-blue-400 mb-2">Side Quests ({generatedTasks.filter(t => t.category === "side").length})</h4>
                {generatedTasks.filter(t => t.category === "side").map((task, index) => (
                  <div key={index} className="bg-blue-900/20 p-2 rounded-lg mb-2 text-sm">
                    <div className="font-medium">{task.title}</div>
                    <div className="text-xs text-gray-400">+{task.xp} XP • {task.frequency}</div>
                  </div>
                ))}
              </div>
              <div>
                <h4 className="font-semibold text-green-400 mb-2">Mini Tasks ({generatedTasks.filter(t => t.category === "mini").length})</h4>
                {generatedTasks.filter(t => t.category === "mini").map((task, index) => (
                  <div key={index} className="bg-green-900/20 p-2 rounded-lg mb-2 text-sm">
                    <div className="font-medium">{task.title}</div>
                    <div className="text-xs text-gray-400">+{task.xp} XP • {task.frequency}</div>
                  </div>
                ))}
              </div>
            </div>
            <button
              onClick={handleCompleteOnboarding}
              className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-semibold py-3 px-6 rounded-lg transition flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              Start My Productivity Journey!
            </button>
          </div>
        )}

        {/* Input Area */}
        {!showTaskPreview && (
          <div className="border-t border-white/20 p-6">
            <div className="flex gap-3">
              <input
                type="text"
                value={currentInput}
                onChange={(e) => setCurrentInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                placeholder="Type your response..."
                className="flex-1 bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                disabled={isThinking}
              />
              <button
                onClick={handleSendMessage}
                disabled={isThinking || !currentInput.trim()}
                className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white p-3 rounded-lg transition"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
