"use client"

import { useState } from "react"
import { ArrowLeft, Calendar, Star, Clock, Target, CheckCircle, Circle } from "lucide-react"

interface MainQuestDetailPageProps {
  quest: any
  onBack: () => void
}

export default function MainQuestDetailPage({ quest, onBack }: MainQuestDetailPageProps) {
  const [notes, setNotes] = useState("")
  const [timeSpent, setTimeSpent] = useState("0")
  const [difficulty, setDifficulty] = useState(3)

  return (
    <div className="animate-fade-in space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition">
          <ArrowLeft size={20} />
        </button>
        <div className="flex-grow">
          <h1 className="text-2xl font-bold">Quest Details</h1>
          <p className="text-gray-400">Detailed view and tracking</p>
        </div>
      </div>

      {/* Quest Info Card */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-6 rounded-xl border border-indigo-700/50 shadow-lg">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-grow">
            <h2 className="text-xl font-bold mb-2">{quest.title}</h2>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <div className="flex items-center gap-1">
                <Star className="text-yellow-400" size={16} />
                <span>+{quest.xp} XP</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar size={16} />
                <span>Created: {new Date().toLocaleDateString()}</span>
              </div>
            </div>
          </div>
          <div className={`p-2 rounded-full ${quest.completed ? "bg-green-600" : "bg-gray-600"}`}>
            {quest.completed ? <CheckCircle size={24} /> : <Circle size={24} />}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-gray-700/50 p-3 rounded-lg">
            <div className="text-sm text-gray-400 mb-1">Status</div>
            <div className={`font-semibold ${quest.completed ? "text-green-400" : "text-yellow-400"}`}>
              {quest.completed ? "Completed" : "In Progress"}
            </div>
          </div>
          <div className="bg-gray-700/50 p-3 rounded-lg">
            <div className="text-sm text-gray-400 mb-1">Priority</div>
            <div className="font-semibold text-red-400">High</div>
          </div>
        </div>
      </div>

      {/* Progress Tracking */}
      <div className="bg-gray-800/60 p-6 rounded-xl border border-gray-700">
        <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Target />
          Progress Tracking
        </h3>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold mb-2">Time Spent (hours)</label>
            <input
              type="number"
              value={timeSpent}
              onChange={(e) => setTimeSpent(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-400 focus:outline-none"
              min="0"
              step="0.5"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2">Difficulty Level</label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((level) => (
                <button
                  key={level}
                  onClick={() => setDifficulty(level)}
                  className={`w-8 h-8 rounded-full border-2 transition ${
                    level <= difficulty ? "bg-indigo-600 border-indigo-600" : "border-gray-600 hover:border-indigo-400"
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2">Notes & Reflections</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add notes about your progress, challenges, or insights..."
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-400 focus:outline-none h-32 resize-none"
            />
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-gray-800/60 p-6 rounded-xl border border-gray-700">
        <h3 className="text-lg font-bold mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-3">
          <button className="flex items-center justify-center gap-2 p-3 bg-green-600 hover:bg-green-500 rounded-lg font-semibold transition">
            <CheckCircle size={18} />
            Mark Complete
          </button>
          <button className="flex items-center justify-center gap-2 p-3 bg-blue-600 hover:bg-blue-500 rounded-lg font-semibold transition">
            <Clock size={18} />
            Start Timer
          </button>
          <button className="flex items-center justify-center gap-2 p-3 bg-purple-600 hover:bg-purple-500 rounded-lg font-semibold transition">
            <Target size={18} />
            Break Down
          </button>
          <button className="flex items-center justify-center gap-2 p-3 bg-gray-600 hover:bg-gray-500 rounded-lg font-semibold transition">
            <Calendar size={18} />
            Schedule
          </button>
        </div>
      </div>

      {/* Save Progress */}
      <button className="w-full p-3 bg-indigo-600 hover:bg-indigo-500 rounded-lg font-semibold transition">
        Save Progress
      </button>
    </div>
  )
}
