"use client"

import { useState, useEffect } from "react"
import { Code, Terminal, Cpu, Database, Wifi, Shield } from 'lucide-react'

export default function LoadingScreen() {
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState(0)

  const steps = [
    { icon: <Terminal />, text: "Initializing system...", color: "text-green-400" },
    { icon: <Database />, text: "Loading user data...", color: "text-blue-400" },
    { icon: <Cpu />, text: "Optimizing performance...", color: "text-purple-400" },
    { icon: <Shield />, text: "Securing connection...", color: "text-yellow-400" },
    { icon: <Wifi />, text: "Establishing sync...", color: "text-indigo-400" },
    { icon: <Code />, text: "Ready to launch!", color: "text-emerald-400" }
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 2
      })
    }, 50)

    const stepInterval = setInterval(() => {
      setCurrentStep(prev => {
        if (prev >= steps.length - 1) {
          clearInterval(stepInterval)
          return steps.length - 1
        }
        return prev + 1
      })
    }, 300)

    return () => {
      clearInterval(interval)
      clearInterval(stepInterval)
    }
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center p-4">
      {/* Matrix-like background effect */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`,
              animationDuration: `${2 + Math.random() * 3}s`
            }}
          >
            <div className="w-1 h-1 bg-green-400 rounded-full opacity-60"></div>
          </div>
        ))}
      </div>

      <div className="relative z-10 text-center max-w-md w-full">
        {/* Logo */}
        <div className="mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-green-400 to-blue-500 rounded-2xl mb-4 animate-pulse">
            <Code className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">TaskQuest</h1>
          <p className="text-gray-400">Initializing your productivity engine...</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="w-full bg-gray-800 rounded-full h-2 mb-4">
            <div 
              className="bg-gradient-to-r from-green-400 to-blue-500 h-2 rounded-full transition-all duration-100 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="text-gray-300 text-sm">{progress}% Complete</div>
        </div>

        {/* Loading Steps */}
        <div className="space-y-3">
          {steps.map((step, index) => (
            <div
              key={index}
              className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-300 ${
                index <= currentStep 
                  ? "bg-gray-800/50 border border-gray-700" 
                  : "opacity-30"
              }`}
            >
              <div className={`${step.color} ${index === currentStep ? "animate-spin" : ""}`}>
                {step.icon}
              </div>
              <span className={`text-sm ${index <= currentStep ? "text-white" : "text-gray-500"}`}>
                {step.text}
              </span>
              {index < currentStep && (
                <div className="ml-auto text-green-400">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Terminal-like output */}
        <div className="mt-8 bg-black/50 rounded-lg p-4 font-mono text-xs text-left">
          <div className="text-green-400 mb-1">$ taskquest --initialize</div>
          <div className="text-gray-400">Loading modules...</div>
          <div className="text-gray-400">Checking dependencies...</div>
          <div className="text-green-400">✓ All systems operational</div>
          <div className="text-blue-400 animate-pulse">▋</div>
        </div>
      </div>
    </div>
  )
}
