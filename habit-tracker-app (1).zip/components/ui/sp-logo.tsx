"use client"

import { useState, useEffect } from "react"

interface SPLogoProps {
  size?: "sm" | "md" | "lg" | "xl"
  showExpansion?: boolean
  animated?: boolean
  className?: string
}

export default function SPLogo({ 
  size = "md", 
  showExpansion = false, 
  animated = false,
  className = "" 
}: SPLogoProps) {
  const [showText, setShowText] = useState(!animated)

  useEffect(() => {
    if (animated) {
      const timer = setTimeout(() => {
        setShowText(true)
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [animated])

  const sizeClasses = {
    sm: "w-8 h-8 text-sm",
    md: "w-12 h-12 text-lg",
    lg: "w-16 h-16 text-xl",
    xl: "w-24 h-24 text-3xl"
  }

  const textSizes = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
    xl: "text-lg"
  }

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Logo Icon */}
      <div className={`${sizeClasses[size]} bg-gradient-to-br from-purple-500 via-indigo-500 to-blue-500 rounded-2xl flex items-center justify-center font-bold text-white shadow-lg relative overflow-hidden group`}>
        {/* Background Animation */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600 via-indigo-600 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* Progress Ring */}
        <svg className="absolute inset-0 w-full h-full transform -rotate-90" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="45"
            stroke="rgba(255,255,255,0.2)"
            strokeWidth="3"
            fill="none"
          />
          <circle
            cx="50"
            cy="50"
            r="45"
            stroke="rgba(255,255,255,0.8)"
            strokeWidth="3"
            fill="none"
            strokeDasharray={283}
            strokeDashoffset={animated ? 283 : 70}
            className={`transition-all duration-2000 ${animated ? 'animate-pulse' : ''}`}
            strokeLinecap="round"
          />
        </svg>
        
        {/* SP Text */}
        <span className="relative z-10 font-black tracking-tight">SP</span>
        
        {/* Skill Points Indicator */}
        <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full animate-pulse" />
      </div>

      {/* Expansion Text */}
      {showExpansion && (
        <div className={`transition-all duration-1000 ${showText ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'}`}>
          <div className="flex flex-col">
            <span className={`font-bold text-white ${textSizes[size]}`}>
              Skill Progressing
            </span>
            <span className={`text-gray-400 ${size === 'xl' ? 'text-sm' : 'text-xs'}`}>
              Level up your potential
            </span>
          </div>
        </div>
      )}
    </div>
  )
}
