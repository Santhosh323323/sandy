"use client"

import { useState, useEffect } from "react"
import SPLogo from "./sp-logo"

interface SplashScreenProps {
  onComplete: () => void
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [stage, setStage] = useState(0)

  useEffect(() => {
    const timers = [
      setTimeout(() => setStage(1), 500),   // Show logo
      setTimeout(() => setStage(2), 1500),  // Show expansion
      setTimeout(() => setStage(3), 3000),  // Start fade out
      setTimeout(() => onComplete(), 3500)  // Complete
    ]

    return () => timers.forEach(clearTimeout)
  }, [onComplete])

  return (
    <div className={`fixed inset-0 bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900 flex items-center justify-center z-50 transition-opacity duration-500 ${stage === 3 ? 'opacity-0' : 'opacity-100'}`}>
      {/* Animated Background Particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 4}s`
            }}
          >
            <div className="w-1 h-1 bg-white rounded-full opacity-30"></div>
          </div>
        ))}
      </div>

      {/* Floating Skill Icons */}
      <div className="absolute inset-0">
        {['⚡', '🎯', '🚀', '💎', '🔥', '⭐'].map((icon, i) => (
          <div
            key={i}
            className={`absolute text-2xl transition-all duration-2000 ${stage >= 1 ? 'opacity-20' : 'opacity-0'}`}
            style={{
              left: `${15 + (i * 15)}%`,
              top: `${20 + (i % 2) * 60}%`,
              transform: `translateY(${Math.sin(Date.now() / 1000 + i) * 10}px)`,
              animationDelay: `${i * 0.2}s`
            }}
          >
            {icon}
          </div>
        ))}
      </div>

      {/* Main Logo */}
      <div className={`relative z-10 transition-all duration-1000 ${stage >= 1 ? 'scale-100 opacity-100' : 'scale-50 opacity-0'}`}>
        <SPLogo 
          size="xl" 
          showExpansion={stage >= 2} 
          animated={stage >= 1}
        />
      </div>

      {/* Loading Indicator */}
      <div className={`absolute bottom-20 transition-all duration-500 ${stage >= 1 ? 'opacity-100' : 'opacity-0'}`}>
        <div className="flex flex-col items-center gap-4">
          <div className="flex space-x-2">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-3 h-3 bg-white rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.2}s` }}
              />
            ))}
          </div>
          <p className="text-white text-sm font-medium">Initializing your journey...</p>
        </div>
      </div>

      {/* Progress Ring */}
      <div className={`absolute inset-0 flex items-center justify-center transition-all duration-1000 ${stage >= 2 ? 'opacity-100' : 'opacity-0'}`}>
        <svg className="w-96 h-96 transform -rotate-90" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="48"
            stroke="rgba(255,255,255,0.1)"
            strokeWidth="0.5"
            fill="none"
          />
          <circle
            cx="50"
            cy="50"
            r="48"
            stroke="url(#gradient)"
            strokeWidth="0.5"
            fill="none"
            strokeDasharray={301}
            strokeDashoffset={stage >= 2 ? 50 : 301}
            className="transition-all duration-2000"
            strokeLinecap="round"
          />
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#8B5CF6" />
              <stop offset="50%" stopColor="#3B82F6" />
              <stop offset="100%" stopColor="#06B6D4" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  )
}
