"use client"

import { useEffect, useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Award, Clock, AlertTriangle, CheckCircle, XCircle } from 'lucide-react'

interface DailyQuest {
  id: string
  title: string
  description: string
  targetCount: number
  currentCount: number
  xpReward: number
  currentXP: number
  timeLimit: number
  startTime: string
  endTime: string
  isActive: boolean
  isCompleted: boolean
  isFailed: boolean
}

export default function DailyQuestCard() {
  const { user, updateUser } = useAuth()
  const [dailyQuest, setDailyQuest] = useState<DailyQuest | null>(null)
  const [timeRemaining, setTimeRemaining] = useState(0)

  // Initialize or load daily quest
  useEffect(() => {
    if (user) {
      const today = new Date().toISOString().split('T')[0]
      const savedQuest = localStorage.getItem(`dailyQuest_${today}`)
      
      if (savedQuest) {
        const quest = JSON.parse(savedQuest)
        setDailyQuest(quest)
      } else {
        // Create new daily quest
        const newQuest: DailyQuest = {
          id: `daily_${today}`,
          title: "Daily Quest Challenge",
          description: "Complete 3 Main Quests before sunset",
          targetCount: 3,
          currentCount: 0,
          xpReward: 50,
          currentXP: 0,
          timeLimit: 18, // 18 hours from start
          startTime: new Date().toISOString(),
          endTime: new Date(Date.now() + 18 * 60 * 60 * 1000).toISOString(),
          isActive: true,
          isCompleted: false,
          isFailed: false
        }
        setDailyQuest(newQuest)
        localStorage.setItem(`dailyQuest_${today}`, JSON.stringify(newQuest))
      }
    }
  }, [user])

  // Update timer and check quest status
  useEffect(() => {
    if (!dailyQuest) return

    const updateTimer = () => {
      const now = new Date()
      const endTime = new Date(dailyQuest.endTime)
      const remaining = Math.max(0, endTime.getTime() - now.getTime())
      setTimeRemaining(remaining)

      // Check if quest failed
      if (remaining === 0 && !dailyQuest.isCompleted && !dailyQuest.isFailed && dailyQuest.isActive) {
        const failedQuest = {
          ...dailyQuest,
          isFailed: true,
          isActive: false,
          currentXP: 0
        }

        // Reduce user XP by 25% of the quest reward
        if (user) {
          const xpPenalty = Math.floor(dailyQuest.xpReward * 0.25)
          const newStats = { ...user.stats }
          newStats.xp = Math.max(0, newStats.xp - xpPenalty)
          newStats.totalXp = Math.max(0, newStats.totalXp - xpPenalty)

          updateUser({ stats: newStats })
        }

        setDailyQuest(failedQuest)
        const today = new Date().toISOString().split('T')[0]
        localStorage.setItem(`dailyQuest_${today}`, JSON.stringify(failedQuest))
      }
    }

    updateTimer()
    const interval = setInterval(updateTimer, 1000)
    return () => clearInterval(interval)
  }, [dailyQuest, user, updateUser])

  // Listen for quest updates from localStorage
  useEffect(() => {
    const handleStorageChange = () => {
      const today = new Date().toISOString().split('T')[0]
      const savedQuest = localStorage.getItem(`dailyQuest_${today}`)
      if (savedQuest) {
        setDailyQuest(JSON.parse(savedQuest))
      }
    }

    const interval = setInterval(handleStorageChange, 1000)
    return () => clearInterval(interval)
  }, [])

  if (!dailyQuest) return null

  const formatTime = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60))
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60))
    return `${hours}h ${minutes}m`
  }

  const getStatusColor = () => {
    if (dailyQuest.isCompleted) return "from-green-600 to-emerald-600"
    if (dailyQuest.isFailed) return "from-red-600 to-rose-600"
    if (timeRemaining < 2 * 60 * 60 * 1000) return "from-orange-600 to-red-600" // Less than 2 hours
    return "from-gray-800 to-gray-900"
  }

  const getStatusIcon = () => {
    if (dailyQuest.isCompleted) return <CheckCircle className="text-green-400" />
    if (dailyQuest.isFailed) return <XCircle className="text-red-400" />
    if (timeRemaining < 2 * 60 * 60 * 1000) return <AlertTriangle className="text-orange-400" />
    return <Award className="text-yellow-400" />
  }

  return (
    <div className={`bg-gradient-to-br ${getStatusColor()} p-4 rounded-xl border border-gray-700 shadow-lg`}>
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-bold text-lg flex items-center gap-2">
          {getStatusIcon()}
          {dailyQuest.title}
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold bg-yellow-400 text-gray-900 px-2 py-0.5 rounded-full">
            +{dailyQuest.currentXP} XP
          </span>
          {dailyQuest.isActive && (
            <div className="flex items-center gap-1 text-xs bg-gray-700 px-2 py-1 rounded-full">
              <Clock size={12} />
              {formatTime(timeRemaining)}
            </div>
          )}
        </div>
      </div>
      
      <p className="text-sm text-gray-300 mb-3">{dailyQuest.description}</p>
      
      <div className="w-full bg-gray-700 rounded-full h-2.5 mb-2">
        <div 
          className={`h-2.5 rounded-full transition-all duration-500 ${
            dailyQuest.isCompleted ? "bg-green-500" : 
            dailyQuest.isFailed ? "bg-red-500" : "bg-blue-500"
          }`}
          style={{ width: `${(dailyQuest.currentCount / dailyQuest.targetCount) * 100}%` }}
        />
      </div>
      
      <div className="flex justify-between items-center text-xs">
        <span className="text-gray-400">
          {dailyQuest.currentCount}/{dailyQuest.targetCount} Complete
        </span>
        {dailyQuest.isFailed && (
          <span className="text-red-400 font-semibold">
            Failed - XP Reduced
          </span>
        )}
        {dailyQuest.isCompleted && (
          <span className="text-green-400 font-semibold">
            Quest Complete!
          </span>
        )}
      </div>
    </div>
  )
}
