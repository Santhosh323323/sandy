"use client"

import { useState, useEffect } from "react"
import { useApp } from "@/contexts/app-context"
import { Play, Pause, RotateCcw, Settings, Clock, Smartphone, Timer, Target, TrendingUp } from 'lucide-react'

export default function FocusPage() {
  const [activeTab, setActiveTab] = useState<"timer" | "limits" | "analytics">("timer")

  return (
    <div className="animate-fade-in space-y-6">
      <h1 className="text-2xl font-bold">Focus</h1>

      {/* Tab Navigation */}
      <div className="flex bg-gray-800/50 rounded-lg p-1">
        <button
          onClick={() => setActiveTab("timer")}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition ${
            activeTab === "timer" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"
          }`}
        >
          <Timer size={18} />
          Pomodoro Timer
        </button>
        <button
          onClick={() => setActiveTab("analytics")}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition ${
            activeTab === "analytics" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"
          }`}
        >
          <TrendingUp size={18} />
          Focus Analytics
        </button>
        <button
          onClick={() => setActiveTab("limits")}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition ${
            activeTab === "limits" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"
          }`}
        >
          <Smartphone size={18} />
          App Limits
        </button>
      </div>

      {activeTab === "timer" && <PomodoroTimer />}
      {activeTab === "analytics" && <FocusAnalytics />}
      {activeTab === "limits" && <AppLimits />}
    </div>
  )
}

const FocusAnalytics = () => {
  const { quests } = useApp()
  const [focusData, setFocusData] = useState({
    dailyFocusScore: 0,
    tasksOnTime: 0,
    tasksOverdue: 0,
    averageCompletionTime: 0,
    focusTrend: "stable" as "improving" | "declining" | "stable"
  })

  useEffect(() => {
    const calculateFocusMetrics = () => {
      const today = new Date().toISOString().split('T')[0]
      const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      
      // Get task timing data
      const taskTiming = JSON.parse(localStorage.getItem('taskTiming') || '{}')
      const todayTasks = taskTiming[today] || {}
      const yesterdayTasks = taskTiming[yesterday] || {}
      
      // Calculate daily tasks
      const allTasks = [...quests.main, ...quests.side, ...quests.mini]
      const completedTasks = allTasks.filter(task => task.completed)
      const totalTasks = allTasks.length
      
      // Calculate focus score based on task completion efficiency
      let focusScore = 0
      if (totalTasks > 0) {
        const completionRate = (completedTasks.length / totalTasks) * 100
        focusScore = completionRate
        
        // Bonus for completing tasks within estimated time
        const onTimeCount = Object.values(todayTasks).filter((task: any) => 
          task.completed && task.actualTime <= task.estimatedTime
        ).length
        
        if (completedTasks.length > 0) {
          const onTimePercentage = (onTimeCount / completedTasks.length) * 100
          focusScore = (focusScore + onTimePercentage) / 2
        }
      }
      
      // Calculate tasks on time vs overdue
      const onTime = Object.values(todayTasks).filter((task: any) => 
        task.completed && task.actualTime <= task.estimatedTime
      ).length
      
      const overdue = allTasks.filter(task => !task.completed).length
      
      // Calculate average completion time
      const completedTimings = Object.values(todayTasks).filter((task: any) => task.completed)
      const avgTime = completedTimings.length > 0 
        ? completedTimings.reduce((sum: number, task: any) => sum + task.actualTime, 0) / completedTimings.length
        : 0
      
      // Determine trend
      const todayScore = focusScore
      const yesterdayScore = calculateYesterdayScore(yesterdayTasks)
      let trend: "improving" | "declining" | "stable" = "stable"
      
      if (todayScore > yesterdayScore + 5) trend = "improving"
      else if (todayScore < yesterdayScore - 5) trend = "declining"
      
      setFocusData({
        dailyFocusScore: Math.round(focusScore),
        tasksOnTime: onTime,
        tasksOverdue: overdue,
        averageCompletionTime: Math.round(avgTime * 10) / 10,
        focusTrend: trend
      })
    }

    const calculateYesterdayScore = (yesterdayTasks: any) => {
      const completedCount = Object.values(yesterdayTasks).filter((task: any) => task.completed).length
      const totalCount = Object.keys(yesterdayTasks).length
      return totalCount > 0 ? (completedCount / totalCount) * 100 : 50
    }

    calculateFocusMetrics()
  }, [quests])

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case "improving": return "text-green-400"
      case "declining": return "text-red-400"
      default: return "text-yellow-400"
    }
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "improving": return "📈"
      case "declining": return "📉"
      default: return "➡️"
    }
  }

  return (
    <div className="space-y-6">
      {/* Focus Score Card */}
      <div className="bg-gradient-to-r from-purple-600/20 to-indigo-600/20 p-6 rounded-xl border border-purple-500/30">
        <div className="text-center">
          <h3 className="text-lg font-semibold mb-2">Daily Focus Score</h3>
          <div className="text-4xl font-bold mb-2">{focusData.dailyFocusScore}%</div>
          <div className={`flex items-center justify-center gap-2 ${getTrendColor(focusData.focusTrend)}`}>
            <span>{getTrendIcon(focusData.focusTrend)}</span>
            <span className="capitalize">{focusData.focusTrend}</span>
          </div>
        </div>
      </div>

      {/* Focus Metrics */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-800/60 p-4 rounded-xl border border-gray-700">
          <div className="flex items-center gap-3 mb-2">
            <Target className="text-green-400" size={20} />
            <h4 className="font-semibold">Tasks On Time</h4>
          </div>
          <div className="text-2xl font-bold text-green-400">{focusData.tasksOnTime}</div>
          <p className="text-sm text-gray-400">Completed within estimated time</p>
        </div>

        <div className="bg-gray-800/60 p-4 rounded-xl border border-gray-700">
          <div className="flex items-center gap-3 mb-2">
            <Clock className="text-red-400" size={20} />
            <h4 className="font-semibold">Overdue Tasks</h4>
          </div>
          <div className="text-2xl font-bold text-red-400">{focusData.tasksOverdue}</div>
          <p className="text-sm text-gray-400">Tasks past deadline</p>
        </div>
      </div>

      {/* Performance Insights */}
      <div className="bg-gray-800/60 p-6 rounded-xl border border-gray-700">
        <h3 className="font-bold text-lg mb-4">Performance Insights</h3>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span>Average Task Completion Time</span>
            <span className="font-semibold">{focusData.averageCompletionTime}h</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span>Focus Efficiency</span>
            <span className={`font-semibold ${
              focusData.dailyFocusScore >= 80 ? "text-green-400" : 
              focusData.dailyFocusScore >= 60 ? "text-yellow-400" : "text-red-400"
            }`}>
              {focusData.dailyFocusScore >= 80 ? "Excellent" : 
               focusData.dailyFocusScore >= 60 ? "Good" : "Needs Improvement"}
            </span>
          </div>

          <div className="bg-gray-700/50 p-3 rounded-lg">
            <h4 className="font-semibold mb-2">💡 Focus Tip</h4>
            <p className="text-sm text-gray-300">
              {focusData.dailyFocusScore >= 80 
                ? "Great focus! Keep maintaining this momentum with regular breaks."
                : focusData.dailyFocusScore >= 60
                ? "Good progress! Try breaking larger tasks into smaller chunks."
                : "Consider using the Pomodoro technique to improve focus and reduce distractions."
              }
            </p>
          </div>
        </div>
      </div>

      {/* Weekly Focus Trend */}
      <div className="bg-gray-800/60 p-6 rounded-xl border border-gray-700">
        <h3 className="font-bold text-lg mb-4">Weekly Focus Pattern</h3>
        <div className="grid grid-cols-7 gap-2">
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
            const score = Math.floor(Math.random() * 40) + 60 // Simulated data
            return (
              <div key={day} className="text-center">
                <div className="text-xs text-gray-400 mb-1">{day}</div>
                <div className="h-16 bg-gray-700 rounded relative overflow-hidden">
                  <div 
                    className={`absolute bottom-0 w-full transition-all duration-500 ${
                      score >= 80 ? "bg-green-500" : score >= 60 ? "bg-yellow-500" : "bg-red-500"
                    }`}
                    style={{ height: `${score}%` }}
                  />
                </div>
                <div className="text-xs mt-1">{score}%</div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// Keep existing PomodoroTimer and AppLimits components...
const PomodoroTimer = () => {
  const [timeLeft, setTimeLeft] = useState(25 * 60) // 25 minutes
  const [isActive, setIsActive] = useState(false)
  const [mode, setMode] = useState<"work" | "break" | "longBreak">("work")
  const [sessions, setSessions] = useState(0)

  const timeSettings = {
    work: 25 * 60,
    break: 5 * 60,
    longBreak: 15 * 60,
  }

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => time - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      // Timer finished
      setIsActive(false)
      if (mode === "work") {
        setSessions((prev) => prev + 1)
        const newSessions = sessions + 1
        if (newSessions % 4 === 0) {
          setMode("longBreak")
          setTimeLeft(timeSettings.longBreak)
        } else {
          setMode("break")
          setTimeLeft(timeSettings.break)
        }
      } else {
        setMode("work")
        setTimeLeft(timeSettings.work)
      }
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isActive, timeLeft, mode, sessions])

  const toggleTimer = () => setIsActive(!isActive)

  const resetTimer = () => {
    setIsActive(false)
    setTimeLeft(timeSettings[mode])
  }

  const switchMode = (newMode: "work" | "break" | "longBreak") => {
    setMode(newMode)
    setTimeLeft(timeSettings[newMode])
    setIsActive(false)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const progress = ((timeSettings[mode] - timeLeft) / timeSettings[mode]) * 100

  return (
    <div className="space-y-6">
      {/* Mode Selector */}
      <div className="flex justify-center gap-2">
        <button
          onClick={() => switchMode("work")}
          className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${
            mode === "work" ? "bg-red-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
          }`}
        >
          Work
        </button>
        <button
          onClick={() => switchMode("break")}
          className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${
            mode === "break" ? "bg-green-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
          }`}
        >
          Break
        </button>
        <button
          onClick={() => switchMode("longBreak")}
          className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${
            mode === "longBreak" ? "bg-blue-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
          }`}
        >
          Long Break
        </button>
      </div>

      {/* Timer Display */}
      <div className="flex flex-col items-center">
        <div className="relative w-64 h-64 mb-6">
          <svg className="absolute w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="currentColor"
              strokeWidth="6"
              fill="none"
              className="text-gray-700"
            />
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="currentColor"
              strokeWidth="6"
              fill="none"
              strokeDasharray={283}
              strokeDashoffset={283 - (progress / 100) * 283}
              className={`transition-all duration-1000 ${
                mode === "work" ? "text-red-500" : mode === "break" ? "text-green-500" : "text-blue-500"
              }`}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="text-4xl font-mono font-bold">{formatTime(timeLeft)}</div>
            <div className="text-sm text-gray-400 capitalize">{mode} Time</div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-4">
          <button
            onClick={toggleTimer}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition ${
              isActive ? "bg-red-600 hover:bg-red-500" : "bg-green-600 hover:bg-green-500"
            }`}
          >
            {isActive ? <Pause size={20} /> : <Play size={20} />}
            {isActive ? "Pause" : "Start"}
          </button>
          <button
            onClick={resetTimer}
            className="flex items-center gap-2 px-4 py-3 rounded-lg bg-gray-600 hover:bg-gray-500 font-semibold transition"
          >
            <RotateCcw size={20} />
            Reset
          </button>
        </div>

        {/* Session Counter */}
        <div className="mt-4 text-center">
          <div className="text-lg font-semibold">Sessions Completed: {sessions}</div>
          <div className="flex justify-center gap-1 mt-2">
            {[...Array(4)].map((_, i) => (
              <div key={i} className={`w-3 h-3 rounded-full ${i < sessions % 4 ? "bg-yellow-400" : "bg-gray-600"}`} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

const AppLimits = () => {
  const [limits, setLimits] = useState([
    { name: "Social Media", currentTime: "2h 15m", limit: "3h", icon: "📱", enabled: true },
    { name: "Entertainment", currentTime: "1h 5m", limit: "2h", icon: "🎬", enabled: true },
    { name: "Games", currentTime: "45m", limit: "1h", icon: "🎮", enabled: false },
    { name: "News", currentTime: "30m", limit: "45m", icon: "📰", enabled: true },
  ])

  const toggleLimit = (index: number) => {
    setLimits((prev) => prev.map((limit, i) => (i === index ? { ...limit, enabled: !limit.enabled } : limit)))
  }

  return (
    <div className="space-y-6">
      <div className="bg-gray-800/60 p-4 rounded-xl border border-gray-700">
        <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
          <Clock />
          {"Today's Usage"}
        </h3>
        <div className="space-y-3">
          {limits.map((app, index) => (
            <div key={app.name} className="flex items-center justify-between bg-gray-700/50 p-3 rounded-lg">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{app.icon}</span>
                <div>
                  <div className="font-semibold">{app.name}</div>
                  <div className="text-sm text-gray-400">
                    {app.currentTime} / {app.limit}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-16 bg-gray-600 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all ${
                      app.currentTime.includes("2h")
                        ? "bg-red-500"
                        : app.currentTime.includes("1h")
                          ? "bg-yellow-500"
                          : "bg-green-500"
                    }`}
                    style={{ width: "60%" }}
                  />
                </div>
                <button
                  onClick={() => toggleLimit(index)}
                  className={`w-12 h-6 rounded-full p-1 transition ${app.enabled ? "bg-indigo-600" : "bg-gray-600"}`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition-transform ${
                      app.enabled ? "translate-x-6" : "translate-x-0"
                    }`}
                  />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gray-800/60 p-4 rounded-xl border border-gray-700">
        <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
          <Settings />
          Focus Settings
        </h3>
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span>Block notifications during focus</span>
            <button className="w-12 h-6 bg-indigo-600 rounded-full p-1">
              <div className="w-4 h-4 bg-white rounded-full translate-x-6 transition-transform" />
            </button>
          </div>
          <div className="flex justify-between items-center">
            <span>Auto-start breaks</span>
            <button className="w-12 h-6 bg-gray-600 rounded-full p-1">
              <div className="w-4 h-4 bg-white rounded-full transition-transform" />
            </button>
          </div>
          <div className="flex justify-between items-center">
            <span>Sound notifications</span>
            <button className="w-12 h-6 bg-indigo-600 rounded-full p-1">
              <div className="w-4 h-4 bg-white rounded-full translate-x-6 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
